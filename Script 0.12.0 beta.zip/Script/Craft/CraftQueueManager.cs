﻿using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class CraftQueueManager : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Скрипты")]
    public InventoryManager inventoryManager;
    public QuickslotInventory quickslotInventory;
    public CraftManager craftManager;

    [Space]
    [Header("Текущий крафт")]
    public CraftScriptableObject currentCraftItem;

    [Space]
    [Header("Информация")]
    public List<CraftQueueItemDetails> craftQueueItemDetails;

    [Space]
    public TMP_InputField craftAmountInputField;
    public int craftTime;
    private bool invokeUpdate;

    public void RemoveButtonFunction()
    {
        if (int.Parse(craftAmountInputField.text) <= 1) return;
        int newAmount = int.Parse(craftAmountInputField.text) - 1;
        craftAmountInputField.text = newAmount.ToString();
    }

    public void AddButtonFunction()
    {
        if (int.Parse(craftAmountInputField.text) >= 9) return;
        int newAmount = int.Parse(craftAmountInputField.text) + 1;
        craftAmountInputField.text = newAmount.ToString();
    }

    public void AddToCraftQueue()
    {
        bool poolFull = true;

        for (int i = 0; i < craftQueueItemDetails.Count; i++)
        {
            if (craftQueueItemDetails[i].craftAmount <= 0)
            {
                poolFull = false;
            }
        }

        if (poolFull == true) return;

        foreach (CraftResource craftResource in currentCraftItem.craftResources)
        {
            int amountToRemove = craftResource.craftObjectAmount * int.Parse(craftAmountInputField.text);

            foreach (InventorySlot slot in inventoryManager.slots)
            {
                if (amountToRemove <= 0) continue;

                if(slot.item == craftResource.craftObject)
                {
                    if(amountToRemove > slot.amount)
                    {
                        amountToRemove -= slot.amount;
                        slot.GetComponentInChildren<DragAndDropItem>().NullifySlotData();
                    }
                    else
                    {
                        slot.amount -= amountToRemove;
                        amountToRemove = 0;
                        if(slot.amount <= 0) slot.GetComponentInChildren<DragAndDropItem>().NullifySlotData(); else slot.itemAmountText.text = slot.amount.ToString();
                    }
                }
            }
        }
        
        for (int i = 0; i < craftQueueItemDetails.Count; i++)
        {
            if (craftQueueItemDetails[i].craftAmount <= 0)
            {
                craftQueueItemDetails[i].itemImage.sprite = currentCraftItem.finalCraft.icon;
                craftQueueItemDetails[i].amountText.text = craftAmountInputField.text;
                craftQueueItemDetails[i].craftAmount = int.Parse(craftAmountInputField.text);

                craftTime = currentCraftItem.craftTime;
                int minutes = Mathf.FloorToInt(craftTime / 60);
                int seconds = craftTime - minutes * 60;

                craftQueueItemDetails[i].timeText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
                craftQueueItemDetails[i].craftTime = craftTime;
                craftQueueItemDetails[i].currentCraftItem = currentCraftItem;

                craftQueueItemDetails[i].gameObject.SetActive(true);
                break;
            }
            else if (craftQueueItemDetails[i].currentCraftItem == currentCraftItem)
            {
                craftQueueItemDetails[i].craftAmount += int.Parse(craftAmountInputField.text);
                craftQueueItemDetails[i].amountText.text = "X" + craftQueueItemDetails[i].craftAmount.ToString();
                break;
            }
        }

        CancelInvoke();
        invokeUpdate = false;

        InvokeRepeating(nameof(TimeUpdate), 0f, 1f);

        inventoryManager.craftPanel.SetActive(false);
        quickslotInventory.CheckItemInHand();
        inventoryManager.clothAdder.UpdateClothes();
    }

    void TimeUpdate()
    {
        for (int i = 0; i < craftQueueItemDetails.Count; i++)
        {
            if (craftQueueItemDetails[i].craftAmount >= 1)
            {
                invokeUpdate = true;
                craftQueueItemDetails[i].UpdateTime();
                break;
            }
        }

        if (invokeUpdate == false) CancelInvoke();
    }
}
