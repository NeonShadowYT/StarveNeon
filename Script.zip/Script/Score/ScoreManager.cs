using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager instance;

    [Space]
    public TMP_Text scoreText;

    private void Awake() => instance = this;

    private void Start()
    {
        scoreText.text = "Опыт " + DataSaveLoad.instance.data.playerScore.ToString();

        if (DiscordManager.instance != null && DiscordManager.instance.discord != null) InvokeRepeating(nameof(DiscordBooster), 10f, 10f);
    }

    public void ScoreAdd(int scoreAdd)
    {
        DataSaveLoad.instance.data.playerScore += scoreAdd;
        scoreText.text = "Опыт " + DataSaveLoad.instance.data.playerScore.ToString();
    }

    private void DiscordBooster()
    {
        if (DiscordManager.instance == null || DiscordManager.instance.discord == null)
        {
            CancelInvoke();
            return;
        }

        //благодарность за дискорд статус Starve Neon, 1 тк не хочу делать из этого чит способ фарма опыта
        ScoreAdd(1);
    }
}

[System.Serializable]
public class Lvl
{
    public Sprite icon;
    public int xp;
}