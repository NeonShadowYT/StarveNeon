using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;

public class FractionManager : MonoBehaviour
{
    [Space]
    [Header("Данные")]
    public List<Fraction> allBiomFraction;

    [Space]
    public FractionScriptableObject currentFraction;
    public InventoryManager inventoryManager;

    public MoneyManager moneyManager;
    public MoneySlot currentMoneySlot;

    [Space]
    [Header("Визуал")]
    public Image FractionImage;

    public TMP_Text FractionNPCText;
    public TMP_Text FractionNameText;
    public TMP_Text FractionReputationText;

    public GameObject fractionPanel;

    [Space]
    [Header("Торговля")]
    public Transform TovarePanelSpawn;
    public GameObject ToverePrefab;

    public List<TovareList> Tovare;
    private Tovare currentTovare;

    [Space]
    [Header("Ксенксы")]
    public TMP_Text KsencseStatsReputationText;

    public int _ksenoRepAmount;
    public int ksenoRepAmount
    {
        get { return _ksenoRepAmount; }
        set
        {
            _ksenoRepAmount = value;
            KsencseStatsReputationText.text = "Репутация " + _ksenoRepAmount.ToString();

            for (int i = 0; i < allBiomFraction.Count; i++)
            {
                if (allBiomFraction[i].MyFraction.fractionRace == FractionRace.Ksencse)
                {
                    foreach (FractionNPS fractNps in allBiomFraction[i].fractionNps)
                    {
                        fractNps.CheckRep();
                    }
                }
            }
        }
    }

    [Space]
    [Header("Гк")]
    public TMP_Text GCStatsReputationText;

    public int _goldenRepAmount;
    public int goldenRepAmount
    {
        get { return _goldenRepAmount; }
        set
        {
            _goldenRepAmount = value;
            GCStatsReputationText.text = "Репутация " + _goldenRepAmount.ToString();

            for (int i = 0; i < allBiomFraction.Count; i++)
            {
                if (allBiomFraction[i].MyFraction.fractionRace == FractionRace.GC)
                {
                    foreach (FractionNPS fractNps in allBiomFraction[i].fractionNps)
                    {
                        fractNps.CheckRep();
                    }
                }
            }
        }
    }

    [Space]
    [Header("Оборотни")]
    public TMP_Text OborotenStatsReputationText;

    public int _oborotRepAmount;
    public int oborotRepAmount
    {
        get { return _oborotRepAmount; }
        set
        {
            _oborotRepAmount = value;
            OborotenStatsReputationText.text = "Репутация " + _oborotRepAmount.ToString();

            for (int i = 0; i < allBiomFraction.Count; i++)
            {
                if (allBiomFraction[i].MyFraction.fractionRace == FractionRace.Oboroten)
                {
                    foreach (FractionNPS fractNps in allBiomFraction[i].fractionNps)
                    {
                        fractNps.CheckRep();
                    }
                }
            }
        }
    }

    [Space]
    [Header("Стейси")]
    public TMP_Text StasyStatsReputationText;

    public int _stasyRepAmount;
    public int stasyRepAmount
    {
        get { return _stasyRepAmount; }
        set
        {
            _stasyRepAmount = value;
            StasyStatsReputationText.text = "Репутация " + _stasyRepAmount.ToString();

            for (int i = 0; i < allBiomFraction.Count; i++)
            {
                if (allBiomFraction[i].MyFraction.fractionRace == FractionRace.Stasy)
                {
                    foreach (FractionNPS fractNps in allBiomFraction[i].fractionNps)
                    {
                        fractNps.CheckRep();
                    }
                }
            }
        }
    }

    public void FractionFunc()
    {
        FractionImage.sprite = currentFraction.FractionIcon;
        FractionNameText.text = currentFraction.FractionName;

        CheckCurrentMoney();

        fractionPanel.SetActive(true);
        Tovare = currentFraction.Tovare;

        LoadTovareItems();
    }

    public void FractionClose() => fractionPanel.SetActive(false);

    public void AddMoney(MoneyItem money)
    {
        moneyManager.CurrentAddMoney(money);

        if (currentMoneySlot != null && currentTovare != null) currentTovare.UpdateTovare(currentMoneySlot);
    }

    public void LoadTovareItems()
    {
        for (int i = 0; i < TovarePanelSpawn.childCount; i++) Destroy(TovarePanelSpawn.GetChild(i).gameObject);

        for (int i = 0; i < currentFraction.Tovare.Count; i++)
        {
            Tovare currentTovare = Instantiate(ToverePrefab, TovarePanelSpawn).GetComponent<Tovare>(); // У СУА ИЗМЕНИ ЧТОБЫ БЕЗ ИНСТАНТИЭЙТОВ // НУ ТРАТЬ ВРЕМЯ НА НАСТРОЙКУ КАЖДОГО ЧИХА УААА
            currentTovare.item = currentFraction.Tovare[i].TovareItem;
            currentTovare.inventoryManagers = inventoryManager;

            switch (currentFraction.fractionRace)
            {
                case FractionRace.Ksencse:
                    if (ksenoRepAmount >= 75) currentTovare.price = currentFraction.Tovare[i].TovarePrice / 2;
                    else if (ksenoRepAmount <= 15) currentTovare.price = currentFraction.Tovare[i].TovarePrice * 2;
                    break;
                case FractionRace.GC:
                    if (goldenRepAmount >= 65) currentTovare.price = currentFraction.Tovare[i].TovarePrice / 2;
                    else if (goldenRepAmount <= 10) currentTovare.price = currentFraction.Tovare[i].TovarePrice * 2;
                    break;
                case FractionRace.Oboroten:
                    if (oborotRepAmount >= 80) currentTovare.price = currentFraction.Tovare[i].TovarePrice / 2;
                    else if (oborotRepAmount <= 15) currentTovare.price = currentFraction.Tovare[i].TovarePrice * 2;
                    break;
                case FractionRace.Stasy:
                    if (stasyRepAmount >= 70) currentTovare.price = currentFraction.Tovare[i].TovarePrice / 2;
                    else if (stasyRepAmount <= 20) currentTovare.price = currentFraction.Tovare[i].TovarePrice * 2;
                    break;
            }

            currentTovare.UpdateTovare(currentMoneySlot);
            currentTovare.fractionManager = this;
        }
    }

    public void CheckCurrentMoney() => moneyManager.CheckCurrentMoney(currentFraction);
}