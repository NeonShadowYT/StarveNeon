using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class Stolery : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    public Daytime daytime;
    public WeatherManager weatherManager;

    [Space]
    public Image statsImage;
    public TMP_Text statsText;

    [Space]
    [Header("Статистика")]
    public int complexity;
    public int randomNext;

    [Space]
    [Header("Текущее состояние")]
    public StolyresScriptableObject currentStolyres;
    public Ivent currentIvent;
    public Weather currentWeather;

    [Space]
    [Header("Хорошие ивенты")]
    public List<Ivent> GoodIvent;

    [Header("Нормальные ивенты")]
    public List<Ivent> NormalIvent;

    [Header("Плохие ивенты")]
    public List<Ivent> NoGoodIvent;

    [Header("Ужасные ивенты")]
    public List<Ivent> PizdecIvent;

    [Space]
    [Header("Погода")]
    public List<Weather> WeatherIvent;


    void Awake()
    {
        for (int i = 0; i < GoodIvent.Count; i++) GoodIvent[i].objIvent.SetActive(false);
        for (int i = 0; i < NormalIvent.Count; i++) NormalIvent[i].objIvent.SetActive(false);
        for (int i = 0; i < NoGoodIvent.Count; i++) NoGoodIvent[i].objIvent.SetActive(false);
        for (int i = 0; i < PizdecIvent.Count; i++) PizdecIvent[i].objIvent.SetActive(false);
    }

    public void RandomIvent()
    {
        randomNext = Random.Range(0, 2); // ����� �� �� ��������� �����

        if (randomNext == 0) return;

        randomNext = Random.Range(0, 3); // 0 ������� �����, 1 ���������� �����, 2 ������ �����, 3 �������� �����

        switch (currentStolyres.name)
        {
            case "Golden Creeper": 
                GClogic();
                break;
            case "Mitmi Play": 
                MPlogic();
                break;
            case "Neon Shadow": 
                NSlogic();
                break;
            case "Оборотень Play": 
                OBlogic();
                break;
        }

        if (randomNext != 1)
        {
            RandomWeather();
        }
    }

    public void RandomWeather()
    {
        for (int i = 0; i < WeatherIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1 && WeatherIvent[i].Name != currentWeather.Name)
            {
                if (WeatherIvent[i].fogEnabled == true)
                {
                    if (weatherManager.fogEnabled != true)
                    {
                        return;
                    }
                }

                currentWeather = WeatherIvent[i];
                weatherManager.fogDensity = WeatherIvent[i].fogDensity;

                weatherManager.weatherPlayer.RainObj.SetActive(false);
                weatherManager.weatherPlayer.RainToxinObj.SetActive(false);
                weatherManager.weatherPlayer.RainAdObj.SetActive(false);
                weatherManager.weatherPlayer.FireObj.SetActive(false);
                weatherManager.weatherPlayer.ColdObj.SetActive(false);

                if (WeatherIvent[i].weatherType != WeatherType.Default)
                {
                    switch (WeatherIvent[i].weatherType)
                    {
                        case WeatherType.Rain:
                            weatherManager.weatherPlayer.RainObj.SetActive(true);
                            break;
                        case WeatherType.Toxin:
                            weatherManager.weatherPlayer.RainToxinObj.SetActive(true);
                            break;
                        case WeatherType.Ad:
                            weatherManager.weatherPlayer.RainAdObj.SetActive(true);
                            break;
                        case WeatherType.Fire:
                            weatherManager.weatherPlayer.FireObj.SetActive(true);
                            break;
                        case WeatherType.Cold:
                            weatherManager.weatherPlayer.ColdObj.SetActive(true);
                            break;
                    }
                }

                weatherManager.weatherPlayer.ColdChang = WeatherIvent[i].ColdChang;
                weatherManager.weatherPlayer.WeatherArmor = WeatherIvent[i].WeatherArmor;
                weatherManager.weatherPlayer.currentWeatherType = WeatherIvent[i].weatherType;

                weatherManager.weatherPlayer.StartWeather();
                weatherManager.ChangSettings();

                IventView(null, WeatherIvent[i]);
                break;
            }
        }
    }

    public void IventView(Ivent ivent, Weather weather)
    {   
        if (ivent != null)
        {
            daytime.DayText.text = ivent.Name;
            daytime.DayImage.sprite = ivent.iventIcon;
            daytime.DayTextObject.SetActive(true);

            statsText.text = ivent.Name;
            statsImage.sprite = ivent.iventIcon;
        }
        else if (weather != null)
        {
            daytime.DayText.text = weather.Name;
            daytime.DayImage.sprite = weather.iventIcon;

            statsText.text = weather.Name;
            statsImage.sprite = weather.iventIcon;

            daytime.DayTextObject.SetActive(true);
        }

        Invoke(nameof(ClozeIventView), 5f);
    }

    public void ClozeIventView()
    {
        daytime.DayTextObject.SetActive(false);
    }

    public void OnGoodIvent()
    {
        for (int i = 0; i < GoodIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1)
            {
                currentIvent = GoodIvent[i];

                if (GoodIvent[i].objIvent != null) GoodIvent[i].objIvent.SetActive(true);
                IventView(GoodIvent[i], null);

                GoodIvent.Remove(GoodIvent[i]);
                break;
            }
        }
    }

    public void OnNormalIvent()
    {
        for (int i = 0; i < NormalIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1)
            {
                currentIvent = NormalIvent[i];

                if (NormalIvent[i].objIvent != null) NormalIvent[i].objIvent.SetActive(true);
                IventView(NormalIvent[i], null);

                NormalIvent.Remove(NormalIvent[i]);
                break;
            }
        }
    }

    public void OnNoGoodIvent()
    {
        for (int i = 0; i < NoGoodIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1)
            {
                currentIvent = NoGoodIvent[i];

                if (NoGoodIvent[i].objIvent != null) NoGoodIvent[i].objIvent.SetActive(true);
                IventView(NoGoodIvent[i], null);

                NoGoodIvent.Remove(NoGoodIvent[i]);
                break;
            }
        }
    }

    public void OnPizdecIvent()
    {
        for (int i = 0; i < PizdecIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1)
            {
                currentIvent = PizdecIvent[i];

                if (PizdecIvent[i].objIvent != null) PizdecIvent[i].objIvent.SetActive(true);
                IventView(PizdecIvent[i], null);

                PizdecIvent.Remove(PizdecIvent[i]);
                break;
            }
        }
    }

    private void NSlogic() // ����
    {
        if (daytime.Day <= 8)
        {
            switch (randomNext)
            {
                case 0:
                    OnGoodIvent();
                    break;
                case 1:
                    OnNormalIvent();
                    break;
                default:
                    OnNoGoodIvent();
                    break;
            }
        }
        else if (daytime.Day <= 21)
        {
            switch (randomNext)
            {
                case 0:
                    OnGoodIvent();
                    break;
                case 1:
                    OnNormalIvent();
                    break;
                case 2:
                    OnNoGoodIvent();
                    break;
                case 3:
                    OnPizdecIvent();
                    break;
            }
        }
        else if (daytime.Day >= 22)
        {
            switch (randomNext)
            {
                case 2:
                    OnNoGoodIvent();
                    break;
                case 3:
                    OnNoGoodIvent();
                    break;
                default:
                    OnPizdecIvent();
                    break;
            }
        }
    }

    private void GClogic() // ��
    {
        if (daytime.Day <= 21)
        {
            switch (randomNext)
            {
                case 2:
                    OnNormalIvent();
                    break;
                case 3:
                    OnNoGoodIvent();
                    break;
                default:
                    OnGoodIvent();
                    break;
            }
        }
        else if (daytime.Day >= 22)
        {
            switch (randomNext)
            {
                case 0:
                    OnGoodIvent();
                    break;
                case 1:
                    OnNormalIvent();
                    break;
                case 2:
                    OnNoGoodIvent();
                    break;
                case 3:
                    OnPizdecIvent();
                    break;
            }
        }
    }

    private void MPlogic() // �����
    {
        switch (randomNext)
        {
            case 0:
                OnGoodIvent();
                break;
            case 1:
                OnNormalIvent();
                break;
            case 2:
                OnNoGoodIvent();
                break;
            case 3:
                OnPizdecIvent();
                break;
        }
    }

    private void OBlogic() // ���������
    {
        if (daytime.Day <= 3)
        {
            switch (randomNext)
            {
                case 0:
                    OnNormalIvent();
                    break;
                default:
                    OnNoGoodIvent();
                    break;
            }
        }
        else if (daytime.Day <= 21)
        {
            switch (randomNext)
            {
                case 1:
                    OnNormalIvent();
                    break;
                case 2:
                    OnNoGoodIvent();
                    break;
                default:
                    OnPizdecIvent();
                    break;
            }
        }
        else if (daytime.Day >= 22)
        {
            switch (randomNext)
            {
                case 2:
                    OnPizdecIvent();
                    break;
                default:
                    OnNoGoodIvent();
                    break;
            }
        }
    }

    private void Load()
    {
        dataSaveLoad.Load();

        currentStolyres = Resources.Load<StolyresScriptableObject>($"StolyresScriptable/{dataSaveLoad.data.stolyres}");
        complexity = dataSaveLoad.data.complexity;
    }
}

[System.Serializable]
public class Ivent
{
    public string Name;
    public Sprite iventIcon;

    [Space]
    [Header("Ивент")]
    public GameObject objIvent;
}

[System.Serializable]
public class Weather
{
    public string Name;
    public Sprite iventIcon;

    [Space]
    [Header("Погода")]
    public float fogDensity;
    public bool fogEnabled;

    [Space]
    public WeatherType weatherType;

    [Space]
    [Header("Характеристика")]
    public int WeatherArmor;
    public float ColdChang;
}