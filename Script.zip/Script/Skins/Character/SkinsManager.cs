using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class SkinsManager : MonoBehaviour
{
    public MeshRenderer[] meshRenderer;
    public Mesh[] allMesh;

    public void Start()
    {
        
    }
}