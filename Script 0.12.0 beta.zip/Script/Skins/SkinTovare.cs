using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SkinTovare : MonoBehaviour
{
    public MagazinManager magazinManager;
    public ItemSkinScriptableObject itemSkinScriptableObject;

    public TMP_Text Name;
    public TMP_Text Price;

    public Image Icon;
    public Button BuyButton;

    public void Startap()
    {
        if(magazinManager.dataSaveLoad.data.diamondValue >= itemSkinScriptableObject.Price)
        {
            BuyButton.interactable = true;
        }
        else
        {
            BuyButton.interactable = false;
        }
    }

    public void Buy()
    {
        if (magazinManager.dataSaveLoad.data.diamondValue >= itemSkinScriptableObject.Price)
        {
            magazinManager.dataSaveLoad.data.diamondValue -= itemSkinScriptableObject.Price;
            magazinManager.diamondMoneyText.text = magazinManager.dataSaveLoad.data.diamondValue.ToString();
            magazinManager.AllInventorySkins.Add(itemSkinScriptableObject);

            SkinsInventoryItem skinsInventoryItem = Instantiate(magazinManager.InventoryPrefs, magazinManager.InventoryContent).GetComponent<SkinsInventoryItem>();

            skinsInventoryItem.magazinManager = magazinManager;

            skinsInventoryItem.itemSkinScriptableObject = itemSkinScriptableObject;

            skinsInventoryItem.Image.sprite = itemSkinScriptableObject.Icon;
            skinsInventoryItem.Name.text = itemSkinScriptableObject.Name;

            skinsInventoryItem.Enable.SetActive(false);
            skinsInventoryItem.Disable.SetActive(true);

            magazinManager.UpdateTovare();
            magazinManager.Save();

            magazinManager.AllTovare.Remove(this);
            Destroy(gameObject);
        }
        else
        {
            BuyButton.interactable = false;
        }
    }
}
