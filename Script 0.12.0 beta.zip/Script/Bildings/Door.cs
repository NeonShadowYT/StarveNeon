﻿using System.Collections.Generic;
using UnityEngine;
public class Door : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    [SerializeField] public AudioClip doorAudio;

    public void InvertDoorState() => _animator.SetBool("IsOpened", !_animator.GetBool("IsOpened"));
}
