using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class MagazinManager : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    public TMP_Text diamondMoneyText;

    [Space]
    [Header("Магазин")]
    public GameObject TovarePrefs;
    public Transform TovareContent;

    [Space]
    [Header("Инвентарь")]
    public GameObject InventoryPrefs;
    public Transform InventoryContent;

    [Space]
    [Header("Все скины")]
    public List<ItemSkinScriptableObject> AllSkins;

    [Space]
    [Header("Купленные скины")]
    public List<ItemSkinScriptableObject> AllInventorySkins;
    public List<ItemSkinScriptableObject> AllActiveSkins;

    [Space]
    [Header("Все товары")]
    public List<SkinTovare> AllTovare;

    void Start()
    {
        Load();

        if (dataSaveLoad.data.haveItemSkin.Length != 0)
        {
            for (int i = 0; i < dataSaveLoad.data.haveItemSkin.Length; i++)
            {
                ItemSkinScriptableObject itemSkinScriptableObject = Resources.Load<ItemSkinScriptableObject>($"ItemSkinScriptableObject/{dataSaveLoad.data.haveItemSkin[i]}");

                AllInventorySkins.Add(itemSkinScriptableObject);
            }
        }

        if (dataSaveLoad.data.currentItemSkin.Length != 0)
        {
            for (int i = 0; i < dataSaveLoad.data.currentItemSkin.Length; i++)
            {
                ItemSkinScriptableObject itemSkinScriptableObject = Resources.Load<ItemSkinScriptableObject>($"ItemSkinScriptableObject/{dataSaveLoad.data.currentItemSkin[i]}");

                AllActiveSkins.Add(itemSkinScriptableObject);
            }
        }

        GenerateTovere();

        diamondMoneyText.text = dataSaveLoad.data.diamondValue.ToString();
    }

    public void Load()
    {
        dataSaveLoad.Load();
    }

    public void Save()
    {
        dataSaveLoad.Save();
    }

    public void GenerateTovere()
    {
        foreach (ItemSkinScriptableObject skin in AllSkins) // ��������� ��� �����
        {
            int skinBuy = 0;

            foreach (ItemSkinScriptableObject inventorySkin in AllInventorySkins) // ��������� ��� �����
            {
                if(skin == inventorySkin)
                {
                    skinBuy = 1;
                    break;
                }
            }

            if (skinBuy == 0)
            {
                SkinTovare skinTovare = Instantiate(TovarePrefs, TovareContent).GetComponent<SkinTovare>();

                skinTovare.magazinManager = this;

                skinTovare.itemSkinScriptableObject = skin;

                skinTovare.Icon.sprite = skin.Icon;
                skinTovare.Name.text = skin.Name;
                skinTovare.Price.text = skin.Price.ToString();

                skinTovare.Startap();

                AllTovare.Add(skinTovare);
            }
            else
            {
                SkinsInventoryItem skinsInventoryItem = Instantiate(InventoryPrefs, InventoryContent).GetComponent<SkinsInventoryItem>();

                skinsInventoryItem.magazinManager = this;

                skinsInventoryItem.itemSkinScriptableObject = skin;

                skinsInventoryItem.Image.sprite = skin.Icon;
                skinsInventoryItem.Name.text = skin.Name;

                foreach (ItemSkinScriptableObject active in AllActiveSkins) // ��������� ��� �����
                {
                    if (active == skin)
                    {
                        skinsInventoryItem.Enable.SetActive(true);
                        skinsInventoryItem.Disable.SetActive(false);
                    }
                    else
                    {
                        skinsInventoryItem.Enable.SetActive(false);
                        skinsInventoryItem.Disable.SetActive(true);
                    }
                }
            }
        }
    }

    public void UpdateTovare()
    {
        for (int i = 0; i < AllTovare.Count; i++)
        {
            AllTovare[i].Startap();
        }
    }

    public void AddDiamond(int amount)
    {
        Load();

        dataSaveLoad.data.diamondValue += amount;
        if (diamondMoneyText != null) diamondMoneyText.text = dataSaveLoad.data.diamondValue.ToString();
        
        UpdateTovare();
        Save();
    }
}
