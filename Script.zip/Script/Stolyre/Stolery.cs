using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class Stolery : MonoBehaviour
{
    public static Stolery instance;

    [Space]
    [Header("Статистика")]
    public int complexity;
    public int randomNext;

    [Space]
    [Header("Текущее состояние")]
    public StolyresScriptableObject currentStolyres;
    public Ivent currentIvent;
    public Weather currentWeather;

    [Space]
    [Header("Хорошие ивенты")]
    public List<Ivent> GoodIvent;

    [Header("Нормальные ивенты")]
    public List<Ivent> NormalIvent;

    [Header("Плохие ивенты")]
    public List<Ivent> NoGoodIvent;

    [Header("Ужасные ивенты")]
    public List<Ivent> PizdecIvent;

    [Space]
    [Header("Погода")]
    public List<Weather> WeatherIvent;

    private void Awake() => instance = this;

    private void Start()
    {
        for (int i = 0; i < GoodIvent.Count; i++) GoodIvent[i].objIvent.SetActive(false);
        for (int i = 0; i < NormalIvent.Count; i++) NormalIvent[i].objIvent.SetActive(false);
        for (int i = 0; i < NoGoodIvent.Count; i++) NoGoodIvent[i].objIvent.SetActive(false);
        for (int i = 0; i < PizdecIvent.Count; i++) PizdecIvent[i].objIvent.SetActive(false);
        
        currentStolyres = Resources.Load<StolyresScriptableObject>($"StolyresScriptable/{DataSaveLoad.instance.data.stolyres}");
        complexity = DataSaveLoad.instance.data.complexity;
    }

    public void RandomIvent()
    {
        if (Random.Range(0, 2) == 0) return;

        randomNext = Random.Range(0, 3);

        switch (currentStolyres.name)
        {
            case "Golden Creeper": 
                GClogic();
                break;
            case "Mitmi Play": 
                MPlogic();
                break;
            case "Neon Shadow": 
                NSlogic();
                break;
            case "Оборотень Play": 
                OBlogic();
                break;
        }

        if (randomNext != 1)
        {
            RandomWeather();
        }
    }

    public void RandomWeather()
    {
        for (int i = 0; i < WeatherIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1 && WeatherIvent[i].Name != currentWeather.Name)
            {
                if (WeatherIvent[i].fogEnabled == true)
                {
                    if (WeatherManager.instance.fogEnabled != true)
                    {
                        return;
                    }
                }

                currentWeather = WeatherIvent[i];
                WeatherManager.instance.fogDensity = WeatherIvent[i].fogDensity;

                WeatherPlayer.instance.RainObj.SetActive(false);
                WeatherPlayer.instance.RainToxinObj.SetActive(false);
                WeatherPlayer.instance.RainAdObj.SetActive(false);
                WeatherPlayer.instance.FireObj.SetActive(false);
                WeatherPlayer.instance.ColdObj.SetActive(false);

                switch (WeatherIvent[i].weatherType)
                {
                    case WeatherType.Rain:
                        WeatherPlayer.instance.RainObj.SetActive(true);
                        break;
                    case WeatherType.Toxin:
                        WeatherPlayer.instance.RainToxinObj.SetActive(true);
                        break;
                    case WeatherType.Ad:
                        WeatherPlayer.instance.RainAdObj.SetActive(true);
                        break;
                    case WeatherType.Fire:
                        WeatherPlayer.instance.FireObj.SetActive(true);
                        break;
                    case WeatherType.Cold:
                        WeatherPlayer.instance.ColdObj.SetActive(true);
                        break;
                }

                WeatherPlayer.instance.ColdChang = WeatherIvent[i].ColdChang;
                WeatherPlayer.instance.WeatherArmor = WeatherIvent[i].WeatherArmor;
                WeatherPlayer.instance.currentWeatherType = WeatherIvent[i].weatherType;

                WeatherPlayer.instance.StartWeather();
                WeatherManager.instance.ChangSettings();

                IventView(null, WeatherIvent[i]);
                break;
            }
        }
    }

    public void IventView(Ivent ivent, Weather weather)
    {
        if (ivent != null)
        {
            IventViewer.instance.IventView(ivent.iventIcon, ivent.Name);
            IventViewer.instance.ChangStats(currentStolyres.image, currentStolyres.name, ivent.iventIcon, ivent.Name);
        }
        else if (weather != null)
        {
            IventViewer.instance.IventView(weather.iventIcon, weather.Name);
            IventViewer.instance.ChangStats(currentStolyres.image, currentStolyres.name, weather.iventIcon, weather.Name);
        }
    }

    public void OnGoodIvent()
    {
        for (int i = 0; i < GoodIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1)
            {
                currentIvent = GoodIvent[i];

                if (GoodIvent[i].objIvent != null) GoodIvent[i].objIvent.SetActive(true);
                IventView(GoodIvent[i], null);

                GoodIvent.Remove(GoodIvent[i]);
                break;
            }
        }
    }

    public void OnNormalIvent()
    {
        for (int i = 0; i < NormalIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1)
            {
                currentIvent = NormalIvent[i];

                if (NormalIvent[i].objIvent != null) NormalIvent[i].objIvent.SetActive(true);
                IventView(NormalIvent[i], null);

                NormalIvent.Remove(NormalIvent[i]);
                break;
            }
        }
    }

    public void OnNoGoodIvent()
    {
        for (int i = 0; i < NoGoodIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1)
            {
                currentIvent = NoGoodIvent[i];

                if (NoGoodIvent[i].objIvent != null) NoGoodIvent[i].objIvent.SetActive(true);
                IventView(NoGoodIvent[i], null);

                NoGoodIvent.Remove(NoGoodIvent[i]);
                break;
            }
        }
    }

    public void OnPizdecIvent()
    {
        for (int i = 0; i < PizdecIvent.Count; i++)
        {
            randomNext = Random.Range(0, 2);
            if (randomNext == 1)
            {
                currentIvent = PizdecIvent[i];

                if (PizdecIvent[i].objIvent != null) PizdecIvent[i].objIvent.SetActive(true);
                IventView(PizdecIvent[i], null);

                PizdecIvent.Remove(PizdecIvent[i]);
                break;
            }
        }
    }

    private void NSlogic() // ����
    {
        if (DayTime.instance.Day <= 8)
        {
            switch (randomNext)
            {
                case 0:
                    OnGoodIvent();
                    break;
                case 1:
                    OnNormalIvent();
                    break;
                default:
                    OnNoGoodIvent();
                    break;
            }
        }
        else if (DayTime.instance.Day <= 21)
        {
            switch (randomNext)
            {
                case 0:
                    OnGoodIvent();
                    break;
                case 1:
                    OnNormalIvent();
                    break;
                case 2:
                    OnNoGoodIvent();
                    break;
                case 3:
                    OnPizdecIvent();
                    break;
            }
        }
        else if (DayTime.instance.Day >= 22)
        {
            switch (randomNext)
            {
                case 2:
                    OnNoGoodIvent();
                    break;
                case 3:
                    OnNoGoodIvent();
                    break;
                default:
                    OnPizdecIvent();
                    break;
            }
        }
    }

    private void GClogic() // ��
    {
        if (DayTime.instance.Day <= 21)
        {
            switch (randomNext)
            {
                case 2:
                    OnNormalIvent();
                    break;
                case 3:
                    OnNoGoodIvent();
                    break;
                default:
                    OnGoodIvent();
                    break;
            }
        }
        else if (DayTime.instance.Day >= 22)
        {
            switch (randomNext)
            {
                case 0:
                    OnGoodIvent();
                    break;
                case 1:
                    OnNormalIvent();
                    break;
                case 2:
                    OnNoGoodIvent();
                    break;
                case 3:
                    OnPizdecIvent();
                    break;
            }
        }
    }

    private void MPlogic() // �����
    {
        switch (randomNext)
        {
            case 0:
                OnGoodIvent();
                break;
            case 1:
                OnNormalIvent();
                break;
            case 2:
                OnNoGoodIvent();
                break;
            case 3:
                OnPizdecIvent();
                break;
        }
    }

    private void OBlogic() // ���������
    {
        if (DayTime.instance.Day <= 3)
        {
            switch (randomNext)
            {
                case 0:
                    OnNormalIvent();
                    break;
                default:
                    OnNoGoodIvent();
                    break;
            }
        }
        else if (DayTime.instance.Day <= 21)
        {
            switch (randomNext)
            {
                case 1:
                    OnNormalIvent();
                    break;
                case 2:
                    OnNoGoodIvent();
                    break;
                default:
                    OnPizdecIvent();
                    break;
            }
        }
        else if (DayTime.instance.Day >= 22)
        {
            switch (randomNext)
            {
                case 2:
                    OnPizdecIvent();
                    break;
                default:
                    OnNoGoodIvent();
                    break;
            }
        }
    }
}

[System.Serializable]
public class Ivent
{
    public string Name;
    public string Descriphen;
    public Sprite iventIcon;

    [Space]
    [Header("Ивент")]
    public GameObject objIvent;
}

[System.Serializable]
public class Weather
{
    public string Name;
    public Sprite iventIcon;

    [Space]
    [Header("Погода")]
    public float fogDensity;
    public bool fogEnabled;

    [Space]
    public WeatherType weatherType;

    [Space]
    [Header("Характеристика")]
    public int WeatherArmor;
    public float ColdChang;
}