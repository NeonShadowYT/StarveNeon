using UnityEngine;

public class MoneyItem : MonoBehaviour
{
    public MoneyScriptableObject money;
    public int amount;
}