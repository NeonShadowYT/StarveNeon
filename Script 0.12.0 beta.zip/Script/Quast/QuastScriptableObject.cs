using UnityEngine;

public enum QuastType { Kill, Claim, Day }

[CreateAssetMenu(fileName = "Quast", menuName = "Neon Imperium/Quast/New Pass Quast")]
public class QuastScriptableObject : ScriptableObject
{
    [Space]
    [Header("Визуал")]
    public string QuastText;
    public Sprite QuastImage;

    [Space]
    [Header("Тип квеста")]
    public QuastType quastType;

    [Space]
    [Header("Цель")]
    public MobScriptableObject QuastMob;

    [Space]
    [Header("Количество")]
    public int Amount;

    [Space]
    [Header("Награда")]
    public int PassMoneyReward;
}