using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class VerstAnLoker : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Скрипты")]
    public VerstCraftHelper verstCraftHelper;

    [Space]
    [Header("Данные")]
    public CraftScriptableObject craftAnLock;

    [Space]
    [Header("Интерфейс")]
    public Image IconImag;
    public TMP_Text TextTreb;
    public Button CurrentButtonAnLock;

    public void Anlock()
    {
        verstCraftHelper.anlockScore = craftAnLock.verstScore;
        verstCraftHelper.craftAnLock = craftAnLock;
        verstCraftHelper.currentVerstAnLoker = this;

        VerstacManager.instance.UpdateCraftAnLock(craftAnLock.finalCraft, craftAnLock.verstScore);
    }
}
