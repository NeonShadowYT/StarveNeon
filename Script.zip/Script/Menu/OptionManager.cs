using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using Cinemachine;
using TMPro;
using System.Threading.Tasks;

public class OptionManager : MonoBehaviour
{
	public static OptionManager instance;

	[Space]
	[Header("Данные")]
	[SerializeField] private CinemachineVirtualCamera CVC;

	private CinemachinePOV pov;
	private Cinemachine3rdPersonFollow follow;

	[SerializeField] private Camera mCamera;
	[SerializeField] private UniversalAdditionalCameraData cameraData;

	[SerializeField] private Material plants;

	private Light[] sceneLight;
	private DetailsModel[] sceneDetails;
	private TMP_Text[] sceneText;

	[Space]
	[Header("Настройки")]
	[Header("Графика")]
	[SerializeField] private TMP_Dropdown quality;
	[SerializeField] private TMP_Text qualityText;

	[Space]
	[SerializeField] private TMP_Dropdown resolution;
	[SerializeField] private TMP_Text resolutionText;

	[Space]
	[SerializeField] private TMP_Dropdown upscaling;
	[SerializeField] private TMP_Text upscalingText;

	[Space]
	[SerializeField] private Slider render;
	[SerializeField] private TMP_Text renderText;

	[Space]
	[SerializeField] private TMP_Dropdown window;
	[SerializeField] private TMP_Text windowText;

	[Space]
	[SerializeField] private TMP_Dropdown shadowType;
	[SerializeField] private TMP_Text shadowTypeText;

	[Space]
	[SerializeField] private TMP_Dropdown fogMode;
	[SerializeField] private TMP_Text fogModeText;

	[Space]
	[SerializeField] private TMP_Dropdown details;
	[SerializeField] private TMP_Text detailsText;

	[Space]
	[SerializeField] private TMP_Dropdown decoration;
	[SerializeField] private TMP_Text decorationText;

	[Space]
	[SerializeField] private TMP_Dropdown aliasingMode;
	[SerializeField] private TMP_Text aliasingModeText;

	[Space]
	[SerializeField] private TMP_Dropdown aliasingQuality;
	[SerializeField] private TMP_Text aliasingQualityText;

	[Space]
	[SerializeField] private TMP_Dropdown aliasingPower;
	[SerializeField] private TMP_Text aliasingPowerText;

	[Space]
	[SerializeField] private TMP_Dropdown vsync;
	[SerializeField] private TMP_Text vsyncText;

	[Space]
	[SerializeField] private TMP_Dropdown fpcLock;
	[SerializeField] private TMP_Text fpcLockText;

	[Space]
	[SerializeField] private Slider viewDisance;
	[SerializeField] private TMP_Text viewDisanceText;

	[Space]
	[SerializeField] private Slider drawDistance;
	[SerializeField] private TMP_Text drawDistanceText;

	[Space]
	[SerializeField] private Slider shadowDistance;
	[SerializeField] private TMP_Text shadowDistanceText;

	[Space]
	[SerializeField] private Slider additionalLights;
	[SerializeField] private TMP_Text additionalLightsText;

	[Space]
	[SerializeField] private TMP_Dropdown hdr;
	[SerializeField] private TMP_Text hdrText;

	[Header("Обработка")]
	[SerializeField] private VolumeProfile volumeProfile;
	private ColorAdjustments colorAdjustments;
	private MotionBlur motionBlur;
	private DepthOfField depthOfField;

	[Space]
	[SerializeField] private TMP_Dropdown postProcessing;
	[SerializeField] private TMP_Text postProcessingText;

	[Space]
	[SerializeField] private TMP_Dropdown adjustment;
	[SerializeField] private TMP_Text gradientText;

	[Space]
	[SerializeField] private Slider brightness;
	[SerializeField] private TMP_Text brightnessText;

	[Space]
	[SerializeField] private Slider contrast;
	[SerializeField] private TMP_Text contrastText;

	[Space]
	[SerializeField] private Slider saturation;
	[SerializeField] private TMP_Text saturationText;

	[Space]
	[SerializeField] private Slider motionBlurPower;
	[SerializeField] private TMP_Text motionBlurPowerText;

	[Space]
	[SerializeField] private Slider depthOfFieldRange;
	[SerializeField] private TMP_Text depthOfFieldRangeText;

	[Header("НеоТикс")]
	[SerializeField] private Material material;

	[Space]
	[SerializeField] private Slider neotxPower;
	[SerializeField] private TMP_Text neotxPowerText;

	[Space]
	[SerializeField] private Slider neotxMetal;
	[SerializeField] private TMP_Text neotxMetalText;

	[Header("Управление")]
	[SerializeField] private InputActionReference actionReferenceEsc;
	[SerializeField] private InputActionReference actionReferenceLut;

	[Space]
	[SerializeField] private TMP_Dropdown joystic;
	[SerializeField] private TMP_Text joysticText;

	[Space]
	[SerializeField] private TMP_Dropdown viewMode;
	[SerializeField] private TMP_Text viewModeText;

	[Space]
	[SerializeField] private Slider sensitivity;
	[SerializeField] private TMP_Text sensitivityText;

	[Space]
	[SerializeField] private Slider fovDisance;
	[SerializeField] private TMP_Text fovDisanceText;

	[Space]
	[SerializeField] private Slider smoothness;
	[SerializeField] private TMP_Text smoothnessText;

	[Space]
	[SerializeField] private TMP_InputField escInput;
	[SerializeField] private TMP_InputField lutInput;

	[Header("Звуки")]
	[SerializeField] private AudioMixer audioMixer;
	[SerializeField] private AudioMixer chatMixer;

	[Space]
	[SerializeField] private Slider volume;
	[SerializeField] private TMP_Text volumeText;

	[Space]
	[SerializeField] private Slider chatVolume;
	[SerializeField] private TMP_Text chatVolumeText;

	[Header("Оптимизация")]
	public OptimizeCounter optimizeCounter;

	[Space]
	[SerializeField] private Slider physics;
	[SerializeField] private TMP_Text physicsText;

	[Space]
	[SerializeField] private TMP_Dropdown memory;
	[SerializeField] private TMP_Text memoryText;

	[Space]
	[SerializeField] private TMP_Dropdown culling;
	[SerializeField] private TMP_Text cullingText;

	[Space]
	[SerializeField] private TMP_Dropdown counter;
	[SerializeField] private TMP_Text counterText;

	[Space]
	[SerializeField] private TMP_Dropdown adsMode;
	[SerializeField] private TMP_Text adsModeText;

	[Space]
	[Header("Другое")]
	public List<CameraViewMode> camViewMode;

	private Resolution[] resolutions;
	private int currentResolutionIndex;

	private FullScreenMode fullScreenMode;
	private UniversalRenderPipelineAsset universalRenderPipeline;

	private void Awake() => instance = this;
	private void Start()
	{
		MemoryOptimizer.instance.CleanMemory(); 

		pov = CVC.GetCinemachineComponent<CinemachinePOV>();
		follow = CVC.GetCinemachineComponent<Cinemachine3rdPersonFollow>();

		universalRenderPipeline = GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset;
		sceneLight = FindObjectsOfType<Light>();
		sceneDetails = FindObjectsOfType<DetailsModel>();
		sceneText = FindObjectsOfType<TMP_Text>();

		if (volumeProfile.TryGet(out colorAdjustments))
		if (volumeProfile.TryGet(out motionBlur))
		if (volumeProfile.TryGet(out depthOfField))

		PopulateResolutionDropdown();
		LoadSettings();

		SetQuality();
		SetFullscreen();
		SetShadowType();
		SetPostProcessing();
		SetGradientEnabled();
		SetMotionBlur();
		SetDepthOfField();
		SetFogSettings();
		SetDetails();
		SetDecore();
		SetVSync();
		SetFPSLock();
		SetPhysics();
		SetViewDistanceSettings();
		SetNeoTXSettings();
		SetJoysticSettings();
		SetViewMode();
		SetSensitivitySettings();
		SetFieldOfViewSettings();
		SetInput();
		SetMemorySettings();
		SetCulling();
		SetCounter();
		SetSmoothness();
		SetAdsModeSettings();
		SetVolume();

		SaveSettings();
		Invoke(nameof(SetVolume), 0.01f);
	}

	#region Settings Funcs
	private void PopulateResolutionDropdown()
	{
		resolution.ClearOptions();

		List<string> options = new List<string>();
			
		resolutions = Screen.resolutions;
		currentResolutionIndex = resolutions.Length - 1;

		for (int i = 0; i < resolutions.Length; i++)
		{
			string option = resolutions[i].width + "x" + resolutions[i].height + " " + (int)resolutions[i].refreshRateRatio.value + "Гц";
			options.Add(option);

			if (resolutions[i].width == Screen.currentResolution.width &&
				resolutions[i].height == Screen.currentResolution.height &&
				resolutions[i].refreshRateRatio.value == Screen.currentResolution.refreshRateRatio.value)
			{
				currentResolutionIndex = i;
			}
		}

		resolution.AddOptions(options);
		resolution.RefreshShownValue();
	}

	public void SetQuality()
	{
		QualitySettings.SetQualityLevel(quality.value);
		universalRenderPipeline = GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset;

		SetDrawDistanceSettings();
		SetShadowDistanceSettings();
		SetAdditionalLights();

		SetRender();
		SetAliasing();
		SetHdrEnabled();

		SetUpscaling();

		qualityText.text = quality.value.ToString();
	}
	
	public async void SetResolution()
	{
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			await SetText();
		 	return;
		}
		
		Resolution _resolution = resolutions[resolution.value];
		Screen.SetResolution(_resolution.width, _resolution.height, fullScreenMode, _resolution.refreshRateRatio);

		resolutionText.text = resolution.value.ToString();
		await SetText();
	}

	private async Task SetText()
	{
		for (int i = 0; i < sceneText.Length; i++)
		{
			sceneText[i].fontSizeMin = 0;
			sceneText[i].fontSizeMax = sceneText[i].fontSize;
			sceneText[i].enableAutoSizing = true;
		}

		await Task.Delay(100);

		for (int i = 0; i < sceneText.Length; i++)
		{
			sceneText[i].enableAutoSizing = false;
		}
	}
	
	public void SetUpscaling()
	{
		universalRenderPipeline.upscalingFilter = (UpscalingFilterSelection)upscaling.value;
		upscalingText.text = upscaling.value.ToString();
	}

	public void SetRender() 
	{
		universalRenderPipeline.renderScale = render.value;
		renderText.text = render.value.ToString();
	}

	public void SetFullscreen() 
	{
		fullScreenMode = (FullScreenMode)window.value;

		Screen.fullScreenMode = fullScreenMode;
		windowText.text = window.value.ToString();

		SetResolution();
	}

	public void SetShadowType()
	{
		if (shadowDistance.value != 0 && shadowType.value != 0)
		{
			cameraData.renderShadows = true;
		}
		else
		{
			cameraData.renderShadows = false;
		}

		for (int i = 0; i < sceneLight.Length; i++)
		{
			sceneLight[i].shadows = (LightShadows)shadowType.value;
		}

		shadowTypeText.text = shadowType.value.ToString();
	}

	public void SetPostProcessing()
	{
		switch (postProcessing.value)
		{
			case 0:
				cameraData.renderPostProcessing = false;
				break;
			case 1:
				cameraData.renderPostProcessing = true;
				break;
		}

		postProcessingText.text = postProcessing.value.ToString();
	}

	public void SetGradientEnabled()
	{
		if (adjustment.value == 0)
		{
			colorAdjustments.active = false;
		}
		else
		{
			colorAdjustments.active = true;
		}

		colorAdjustments.postExposure.Override(brightness.value);
		colorAdjustments.contrast.Override(contrast.value);
		colorAdjustments.saturation.Override(saturation.value);

		gradientText.text = adjustment.value.ToString();
		brightnessText.text = brightness.value.ToString();
		contrastText.text = contrast.value.ToString();
		saturationText.text = saturation.value.ToString();
	}

	public void SetMotionBlur()
	{
		if (motionBlurPower.value <= 0.05f)
		{
			motionBlur.active = false;
		}
		else
		{
			motionBlur.active = true;
		}
		
		motionBlur.intensity.Override(motionBlurPower.value);
		motionBlurPowerText.text = motionBlurPower.value.ToString();
	}

	public void SetDepthOfField()
	{
		if (depthOfFieldRange.value <= 0.05f)
		{
			depthOfField.active = false;
		}
		else
		{
			depthOfField.active = true;
		}

		depthOfField.focusDistance.Override(depthOfFieldRange.value);
		depthOfFieldRangeText.text = depthOfFieldRange.value.ToString();
	}

	public void SetFogSettings()
	{
		if (WeatherManager.instance == null) return;

		switch (fogMode.value)
		{
			case 0 :
				WeatherManager.instance.fogEnabled = false;
				break;
			default:
				WeatherManager.instance.fogEnabled = true;
				WeatherManager.instance.fogMode = (FogMode)fogMode.value;
				break;
		}

		fogModeText.text = fogMode.value.ToString();
		WeatherManager.instance.ChangSettings();
	}

	public void SetDetails()
	{
		switch (details.value)
		{
			case 0:
				for (int i = 0; i < sceneDetails.Length; i++)
				{
					if (sceneDetails[i].meshStandart != null) sceneDetails[i].meshFilter.mesh = sceneDetails[i].meshStandart;
					if (sceneDetails[i].meshRenderer != null) sceneDetails[i].meshRenderer.material = material;
				}
				break;
			case 1:
				for (int i = 0; i < sceneDetails.Length; i++)
				{
					if (sceneDetails[i].meshDetails != null) sceneDetails[i].meshFilter.mesh = sceneDetails[i].meshDetails;
					if (sceneDetails[i].meshRenderer != null) sceneDetails[i].meshRenderer.material = plants;
				}
				break;
		}

		detailsText.text = details.value.ToString();
	}

	public void SetDecore() 
	{
		decorationText.text = decoration.value.ToString();
	}

	public void SetAliasing() 
	{
		cameraData.antialiasing = (AntialiasingMode)aliasingMode.value;
		cameraData.antialiasingQuality = (AntialiasingQuality)aliasingQuality.value;

		switch (aliasingPower.value)
		{
			case 0:
				universalRenderPipeline.msaaSampleCount = 1;
				break;
			case 1:
				universalRenderPipeline.msaaSampleCount = 2;
				break;
			case 2:
				universalRenderPipeline.msaaSampleCount = 4;
				break;
			case 3:
				universalRenderPipeline.msaaSampleCount = 8;
				break;
		}

		aliasingModeText.text = aliasingMode.value.ToString();
		aliasingQualityText.text = aliasingQuality.value.ToString();
		aliasingPowerText.text = aliasingPower.value.ToString();
	}

	public void SetVSync() 
	{
		QualitySettings.vSyncCount = vsync.value;
		vsyncText.text = vsync.value.ToString();
	}

	public void SetFPSLock()
	{
		switch (fpcLock.value)
		{
			case 0:
				Application.targetFrameRate = -1;
				break;
			case 1:
				Application.targetFrameRate = 30;
				break;
			case 2:
				Application.targetFrameRate = 60;
				break;
			case 3:
				Application.targetFrameRate = 120;
				break;
			case 4:
				Application.targetFrameRate = 240;
				break;
		}

		fpcLockText.text = fpcLock.value.ToString();
	}

	public void SetPhysics()
	{
		Time.fixedDeltaTime = physics.value;
		physicsText.text = physics.value.ToString();
	}

	public void SetViewDistanceSettings()
	{
		if (CVC != null)
		{
			CVC.m_Lens.FarClipPlane = viewDisance.value;
		}

		viewDisanceText.text = viewDisance.value.ToString();
	}

	public void SetDrawDistanceSettings()
	{
		QualitySettings.lodBias = drawDistance.value;
		drawDistanceText.text = drawDistance.value.ToString();
	}

	public void SetShadowDistanceSettings()
	{
		universalRenderPipeline.shadowDistance = shadowDistance.value;
		shadowDistanceText.text = shadowDistance.value.ToString();

		if (shadowDistance.value != 0 && shadowType.value != 0)
		{
			cameraData.renderShadows = true;
		}
		else
		{
			cameraData.renderShadows = false;
		}
	}

	public void SetAdditionalLights()
	{
		universalRenderPipeline.maxAdditionalLightsCount = (int)additionalLights.value;
		additionalLightsText.text = additionalLights.value.ToString();
	}

	public void SetHdrEnabled()
	{
		switch (hdr.value)
		{
			case 0:
				universalRenderPipeline.supportsHDR = false;
				break;
			case 1:
				universalRenderPipeline.supportsHDR = true;
				break;
		}

		hdrText.text = hdr.value.ToString();
	}

	public void SetNeoTXSettings() 
	{
		material.SetFloat("_Smoothness", neotxPower.value);
		material.SetFloat("_Metallic", neotxMetal.value);
		
		plants.SetFloat("_Smoothness", neotxPower.value);
		plants.SetFloat("_Metallic", neotxMetal.value);

		neotxPowerText.text = neotxPower.value.ToString();
		neotxMetalText.text = neotxMetal.value.ToString();
	}

	public void SetJoysticSettings()
	{
		if (VariableJoystick.instance == null) return;

		VariableJoystick.instance.SetMode((JoystickType)joystic.value);
		joysticText.text = joystic.value.ToString();
	}

	public void SetViewMode()
	{
		if (follow != null)
		{
			follow.ShoulderOffset = camViewMode[viewMode.value].position;
		}

		viewModeText.text = viewMode.value.ToString();
	}

	public void SetSensitivitySettings()
	{
		if (pov != null) 
		{
			pov.m_HorizontalAxis.m_MaxSpeed = sensitivity.value;
			pov.m_VerticalAxis.m_MaxSpeed = sensitivity.value;
		}

		sensitivityText.text = sensitivity.value.ToString();
	}

	public void SetFieldOfViewSettings()
	{
		if (CVC != null)
		{
			CVC.m_Lens.FieldOfView = fovDisance.value;
		}

		fovDisanceText.text = fovDisance.value.ToString();
	}

	public void SetSmoothness()
	{
		if (follow != null)
		{
			follow.Damping = new Vector3(smoothness.value, smoothness.value, smoothness.value);
		}

		smoothnessText.text = smoothness.value.ToString();
	}

	public void SetInput()
	{
		actionReferenceEsc.action.ApplyBindingOverride(0, "<Keyboard>/" + escInput.text);
		actionReferenceLut.action.ApplyBindingOverride(0, "<Keyboard>/" + lutInput.text);
	}

	public void SetVolume()
	{
		audioMixer.SetFloat("volume", Mathf.Log10(volume.value) * 20);
		chatMixer.SetFloat("volume", Mathf.Log10(chatVolume.value) * 20);

		volumeText.text = volume.value.ToString();
		chatVolumeText.text = chatVolume.value.ToString();

		if (volume.value <= 0.0001f)
		{
			AudioListener.pause = true;
		}
		else
		{
			AudioListener.pause = false;
		}
	}

	public void SetMemorySettings()
	{
		switch (memory.value)
		{
			case 0:
				MemoryOptimizer.instance.OffClear();
				break;
			case 1:
				MemoryOptimizer.instance.OnClear(60f);
				break;
			case 2:
				MemoryOptimizer.instance.OnClear(120f);
				break;
			case 3:
				MemoryOptimizer.instance.OnClear(240f);
				break;
			case 4:
				MemoryOptimizer.instance.OnClear(480f);
				break;
		}

		memoryText.text = memory.value.ToString();
	}

	public void SetCulling()
	{
		switch (culling.value)
		{
			case 0:
				mCamera.useOcclusionCulling = false;
				break;
			case 1:
				mCamera.useOcclusionCulling = true;
				break;
		}

		cullingText.text = culling.value.ToString();
	}

	public void SetCounter()
	{
		switch (counter.value)
		{
			case 0:
				optimizeCounter.gameObject.SetActive(false);
				break;
			case 1:
				optimizeCounter.gameObject.SetActive(true);
				break;
		}

		counterText.text = counter.value.ToString();
	}

	public void SetAdsModeSettings() 
	{
		adsModeText.text = adsMode.value.ToString();
	}

	public void SaveSettings()
	{
		PlayerPrefs.SetInt("QualitySettings", quality.value);
		PlayerPrefs.SetFloat("Render", render.value);
		PlayerPrefs.SetInt("FogMode", fogMode.value);
		PlayerPrefs.SetInt("Details", details.value);
		PlayerPrefs.SetInt("Decoration", decoration.value);
		PlayerPrefs.SetFloat("ViewDistance", viewDisance.value);
		PlayerPrefs.SetFloat("DrawDistance", drawDistance.value);
		PlayerPrefs.SetInt("ShadowType", shadowType.value);
		PlayerPrefs.SetFloat("ShadowDistance", shadowDistance.value);
		PlayerPrefs.SetFloat("AdditionalLights", additionalLights.value);

		PlayerPrefs.SetInt("PostProcessing", postProcessing.value);
		PlayerPrefs.SetInt("Adjustment", adjustment.value);
		PlayerPrefs.SetFloat("Brightness", brightness.value);
		PlayerPrefs.SetFloat("Contrast", contrast.value);
		PlayerPrefs.SetFloat("Saturation", saturation.value);
		PlayerPrefs.SetFloat("MotionBlurPower", motionBlurPower.value);
		PlayerPrefs.SetFloat("DepthOfFieldRange", depthOfFieldRange.value);

		PlayerPrefs.SetFloat("NeotxPower", neotxPower.value);
		PlayerPrefs.SetFloat("NeotxMetal", neotxMetal.value);

		PlayerPrefs.SetInt("Resolution", resolution.value);
		PlayerPrefs.SetInt("Upscaling", upscaling.value);
		PlayerPrefs.SetInt("ScreenMode", window.value);
		PlayerPrefs.SetInt("VSync", vsync.value);
		PlayerPrefs.SetInt("FPSLock", fpcLock.value);

		PlayerPrefs.SetInt("HDR", hdr.value);
		PlayerPrefs.SetInt("AliasingMode", aliasingMode.value);
		PlayerPrefs.SetInt("AliasingQuality", aliasingQuality.value);
		PlayerPrefs.SetInt("AliasingPower", aliasingPower.value);

		PlayerPrefs.SetInt("JoysticSettings", joystic.value);
		PlayerPrefs.SetInt("ViewMode", viewMode.value);
		PlayerPrefs.SetFloat("Sensitivity", sensitivity.value);
		PlayerPrefs.SetFloat("FovDistance", fovDisance.value);
		PlayerPrefs.SetFloat("Smoothness", smoothness.value);
		PlayerPrefs.SetString("EscInput", escInput.text);
		PlayerPrefs.SetString("LutInput", lutInput.text);

		PlayerPrefs.SetFloat("Volume", volume.value);
		PlayerPrefs.SetFloat("ChatVolume", chatVolume.value);

		PlayerPrefs.SetFloat("Physics", physics.value);
		PlayerPrefs.SetInt("Memory", memory.value);
		PlayerPrefs.SetInt("Culling", culling.value);
		PlayerPrefs.SetInt("Counter", counter.value);
		PlayerPrefs.SetInt("AdsMode", adsMode.value);
	}

	public void LoadSettings()
	{
		if (PlayerPrefs.HasKey("QualitySettings")) quality.value = PlayerPrefs.GetInt("QualitySettings"); else quality.value = 2;
		if (PlayerPrefs.HasKey("Render")) render.value = PlayerPrefs.GetFloat("Render"); else render.value = 1f;
		if (PlayerPrefs.HasKey("FogMode")) fogMode.value = PlayerPrefs.GetInt("FogMode"); else fogMode.value = 2;
		if (PlayerPrefs.HasKey("Details")) details.value = PlayerPrefs.GetInt("Details"); else details.value = 0;
		if (PlayerPrefs.HasKey("Decoration")) decoration.value = PlayerPrefs.GetInt("Decoration"); else decoration.value = 1;
		if (PlayerPrefs.HasKey("ViewDistance")) viewDisance.value = PlayerPrefs.GetFloat("ViewDistance"); else viewDisance.value = 400f;
		if (PlayerPrefs.HasKey("DrawDistance")) drawDistance.value = PlayerPrefs.GetFloat("DrawDistance"); else drawDistance.value = 2f;
		if (PlayerPrefs.HasKey("ShadowType")) shadowType.value = PlayerPrefs.GetInt("ShadowType"); else shadowType.value = 1;
		if (PlayerPrefs.HasKey("ShadowDistance")) shadowDistance.value = PlayerPrefs.GetFloat("ShadowDistance"); else shadowDistance.value = 100f;
		if (PlayerPrefs.HasKey("AdditionalLights")) additionalLights.value = PlayerPrefs.GetFloat("AdditionalLights"); else additionalLights.value = 8f;

		if (PlayerPrefs.HasKey("PostProcessing")) postProcessing.value = PlayerPrefs.GetInt("PostProcessing"); else postProcessing.value = 0;
		if (PlayerPrefs.HasKey("Adjustment")) adjustment.value = PlayerPrefs.GetInt("Adjustment"); else adjustment.value = 1;
		if (PlayerPrefs.HasKey("Brightness")) brightness.value = PlayerPrefs.GetFloat("Brightness"); else brightness.value = 0.35f;
		if (PlayerPrefs.HasKey("Contrast")) contrast.value = PlayerPrefs.GetFloat("Contrast"); else contrast.value = 15f;
		if (PlayerPrefs.HasKey("Saturation")) saturation.value = PlayerPrefs.GetFloat("Saturation"); else saturation.value = 15f;
		if (PlayerPrefs.HasKey("MotionBlurPower")) motionBlurPower.value = PlayerPrefs.GetFloat("MotionBlurPower"); else motionBlurPower.value = 0f;
		if (PlayerPrefs.HasKey("DepthOfFieldRange")) depthOfFieldRange.value = PlayerPrefs.GetFloat("DepthOfFieldRange"); else depthOfFieldRange.value = 2.5f;

		if (PlayerPrefs.HasKey("NeotxPower")) neotxPower.value = PlayerPrefs.GetFloat("NeotxPower"); else neotxPower.value = 0.35f;
		if (PlayerPrefs.HasKey("NeotxMetal")) neotxMetal.value = PlayerPrefs.GetFloat("NeotxMetal"); else neotxMetal.value = 0.1f;

		if (PlayerPrefs.HasKey("Resolution")) resolution.value = PlayerPrefs.GetInt("Resolution"); else resolution.value = currentResolutionIndex;
		if (PlayerPrefs.HasKey("Upscaling")) upscaling.value = PlayerPrefs.GetInt("Upscaling"); else upscaling.value = 0;
		if (PlayerPrefs.HasKey("ScreenMode")) window.value = PlayerPrefs.GetInt("ScreenMode"); else window.value = 1;
		if (PlayerPrefs.HasKey("VSync")) vsync.value = PlayerPrefs.GetInt("VSync"); else vsync.value = 0;
		if (PlayerPrefs.HasKey("FPSLock")) fpcLock.value = PlayerPrefs.GetInt("FPSLock"); else fpcLock.value = 2;

		if (PlayerPrefs.HasKey("HDR")) hdr.value = PlayerPrefs.GetInt("HDR"); else hdr.value = 0;
		if (PlayerPrefs.HasKey("AliasingMode")) aliasingMode.value = PlayerPrefs.GetInt("AliasingMode"); else aliasingMode.value = 0;
		if (PlayerPrefs.HasKey("AliasingQuality")) aliasingQuality.value = PlayerPrefs.GetInt("AliasingQuality"); else aliasingQuality.value = 0;
		if (PlayerPrefs.HasKey("AliasingPower")) aliasingPower.value = PlayerPrefs.GetInt("AliasingPower"); else aliasingPower.value = 0;
		
		if (PlayerPrefs.HasKey("JoysticSettings")) joystic.value = PlayerPrefs.GetInt("JoysticSettings"); else joystic.value = 0;
		if (PlayerPrefs.HasKey("Sensitivity")) sensitivity.value = PlayerPrefs.GetFloat("Sensitivity"); else sensitivity.value = 1.75f;
		if (PlayerPrefs.HasKey("ViewMode")) viewMode.value = PlayerPrefs.GetInt("ViewMode"); else viewMode.value = 1;
		if (PlayerPrefs.HasKey("FovDistance")) fovDisance.value = PlayerPrefs.GetFloat("FovDistance"); else fovDisance.value = 90f;
		if (PlayerPrefs.HasKey("Smoothness")) smoothness.value = PlayerPrefs.GetFloat("Smoothness"); else smoothness.value = 0f;
		if (PlayerPrefs.HasKey("EscInput")) escInput.text = PlayerPrefs.GetString("EscInput"); else escInput.text = "Escape";
		if (PlayerPrefs.HasKey("LutInput")) lutInput.text = PlayerPrefs.GetString("LutInput"); else lutInput.text = "E";

		if (PlayerPrefs.HasKey("Volume")) volume.value = PlayerPrefs.GetFloat("Volume"); else volume.value = 0.8f;
		if (PlayerPrefs.HasKey("ChatVolume")) chatVolume.value = PlayerPrefs.GetFloat("ChatVolume"); else chatVolume.value = 1f;

		if (PlayerPrefs.HasKey("Physics")) physics.value = PlayerPrefs.GetFloat("Physics"); else physics.value = 0.02f;
		if (PlayerPrefs.HasKey("Memory")) memory.value = PlayerPrefs.GetInt("Memory"); else memory.value = 0;
		if (PlayerPrefs.HasKey("Culling")) culling.value = PlayerPrefs.GetInt("Culling"); else culling.value = 1;
		if (PlayerPrefs.HasKey("Counter")) counter.value = PlayerPrefs.GetInt("Counter"); else counter.value = 0;
		if (PlayerPrefs.HasKey("AdsMode")) adsMode.value = PlayerPrefs.GetInt("AdsMode"); else adsMode.value = 0;
	}
	#endregion

	public void DeliteSettings() => PlayerPrefs.DeleteAll();

	public void DeliteSave() => BinarySavingSystem.DeleteSave();
}

[System.Serializable]
public class CameraViewMode
{
	public Vector3 position;
}