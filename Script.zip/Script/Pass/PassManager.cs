using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PassManager : MonoBehaviour
{
    public static PassManager instance;

    [Space]
    [Header("Текст")]
    public TMP_Text PassNameText;
    public TMP_Text PassMoneyText;
    public TMP_Text PassLvlText;

    public TMP_Text PassUpdatePriceText;

    [Space]
    [Header("Награда")]
    private GameObject NextRewardObj;
    private PassItemList NextPassItem;

    [Space]
    [Header("Важное")]
    public GameObject PassItemPrefab;
    public Transform PassContent;

    [Space]
    [Header("Лист")]
    public List<PassList> Pass;

    private void Awake() => instance = this;

    private void Start()
    {
        ChangPass();
    }

    public void ChangPass()
    {
        for (int i = 0; i < PassContent.childCount; i++) Destroy(PassContent.GetChild(i).gameObject);

        foreach (PassList pass in Pass)
        {
            if (pass.PassName == DataSaveLoad.instance.data.passName)
            {
                PassNameText.text = pass.PassName;

                foreach (PassItemList passItemList in pass.PassItemList)
                {
                    if (passItemList.ItemLvl > DataSaveLoad.instance.data.passLvl)
                    {
                        PassItemSpawner(passItemList);
                    }
                }

                break;
            }
        }
    }

    public void PassItemSpawner(PassItemList passItemList)
    {
        PassItem passItem = Instantiate(PassItemPrefab, PassContent).GetComponent<PassItem>();

        if (passItemList.ItemLvl == DataSaveLoad.instance.data.passLvl + 1)
        {
            NextPassItem = passItemList;
            NextRewardObj = passItem.gameObject;

            PassUpdatePriceText.text = NextPassItem.Price.ToString();
        }

        passItem.PassItemImage.sprite = passItemList.ItemImage;

        passItem.PassNameItems.text = passItemList.ItemName;
        passItem.PassItemLvl.text = passItemList.ItemLvl.ToString();
    }

    public void UpdatePass()
    {
        if (NextPassItem == null) 
        {
            PassUpdatePriceText.text = "";
            return;
        }

        if(DataSaveLoad.instance.data.rockValue >= NextPassItem.Price)
        {
            DataSaveLoad.instance.data.rockValue -= NextPassItem.Price;
            DataSaveLoad.instance.data.passLvl = NextPassItem.ItemLvl;

            PassMoneyText.text = DataSaveLoad.instance.data.rockValue.ToString();
            PassLvlText.text = DataSaveLoad.instance.data.passLvl.ToString();

            ClaimReward();
        }
    }

    public void ClaimReward()
    {
        switch(NextPassItem.BonusTypePass)
        {
            case RewardType.Wood :
                DataSaveLoad.instance.data.reditValue += (Random.Range(256, 512));
                break;
            case RewardType.Rock :
                DataSaveLoad.instance.data.reditValue += (Random.Range(128, 256));
                break;
            case RewardType.Gold :
                DataSaveLoad.instance.data.reditValue += (Random.Range(64, 128));
                break;
            case RewardType.Diamond :
                DataSaveLoad.instance.data.reditValue += (Random.Range(32, 64));
                break;
            case RewardType.Ametist :
                DataSaveLoad.instance.data.reditValue += (Random.Range(16, 32));
                break;
            case RewardType.Redit :
                DataSaveLoad.instance.data.reditValue += (Random.Range(8, 16));
                break;
            case RewardType.Izum :
                DataSaveLoad.instance.data.izumValue += (Random.Range(4, 8));
                break;
            case RewardType.Core :
                DataSaveLoad.instance.data.coreValue += (Random.Range(2, 4));
                break;
            case RewardType.Neolit :
                DataSaveLoad.instance.data.neolitValue += (Random.Range(1, 2));
                break;
            case RewardType.CharacterSkin :
                DataSaveLoad.instance.data.inventorySkin[DataSaveLoad.instance.data.inventorySkin.Length + 1] = NextPassItem.ItemName;
                break;
            case RewardType.ItemSkin :
                DataSaveLoad.instance.data.inventorySkin[DataSaveLoad.instance.data.inventorySkin.Length + 1] = NextPassItem.ItemName;
                break;
        }
    }

    public void NewPassSetter()
    {
        DataSaveLoad.instance.data.passLvl = 0;
        PassLvlText.text = "0";

        //DataSaveLoad.instance.data.passName = latestPass;
    }
}

[System.Serializable]
public class PassList
{
    [Space]
    [Header("Данные")]
    public string PassName;
    public bool PassComplite;
    public List<PassItemList> PassItemList;
}

[System.Serializable]
public class PassItemList
{
    [Space]
    [Header("Данные")]
    public string ItemName;

    public int ItemLvl;

    [Space]
    [Header("Визуал")]
    public Sprite ItemImage;
    public int Price;

    [Space]
    [Header("Тип награды")]
    public RewardType BonusTypePass;
}