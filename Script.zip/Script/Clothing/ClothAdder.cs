using System.Collections.Generic;
using UnityEngine;

public class ClothAdder : MonoBehaviour //Ваш скрипт должен иметь название "ClothAdder" 
{
    public static ClothAdder instance;

    [Space]
    public Transform[] allArmorClothes;
    public Transform allBackpackClothes;
    public Transform allShieldClothes;

    [Space]
    public InventorySlot armorSlot;
    public InventorySlot backpackSlot;
    public InventorySlot shieldSlot;

    public Armor armor;
    public Backpack backpack;
    public Shield shield;

    private void Awake() => instance = this;

    public void UpdateClothes()
    {
        if (armorSlot.item != null && armorSlot.durability >= 1) // для брони
        {
            for (int ii = 0; ii < allArmorClothes.Length; ii++)
            {
                for (int i = 0; i < allArmorClothes[ii].childCount; i++)
                {
                    GameObject clothObj = allArmorClothes[ii].GetChild(i).gameObject;

                    if (armorSlot.item.inHandName == clothObj.name)
                    {
                        PhotonSetManager.instance.SetArmor(clothObj.name, null);

                        clothObj.SetActive(true);
                    }
                    else
                    {
                        clothObj.SetActive(false);
                    }
                }
            }
        }
        else 
        {
            for (int ii = 0; ii < allArmorClothes.Length; ii++)
            {
                for (int i = 0; i < allArmorClothes[ii].childCount; i++)
                {
                    allArmorClothes[ii].GetChild(i).gameObject.SetActive(false);
                }
            }

            PhotonSetManager.instance.SetArmor(" ", null);
        }
        
        if (backpackSlot.item != null && backpackSlot.durability >= 1) // для рюкзаков
        {
            for (int i = 0; i < allBackpackClothes.childCount; i++)
            {
                GameObject clothObj = allBackpackClothes.GetChild(i).gameObject;

                if (backpackSlot.item != null && backpackSlot.item.inHandName == clothObj.name )
                {
                    PhotonSetManager.instance.SetBackpack(clothObj.name, null);

                    clothObj.SetActive(true);
                }
                else
                {
                    clothObj.SetActive(false);
                }
            }
        }
        else
        {
            for (int i = 0; i < allBackpackClothes.childCount; i++)
            {
                allBackpackClothes.GetChild(i).gameObject.SetActive(false);
            }

            PhotonSetManager.instance.SetBackpack(" ", null);
        }
        
        if (shieldSlot.item != null && shieldSlot.durability >= 1) // для щитов
        {
            for (int i = 0; i < allShieldClothes.childCount; i++)
            {
                GameObject clothObj = allShieldClothes.GetChild(i).gameObject; 

                if (shieldSlot.item.inHandName == clothObj.name)
                {
                    PhotonSetManager.instance.SetShield(clothObj.name, null);

                    clothObj.SetActive(true);
                }
                else
                {
                    clothObj.SetActive(false);
                }
            }
        }
        else 
        {
            for (int i = 0; i < allShieldClothes.childCount; i++)
            {
                allShieldClothes.GetChild(i).gameObject.SetActive(false);
            }

            PhotonSetManager.instance.SetShield(" ", null);
        }

        ArmorStats.instance.ChangStats();
    }
}