using UnityEngine;
using UnityEngine.UI;

public class FillCraftItemDetails : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Текущая информация о крафте")]
    public CraftScriptableObject currentCraftItem;

    [Space]
    public Image image;
    public Sprite nullImage;
    public bool verstacComplite;

    public void FillItemDetails() //новая
    {
        if (currentCraftItem.craftType == CraftType.Buildings)
        {
            CraftManager.instance.buildingBtn.gameObject.SetActive(true);
            CraftQueueManager.instance.craftAmountInputField.text = "1";
        }
        else
        {
            CraftManager.instance.buildingBtn.gameObject.SetActive(false);
        }

        InventoryManager.instance.craftView.SetActive(true);
        InventoryManager.instance.detailsPanel.SetActive(false);
        InventoryManager.instance.chatPanel.SetActive(false);

        CraftManager.instance.currentCraftItem = this;
        
        CraftManager.instance.craftItemName.text = currentCraftItem.finalCraft.name;
        CraftManager.instance.craftItemDescription.text = currentCraftItem.finalCraft.itemDescription;
        CraftManager.instance.craftItemTime.text = "Время крафта " + currentCraftItem.craftTime;
        CraftManager.instance.craftItemImage.sprite = currentCraftItem.finalCraft.icon;

        bool canCraft = true;

        for (int i = 0; i < CraftManager.instance.allResDetails.Count; i++)
        {
            CraftResourceDetails crd = CraftManager.instance.allResDetails[i];

            crd.itemTypeText.text = "";
            crd.totalText.text = "";

            crd.itemImage.sprite = nullImage;
            crd.compliteImage.color = crd.disableColor;
        }

        for (int i = 0; i < currentCraftItem.craftResources.Count; i++)
        {
            CraftResourceDetails crd = CraftManager.instance.allResDetails[i];

            crd.itemTypeText.text = currentCraftItem.craftResources[i].craftObject.itemName;
            crd.itemImage.sprite = currentCraftItem.craftResources[i].craftObject.icon;

            int totalAmount = currentCraftItem.craftResources[i].craftObjectAmount * int.Parse(CraftQueueManager.instance.craftAmountInputField.text);
            crd.totalText.text = totalAmount.ToString();
            
            int resourceAmount = 0;

            foreach (InventorySlot slot in InventoryManager.instance.slots)
            {
                if (slot.item == null) continue;

                if (slot.item.itemName == currentCraftItem.craftResources[i].craftObject.itemName) resourceAmount += slot.amount;
            }

            if (resourceAmount < totalAmount) 
            {
                canCraft = false;
            }
            else
            {
                crd.compliteImage.color = crd.enebleColor;
            }
        }

        if (canCraft) 
        {
            CraftManager.instance.craftBtn.interactable = true;
            CraftManager.instance.buildingBtn.interactable = true;
        }
        else 
        {
            CraftManager.instance.craftBtn.interactable = false;
            CraftManager.instance.buildingBtn.interactable = false;
        }
        
        CraftQueueManager.instance.currentCraftItem = currentCraftItem;
    }
}
