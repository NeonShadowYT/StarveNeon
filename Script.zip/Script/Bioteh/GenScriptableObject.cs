using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "Bioteh", menuName = "Neon Imperium/Bioteh/New Gen")]
public class GenScriptableObject : ScriptableObject
{
    [Space]
    [Header("Настройки гена")]
    public string NameGen;
    public string Descriphen;

    [Space]
    public Sprite icon;

    [Space]
    public float RegenPlus = 1f;
    public float FoodPlus = 1f; 
    public float WaterPlus = 1f;
    public float ColdPlus = 1f;
    public float HealthPlus = 1f;
    public float RazbrosPlus = 1f;
    public float DamagePlus = 1f; 
    public float AdColdPlus = 1f;
    public float SnowColdPlus = 1f;
    public float NightSpeed = 1f;
    public float DaySpeed = 1f;
    public float JumpPlus = 1f;
    public float NoArmorSpeed = 1f;
    public float ArmorSpeed = 1f;
    public float MyPlants = 1f;
    public float PetsPlus = 1f;
    public float TimeWeb = 1f;
    public float DamageBlood = 1f;
    public float CritPlus = 1f;
    public float CritDamage = 1f;

    public int NaturalColdArmor = 0;

    [Space]
    public int Complexity = 1;
    public int Metabalizm;
}
