using UnityEngine;

public enum TableType{ Verstac, Outing, Storage, Building, Furnace, Fraction }
public class TableManager : MonoBehaviour
{
    public static TableManager instance;
    [HideInInspector] public Table currentTable;

    private void Awake() => instance = this;

    public void TableFunction(Table _table)
    {
        InventoryManager.instance.EditCurcorOn();
        currentTable = _table;

        switch (_table.tableType)
        {
            case TableType.Verstac:
                VerstacManager.instance.Function(_table);
                break;
            case TableType.Outing:
                OutingManager.instance.Function(_table);
                break;
            case TableType.Storage:
                StorageManager.instance.Function(_table);
                break;
            case TableType.Furnace:
                break;
            case TableType.Fraction:
                FractionManager.instance.Function(_table);
                break;
        }
    }

    public void TableClose()
    {
        currentTable = null;

        FractionManager.instance.Close();
        VerstacManager.instance.Close();
        StorageManager.instance.Close();
        OutingManager.instance.Close();
    }
}