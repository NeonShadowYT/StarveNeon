using UnityEngine;
using System.Threading.Tasks;

public class MemoryOptimizer : MonoBehaviour
{
    public static MemoryOptimizer instance;

    private void Awake() => instance = this;

    public void OnClear(float interval)
    {
        // Начинаем повторяющиеся вызовы очистки памяти
        InvokeRepeating(nameof(CleanMemory), interval, interval);
    }

    public void OffClear()
    {
        // Заканчиваем повторяющиеся вызовы очистки памяти
        CancelInvoke(nameof(CleanMemory));
    }

    public async void CleanMemory()
    {
        // Асинхронно вызываем сборку мусора
        await Task.Run(() => System.GC.Collect());

        // Выгружаем неиспользуемые ресурсы
        Resources.UnloadUnusedAssets();
    }
}