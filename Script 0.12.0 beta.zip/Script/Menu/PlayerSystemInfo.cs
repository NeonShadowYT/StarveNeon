using UnityEngine.UI;
using UnityEngine;
using TMPro;
using System;
using System.Globalization;

public class PlayerSystemInfo : MonoBehaviour
{
    [Space]
    [Header("Характеристики")]
    [SerializeField] private TMP_Text deviceModelInfo; //устройство
    [SerializeField] private TMP_Text operatingSystemInfo; //система

    [Header("Видеокарта")]
    [SerializeField] private TMP_Text graphicsDeviceInfo; //видеокарта
    [SerializeField] private TMP_Text graphicsMemoryInfo; //мб видеопамяти

    [Header("Процессор")]
    [SerializeField] private TMP_Text processorTypeInfo; //процессор
    [SerializeField] private TMP_Text processorBitInfo; //архиектура процессора
    [SerializeField] private TMP_Text processorCountInfo; //количество ядер
    [SerializeField] private TMP_Text processorFrequencyInfo; //частота процессора

    [Header("Оперативка")]
    [SerializeField] private TMP_Text systemMemoryInfo; //мб оперативки

    [Header("Поддержка")]
    [SerializeField] private TMP_Text supportsRayTracingInfo; //RTX
    [SerializeField] private TMP_Text hdrDisplaySupportFlagsInfo; //HDR
    [SerializeField] private TMP_Text supportsGyroscopeInfo; //гироскоп
    [SerializeField] private TMP_Text supportsAccelerometerInfo; //акселерометр
    [SerializeField] private TMP_Text supportsVibrationInfo; //вибрация

    public void InfoButton()
    {
        deviceModelInfo.text = SystemInfo.deviceModel;
        operatingSystemInfo.text = SystemInfo.operatingSystem;

        graphicsDeviceInfo.text = SystemInfo.graphicsDeviceName;
        graphicsMemoryInfo.text = SystemInfo.graphicsMemorySize.ToString() + " Мб";

        processorTypeInfo.text = SystemInfo.processorType;

        if (CultureInfo.InvariantCulture.CompareInfo.IndexOf(SystemInfo.processorType, "ARM", CompareOptions.IgnoreCase) >= 0)
        {
            if (Environment.Is64BitProcess) processorBitInfo.text = "ARM64";
            else processorBitInfo.text = "ARM";
        }
        else
        {
            if (Environment.Is64BitProcess) processorBitInfo.text = "x86_64";
            else processorBitInfo.text = "x86";
        }

        processorCountInfo.text = SystemInfo.processorCount.ToString();
        processorFrequencyInfo.text = SystemInfo.processorFrequency.ToString();

        systemMemoryInfo.text = SystemInfo.systemMemorySize.ToString() + " Мб";

        if (SystemInfo.supportsRayTracing) supportsRayTracingInfo.text = "Поддерживается";
        else supportsRayTracingInfo.text = "Не поддерживается";

        if (SystemInfo.hdrDisplaySupportFlags != HDRDisplaySupportFlags.None) hdrDisplaySupportFlagsInfo.text = "Поддерживается";
        else hdrDisplaySupportFlagsInfo.text = "Не поддерживается";

        if (SystemInfo.supportsGyroscope) supportsGyroscopeInfo.text = "Поддерживается";
        else supportsGyroscopeInfo.text = "Не поддерживается";

        if (SystemInfo.supportsAccelerometer) supportsAccelerometerInfo.text = "Поддерживается";
        else supportsAccelerometerInfo.text = "Не поддерживается";

        if (SystemInfo.supportsVibration) supportsVibrationInfo.text = "Поддерживается";
        else supportsVibrationInfo.text = "Не поддерживается";
    }
}
