using UnityEngine;

public class Shield : MonoBehaviour
{
    public ClothAdder clothAdder;

    [Space]
    [Header("Характеристики")]
    [Range(0, 1), Tooltip("Насколько эффективно щит снижает урон")] public float resistance;
    [Range(0, 10f), Tooltip("Время, необходимое для восстановления щита")] public float recharges;

    public bool recharg;

    private void OnEnable()
    {
        if (clothAdder == null) return;

        clothAdder.shield = this;
        StartRecharges();
    }

    public void StartRecharges()
    {
        recharg = true;
        Invoke(nameof(EndRecharges), recharges);
    }

    public void EndRecharges()
    {
        recharg = false;
    }
}