using UnityEngine;

public enum AchievementType { Resource, Mob, Survival }

[CreateAssetMenu(fileName = "Achievement", menuName = "Neon Imperium/Achievement/New Achievement")]
public class AchievementScriptableObject : ScriptableObject
{
    public ItemScriptableObject itemScriptableObject;
    public MobScriptableObject mobScriptableObject;

    [Space]
    public AchievementType achievementType;
    public Sprite achievementIcon;

    [Space]
    public RewardType rewardType;
    public Sprite rewardIcon;

    [Space]
    public int rewardAmount;
    public float progressAmount;

    [Space]
    public int IdGJ;
}
