using UnityEngine;
using System.Collections.Generic;

[HelpURL("https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg")]
public class MobStats : MonoBehaviour
{
    public MobScriptableObject mobScriptableObject;

    [HideInInspector] public Transform mTransform;
    [HideInInspector] public AIManager aIManager;
    [HideInInspector] public Animator anim;

    [Space]
    [Header("Основное")]
    public float _health;
    public float health
    {
        get { return _health; }
        set
        {
            _health = value;

            if (aIManager.fractionNPS != null)
            {
                InventoryManager.instance.itemObject.Remove(gameObject);
            }

            if (_health <= 0)
            {
                OnDeath();
            }
        }
    }

    [Space]
    [Header("Другое")]
    public bool armor;

    [HideInInspector]
    public bool playerAttackeZone;
    public EquipEffect currentEffect;

    public void Startap()
    {
        aIManager = GetComponent<AIManager>();
        anim = GetComponent<Animator>();
        mTransform = transform;

        OnRegen();
    }

    public void OnRegen()
    {
        switch (DataSaveLoad.instance.data.complexity)
        {
            case 0:
                health = mobScriptableObject.Health * 0.75f;
                break;
            case 1:
                health = mobScriptableObject.Health;
                break;
            case 2:
                health = mobScriptableObject.Health * 1.25f;
                break;
            case 3:
                health = mobScriptableObject.Health * 1.5f;
                break;
        }
    }

    public void TakeDamage(float damage, EquipEffect effect)
    {
        health -= damage;
        currentEffect = effect;

        if (aIManager.fractionNPS != null)
        {
            switch (aIManager.fractionNPS.NPSFraction.fractionRace)
            {
                case FractionRace.Ksencse:
                    FractionManager.instance.ksenoRepAmount -= 10;
                    break;
                case FractionRace.GC:
                    FractionManager.instance.goldenRepAmount -= 15;
                    break;
                case FractionRace.Oboroten:
                    FractionManager.instance.oborotRepAmount -= 5;
                    break;
                case FractionRace.Stasy:
                    FractionManager.instance.stasyRepAmount -= 10;
                    break;
            }
        }

        if (health <= mobScriptableObject.Health * 0.75f)
        {
            if (aIManager.DamageForAgreAI)
            {
                aIManager.AgreAI = true;
            }
            else
            {
                aIManager.PanicAI = true;
            }
        }
    }

    public void OnAttacke()
    {
        if (playerAttackeZone == false) return;

        float damage = Random.Range(-5, 5);

        switch (DataSaveLoad.instance.data.complexity)
        {
            case 0:
                damage += mobScriptableObject.Damage * 0.75f;
                break;
            case 1:
                damage += mobScriptableObject.Damage;
                break;
            case 2:
                damage += mobScriptableObject.Damage * 1.25f;
                break;
            case 3:
                damage += mobScriptableObject.Damage * 1.5f;
                break;
        }

        if (aIManager.fractionNPS != null)
        {
            damage += aIManager.fractionNPS.mEquipStats.damageValue;
        }

        CustomCharacterController.instance.TakeDamage(damage, mobScriptableObject.damageEffect, mobScriptableObject.chanceEffect, mobScriptableObject.crit, mobScriptableObject.critModifer, mobScriptableObject.weak, mobScriptableObject.weakModifer);
    }

    private void OnDeath()
    {
        aIManager.AIStop();

        if (anim != null)
        {
            anim.SetBool("Death", true);
        }
        else
        {
            OnDestroys();
        }
    }

    private void OnRespawn()
    {
        anim.SetBool("Death", false);
        aIManager.death = false;
    }

    private void OnDestroys()
    {
        GlobalInvoker.instance.aiLogicUpdate.Remove(aIManager);
        GlobalInvoker.instance.aiAnimUpdate.Remove(aIManager);
        GlobalInvoker.instance.aiMoveUpdate.Remove(aIManager);

        anim.SetBool("Damage", false);
        anim.SetBool("ViewTarget", false);
        anim.SetFloat("Speed", 0f);
        anim.SetFloat("Target", 0f);

        for (int i = 0; i < QuastGame.instance.quastItemList.Count; i++)
        {
            if (QuastGame.instance.quastItemList[i].quastScriptableObject.QuastMob == mobScriptableObject)
            {
                QuastGame.instance.quastItemList[i].PassItemProgress.value += 1;

                if (QuastGame.instance.quastItemList[i].PassItemProgress.value == QuastGame.instance.quastItemList[i].PassItemProgress.maxValue)
                {
                    QuastGame.instance.AddQuastReward(i);
                }
            }
        }
        
        foreach (LutList lut in mobScriptableObject.LutList)
        {
            InventoryManager.instance.AddItem(null, lut.Item, lut.Amount, lut.Item.maximumDurability, 0);
        }

        OnRegen();

        if (aIManager.DamageForAgreAI)
        {
            aIManager.AgreAI = false;
        }
        else
        {
            aIManager.PanicAI = false;
        }

        aIManager.aiCollider.SetupComponents(false);

        playerAttackeZone = false;
        aIManager.death = true;

        if (aIManager.fractionNPS != null)
        {
            aIManager.aiCollider.mobCollider[2].radius -= aIManager.fractionNPS.mEquipStats.distanceValue;
            aIManager.fractionNPS.Startnps();
        }

        if (ArenaManager.instance == null)
        {
            Invoke(nameof(OnRespawn), mobScriptableObject.respawnTime);
        }
        else
        {
            ArenaManager.instance.wave[0].enemy.Remove(aIManager);

            if (ArenaManager.instance.wave[0].enemy.Count == 0)
            {
                ArenaManager.instance.wave.Remove(ArenaManager.instance.wave[0]);
                ArenaManager.instance.WaitWave();
            }

            gameObject.SetActive(false);
        }
    }
}