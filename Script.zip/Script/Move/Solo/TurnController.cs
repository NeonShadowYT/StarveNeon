using UnityEngine;

public class TurnController : MonoBehaviour //https://www.youtube.com/c/maximple
{
    public static TurnController instance;

    [Space]
    public Animator _animator;
    private float slowMouseX;

    private void Awake() => instance = this;

    public void TurnUpdate()
    {
        slowMouseX = Mathf.Lerp(slowMouseX, Input.GetAxis("Mouse X"), 10 * Time.deltaTime);
        _animator.SetFloat("MouseX", slowMouseX);
    }
}
