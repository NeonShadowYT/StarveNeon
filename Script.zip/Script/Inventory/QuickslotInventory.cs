using UnityEngine;

public class QuickslotInventory : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public static QuickslotInventory instance;
    public AchievementManager achievementManager;

    [Space]
    public Animator anim;
    public AudioSource audioSource;

    [Space]
    [Header("Иконка слота")]
    public Color selectedColor;
    public Color notSelectedColor;

    [Space]
    [Header("Масивы")]
    public InventorySlot[] quickSlot;
    public Transform allWeapons;

    [Space]
    [Header("Текущий слот")]
    public int currentQuickSlot = 0;
    private int currentSmenaSlot = -1;

    [Space]
    [Header("Кеширование")]
    private float _scrollWheel;
    private float scrollWheel
    {
        get{ return _scrollWheel; }
        set
        {
            _scrollWheel = value;

            if (_scrollWheel > 0.1)
            {
                quickSlot[currentQuickSlot].iconBG.color = notSelectedColor;

                if (currentQuickSlot >= quickSlot.Length - 1) currentQuickSlot = 0; else currentQuickSlot++;

                SelectSlot();
            }
            else if (_scrollWheel < -0.1)
            {
                quickSlot[currentQuickSlot].iconBG.color = notSelectedColor;

                if (currentQuickSlot <= 0) currentQuickSlot = quickSlot.Length - 1; else currentQuickSlot--;

                SelectSlot();
            }
        }
    }

    public GatherResources currentWeapon;
    public Gun currentGun;

    [Space]
    [Header("Управление")]
    public bool attacke;
    public bool special;

    private void Awake() => instance = this;
    
    private void Start() => SelectSlot();

    private void Update()
    {    
        if (attacke)
        {
            if (currentGun != null) 
            {
                currentGun.Shoot();
            }
        }

        if (Application.platform == RuntimePlatform.Android) return;

        scrollWheel = Input.GetAxis("Mouse ScrollWheel");

        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            ActiveSlot();
        }
        else if (Input.GetKeyUp(KeyCode.Mouse0))
        {
            anim.SetBool("Hit", false);
            attacke = false;
        }

        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            special = true;
            anim.SetBool("Aim", true);
            
            if (ClothAdder.instance.shieldSlot.item != null && ClothAdder.instance.shield.recharg == false) anim.SetBool("Shield", true);
            else anim.SetBool("Shield", false);
        }
        else if (Input.GetKeyUp(KeyCode.Mouse1))
        {
            special = false;
            anim.SetBool("Aim", false);
            anim.SetBool("Shield", false);
        }
    }

    public void AchivementChek(float progressAdd)
    {
        foreach (AchievementItem achievements in achievementManager.achievementItem)
        {
            if (achievements.achievementScriptableObject.achievementType == AchievementType.Resource &&
             achievements.achievementScriptableObject.itemScriptableObject == quickSlot[currentQuickSlot].item)
            {
                achievements.sliderProgress.value += progressAdd;

                if (achievements.sliderProgress.value >= achievements.sliderProgress.maxValue) 
                {
                    achievements.Unloke();
                    achievements.buttonAchievement.interactable = true;
                }
                else
                {
                    achievements.buttonAchievement.interactable = false;
                }

                break;
            }
        }
    }

    private void SelectSlot()
    {
        anim.SetBool("Hit", false);
        attacke = false;

        quickSlot[currentQuickSlot].iconBG.color = selectedColor;
        currentGun = null;

        CheckItemInHand();
    }

    private void RemoveConsumableItem()
    {
        if (quickSlot[currentQuickSlot].amount <= 1) 
        {
            quickSlot[currentQuickSlot].dragAndDropItem.NullifySlotData();
        }
        else
        {
            quickSlot[currentQuickSlot].amount--;
        }
    }

    public void CheckItemInHand()
    {
        HideItemsInHand();

        if (quickSlot[currentQuickSlot].item != null) 
        {
            ShowItemInHand();
        }
        else
        {
            currentGun = null;

            attacke = false;
            anim.SetBool("Hit", false);
        }
    }

    private void ChangeCharacteristics()
    {
        Indicators.instance.ChangeFoodAmount(quickSlot[currentQuickSlot].item.changeHunger);
        Indicators.instance.ChangeWaterAmount(quickSlot[currentQuickSlot].item.changeThirst);
        Indicators.instance.ChangeHealthAmount(quickSlot[currentQuickSlot].item.changeHealth);
        Indicators.instance.ChangeColdAmount(quickSlot[currentQuickSlot].item.changeCold);

        InventoryManager.instance.audioSource.volume = Random.Range(0.2f, 0.4f);
        InventoryManager.instance.audioSource.pitch = Random.Range(0.8f, 1.2f);

        InventoryManager.instance.audioSource.PlayOneShot(quickSlot[currentQuickSlot].item.itemAudio);
        
        if (Random.Range(0f, 100f) <= quickSlot[currentQuickSlot].item.chanceEffect)
        {
            switch (quickSlot[currentQuickSlot].item.equipEffect)
            {
                case EquipEffect.Regen:
                    Indicators.instance.healEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Blood:
                    Indicators.instance.bloodEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Water:
                    Indicators.instance.waterEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Jump:
                    Indicators.instance.jumpEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Speed:
                    Indicators.instance.speedEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Web:
                    Indicators.instance.webEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Poison:    
                    Indicators.instance.poisonEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Infected:
                    Indicators.instance.infectionEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Fire:
                    Indicators.instance.fireEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Frost:
                    Indicators.instance.frostEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Mutagen:
                    break;
            }
        }
        
        RemoveConsumableItem();
    }

    private void ShowItemInHand()
    {
        AchivementChek(1);

        InventoryManager.instance.audioSource.volume = Random.Range(0.2f, 0.4f);
        InventoryManager.instance.audioSource.pitch = Random.Range(0.8f, 1.2f);

        InventoryManager.instance.audioSource.PlayOneShot(quickSlot[currentQuickSlot].item.itemAudio);

        if (currentQuickSlot != currentSmenaSlot)
        {
            anim.SetBool("Smena", true);
            currentSmenaSlot = currentQuickSlot;
        }

        if (quickSlot[currentQuickSlot].item.animType != AnimType.Default)
        {
            switch (quickSlot[currentQuickSlot].item.animType)
            {
                case AnimType.Spear:
                    anim.SetBool("Spear", true);
                    break;
                case AnimType.Gun:
                    anim.SetBool("Weapon", true);
                    break;
                case AnimType.BigSwords:
                    anim.SetBool("BigSwords", true);
                    break;
                case AnimType.Kosa:
                    anim.SetBool("Kosa", true);
                    break;
            }
        }

        GameObject weaponObj = null;

        for (int i = 0; i < allWeapons.childCount; i++)
        {
            weaponObj = allWeapons.GetChild(i).gameObject;

            if (quickSlot[currentQuickSlot].item.inHandName == weaponObj.name)
            {
                weaponObj.SetActive(true);
                PhotonSetManager.instance.SetWeapon(weaponObj.name, null);

                if (currentWeapon != null) //тут так написано чтобы по максимуму без GetComponent обойтись если что
                {
                    if (weaponObj != currentWeapon.gameObject)
                    {
                        currentWeapon = null;
                        currentWeapon = weaponObj.GetComponent<GatherResources>();
                    }
                }
                else 
                {
                    currentWeapon = weaponObj.GetComponent<GatherResources>();
                }

                anim.SetBool("SpeedMedium", false);
                anim.SetBool("SpeedLow", false);
                anim.SetBool("SpeedMax", false);

                switch (quickSlot[currentQuickSlot].item.speedAttacke)
                {
                    case SpeedAttacke.Low:
                        anim.SetBool("SpeedLow", true);
                        break;
                    case SpeedAttacke.Medium:
                        anim.SetBool("SpeedMedium", true);
                        break;
                    case SpeedAttacke.Max:
                        anim.SetBool("SpeedMax", true);
                        break;
                }

                if (currentGun != null)
                {
                    if (weaponObj != currentGun.gameObject)
                    {
                        currentGun = null;
                        currentGun = weaponObj.GetComponent<Gun>();
                    }
                }
                else 
                {
                    currentGun = weaponObj.GetComponent<Gun>();
                }

                break;
            }
        }
    }

    public void AnimHelper()
    {
        anim.SetBool("BigSwords", false);
        anim.SetBool("Spear", false);
        anim.SetBool("Weapon", false);
        anim.SetBool("Kosa", false);
    }

    private void HideItemsInHand()
    {
        for (int i = 0; i < allWeapons.childCount; i++)
        {
            allWeapons.GetChild(i).gameObject.SetActive(false);
        }

        PhotonSetManager.instance.SetWeapon(" ", null);
        AnimHelper();
    }

    public void MobailDragSlot(GameObject slotGO)
    {
        for (int i = 0; i < quickSlot.Length; i++)
        {
            if (slotGO == quickSlot[i].gameObject)
            {
                quickSlot[currentQuickSlot].iconBG.color = notSelectedColor;
                currentQuickSlot = i;

                SelectSlot();
                break;
            }
        }
    }

    public void ActiveSlot()
    {
        if (quickSlot[currentQuickSlot].item != null)
        {
            if (!InventoryManager.instance.isOpened)
            {
                if (quickSlot[currentQuickSlot].item.itemType == ItemType.Food)
                {
                    ChangeCharacteristics(); // Применяем изменения к здоровью (будущем к голоду и жажде) 
                    CheckItemInHand();
                }
                else if (quickSlot[currentQuickSlot].item.itemType == ItemType.Instrument || quickSlot[currentQuickSlot].item.itemType == ItemType.Weapon)
                {
                    anim.SetBool("Hit", true);
                    attacke = true;
                }
                else if (quickSlot[currentQuickSlot].item.itemType == ItemType.FireWeapon)
                {
                    anim.SetBool("Hit", false);
                    attacke = true;
                }
            }
        }
        else
        {
            currentGun = null;

            anim.SetBool("Hit", false);
            attacke = false;
        }
    }

    public void OnReload()
    {
        if (currentGun != null) currentGun.Reload();
    }

    public void AudioReload()
    {
        if (currentGun != null)
        {
            audioSource.pitch = Random.Range(0.9f, 1.1f);
            audioSource.PlayOneShot(currentGun.reloadAudio);
        }
    }

    public void EndReload()
    {
        anim.SetBool("Reload", false);

        if (currentGun != null)
        {
            currentGun.reload = false;
            currentGun.Amount = currentGun.realBilletAmmount;
        }
    }
}