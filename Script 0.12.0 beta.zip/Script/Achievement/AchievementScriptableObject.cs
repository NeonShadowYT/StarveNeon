using UnityEngine;

[CreateAssetMenu(fileName = "Achievement", menuName = "Neon Imperium/Achievement/New Achievement")]
public class AchievementScriptableObject : ScriptableObject
{
    public ItemScriptableObject itemScriptableObject;
    public Sprite achievementIcon;

    [Space]
    public RewardType rewardType;
    public Sprite rewardIcon;

    [Space]
    public int rewardAmount;
    public float progressAmount;

    [Space]
    public int IdGJ;
}
