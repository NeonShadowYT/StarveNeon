using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuastGame : MonoBehaviour
{
    [Space]
    [Header("Награды")]
    public PassManager passManager;

    [Space]
    [Header("Листы")]
    public List<QuastScriptableObject> allQuastList;
    public List<PassGameItem> quastItemList;

    [Space]
    [Header("Статистика")]
    public GameObject quastPrefab;
    public Transform content;

    public void Start()
    {
        for (int i = 0; i < 5; i++)
        {
            QuastScriptableObject quastScriptableObject = allQuastList[Random.Range(0, allQuastList.Count)];
            PassGameItem passGameItem = Instantiate(quastPrefab, content).GetComponent<PassGameItem>();

            quastItemList.Add(passGameItem);
            passGameItem.quastScriptableObject = quastScriptableObject;

            passGameItem.PassNameItems.text = quastScriptableObject.QuastText;
            passGameItem.PassItemReward.text = quastScriptableObject.PassMoneyReward.ToString();
            passGameItem.PassItemImage.sprite = quastScriptableObject.QuastImage;

            passGameItem.PassItemProgress.maxValue = quastScriptableObject.Amount;
            passGameItem.PassItemProgress.value = 0;

            passGameItem.claimProgress = false;
            allQuastList.Remove(quastScriptableObject);
        }
    }

    public void AddQuastReward(int i)
    {
        passManager.dataSaveLoad.data.rockValue += quastItemList[i].quastScriptableObject.PassMoneyReward;
        quastItemList[i].claimProgress = true;
        
        quastItemList.Remove(quastItemList[i]);
    }
}