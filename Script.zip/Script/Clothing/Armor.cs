using UnityEngine;

public class Armor : MonoBehaviour
{
    public ClothAdder clothAdder;
    
    [Space]
    [Header("Характеристики")]
    [Range(1, 12), Tooltip("Защита от урона")] public int armorPoints;
    [Range(0, 4), Tooltip("Защита от холода")] public int coldPoints;
    [Range(0, 1), Tooltip("Скорость в воде")] public int waterPoints;
    [Range(-1, 1), Tooltip("Скорость вне воды")] public int speedPoints;
    [Range(0, 1), Tooltip("Защита от заражения")] public int infectedPoints;
    [Range(0, 1), Tooltip("Сила прыжка")] public int jumpPoints;
    [Range(0, 6), Tooltip("Защита от погоды")] public int stormPoints;

    private void OnEnable()
    {
        if (clothAdder == null) return;
        clothAdder.armor = this;

        ArmorStats.instance.armor += armorPoints;
        ArmorStats.instance.cold += coldPoints;
        ArmorStats.instance.water += waterPoints;
        ArmorStats.instance.speed += speedPoints;
        ArmorStats.instance.storm += stormPoints;
        ArmorStats.instance.infected += infectedPoints;
        ArmorStats.instance.jump += jumpPoints;
    }

    private void OnDisable()
    {
        if (clothAdder == null) return;

        ArmorStats.instance.armor -= armorPoints;
        ArmorStats.instance.cold -= coldPoints;
        ArmorStats.instance.water -= waterPoints;
        ArmorStats.instance.speed -= speedPoints;
        ArmorStats.instance.storm -= stormPoints;
        ArmorStats.instance.infected -= infectedPoints;
        ArmorStats.instance.jump -= jumpPoints;
    }
}
