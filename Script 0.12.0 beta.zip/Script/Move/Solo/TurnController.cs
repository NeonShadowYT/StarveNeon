using UnityEngine;

public class TurnController : MonoBehaviour //https://www.youtube.com/c/maximple
{
    [Space]
    public Animator _animator;
    private float slowMouseX;

    public void TurnUpdate()
    {
        _animator.SetFloat("MouseX", Mathf.Lerp(slowMouseX, Input.GetAxis("Mouse X"), 10 * Time.deltaTime));
    }
}
