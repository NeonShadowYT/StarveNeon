using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class SelectedCharacters : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    [Space]
    [Header("�������")]
    public GameObject[] AllCharacters;
    public GameObject ArrowToLeft, ArrowToRight, ButtonBuyCharacter, ButtonSelectCharacter, TMP_TextSelectCharacter;

    private string statusCheck;

    private int check;
    private int i;

    [Space]
    [Header("�����")]
    public TMP_Text TextPrice;
    public TMP_Text textMoney;

    [Space]
    [Header("� ����?")]
    public bool Game;

    void Start()
    {
        Load();

        if (Game == false)
        {
            AllCharacters[i].SetActive(true);

            if (dataSaveLoad.data.currentCharacterSkin == AllCharacters[i].name)
            {
                ButtonBuyCharacter.SetActive(false);
                ButtonSelectCharacter.SetActive(false);
                TMP_TextSelectCharacter.SetActive(true);
            }
            else
            {
                if (dataSaveLoad.data.currentCharacterSkin != AllCharacters[i].name)
                {
                    StartCoroutine(CheckHaveCharacter());
                }
            }

            if (i > 0)
            {
                ArrowToLeft.SetActive(true);
            }

            if (i == AllCharacters.Length)
            {
                ArrowToRight.SetActive(false);
            }
        }
    }

    public void Save()
    {
        dataSaveLoad.Save();
    }

    public void Load()
    {
        dataSaveLoad.Load();

        if (textMoney != null) textMoney.text = dataSaveLoad.data.goldValue.ToString();
    }

    public void AddMoney(int Addmoney)
    {
        dataSaveLoad.data.goldValue += Addmoney;
        Save();
    }

    public void AddCharacter(string skinsName)
    {
        dataSaveLoad.data.haveCharacterSkin[dataSaveLoad.data.haveCharacterSkin.Length + 1] = skinsName;
        Save();
    }

    public IEnumerator CheckHaveCharacter()
    {
        while (statusCheck != "Check")
        {
            if (dataSaveLoad.data.haveCharacterSkin.Length != check)
            {
                if (AllCharacters[i].name != dataSaveLoad.data.haveCharacterSkin[check])
                {
                    check++;
                }
                else if (AllCharacters[i].name == dataSaveLoad.data.haveCharacterSkin[check])
                {
                    TMP_TextSelectCharacter.SetActive(false);
                    ButtonBuyCharacter.SetActive(false);
                    ButtonSelectCharacter.SetActive(true);

                    check = 0;
                    statusCheck = "Check";
                }
            }
            else if (dataSaveLoad.data.haveCharacterSkin.Length == check)
            {
                ButtonSelectCharacter.SetActive(false);
                TMP_TextSelectCharacter.SetActive(false);

                SkinsItem skinsItem = AllCharacters[i].GetComponent<SkinsItem>();

                if (skinsItem.Exclusive == false)
                {
                    ButtonBuyCharacter.SetActive(true);
                    TextPrice.text = skinsItem.priceCharacter.ToString();
                }
                else
                {
                    ButtonBuyCharacter.SetActive(false);
                    TextPrice.text = "������������ ����";
                }

                check = 0;
                statusCheck = "Check";
            }
        }

        statusCheck = "";

        yield return null;
    }

    public void ArrowRight()
    {
        if (i < AllCharacters.Length)
        {
            if (i == 0)
            {
                ArrowToLeft.SetActive(true);
            }

            AllCharacters[i].SetActive(false);
            i++;
            AllCharacters[i].SetActive(true);

            if (dataSaveLoad.data.currentCharacterSkin == AllCharacters[i].name)
            {
                ButtonBuyCharacter.SetActive(false);
                ButtonSelectCharacter.SetActive(false);
                TMP_TextSelectCharacter.SetActive(true);
            }
            else if (dataSaveLoad.data.currentCharacterSkin != AllCharacters[i].name)
            {
                StartCoroutine(CheckHaveCharacter());
            }

            if (i + 1 == AllCharacters.Length)
            {
                ArrowToRight.SetActive(false);
            }
        }
    }

    public void ArrowLeft()
    {
        if (i < AllCharacters.Length)
        {
            AllCharacters[i].SetActive(false);
            i--;
            AllCharacters[i].SetActive(true);

            ArrowToRight.SetActive(true);

            if (dataSaveLoad.data.currentCharacterSkin == AllCharacters[i].name)
            {
                ButtonBuyCharacter.SetActive(false);
                ButtonSelectCharacter.SetActive(false);
                TMP_TextSelectCharacter.SetActive(true);
            }
            else if (dataSaveLoad.data.currentCharacterSkin != AllCharacters[i].name)
            {
                StartCoroutine(CheckHaveCharacter());
            }

            if (i == 0)
            {
                ArrowToLeft.SetActive(false);
            }
        }
    }

    public void SelectCharacter()
    {
        Load();

        dataSaveLoad.data.currentCharacterSkin = AllCharacters[i].name;

        ButtonSelectCharacter.SetActive(false);
        TMP_TextSelectCharacter.SetActive(true);

        textMoney.text = dataSaveLoad.data.goldValue.ToString();

        Save();
    }

    public void BuyCharacter()
    {
        Load();

        SkinsItem skinsItem = AllCharacters[i].GetComponent<SkinsItem>();

        if (dataSaveLoad.data.goldValue >= skinsItem.priceCharacter)
        {
            dataSaveLoad.data.goldValue -= skinsItem.priceCharacter;
            dataSaveLoad.data.haveCharacterSkin[dataSaveLoad.data.haveCharacterSkin.Length + 1] = AllCharacters[i].name;

            ButtonBuyCharacter.SetActive(false);
            ButtonSelectCharacter.SetActive(true);
        }

        Save();
    }
}