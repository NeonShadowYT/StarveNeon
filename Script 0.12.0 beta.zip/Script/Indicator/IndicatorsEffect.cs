using System.Collections.Generic;
using UnityEngine;

public class IndicatorsEffect : MonoBehaviour
{
    [Space, Header("Скрипты")]
    public Indicators indicators;
    public CustomCharacterController customCharacterController;

    [Space, Header("Дополнительно")]
    public float genModifer = 1f;

    [Space, Header("Индикаторы")]
    public float healthModifer;
    public float foodModifer;
    public float waterModifer;
    public float coldModifer;

    [Space, Header("Движение")]
    public float speedModifer;
    public float jumpModifer;

    [Space, Header("Исключения")]
    public IndicatorsEffect[] exclusionEffect;

    [Space, Header("При появлении")]
    public IndicatorsEffect[] startAddEffect;
    public IndicatorsEffect[] startRemoveEffect;

    [Space, Header("При исчезновении")]
    public IndicatorsEffect[] endAddEffect;
    public IndicatorsEffect[] endRemoveEffect;

    [Space, Header("Время")]
    public float startTimeEffect;
    public bool infinity;

    [Space, Header("Колбеки")]
    private float _timeEffect;
    public float timeEffect
    {
        get { return _timeEffect; }
        set
        {
            _timeEffect = value;

            if (_timeEffect <= 0)
            {
                gameObject.SetActive(false);
            }
        }
    }

    private bool exclusion;

    void OnEnable()
    {
        customCharacterController.runningSpeed += speedModifer;
        customCharacterController.walkingSpeed += speedModifer;
        customCharacterController.jumpForce += jumpModifer;
        
        exclusion = false;

        for (int i = 0; i < exclusionEffect.Length; i++)
        {
            if (exclusionEffect[i].timeEffect >= 1)
            {
                exclusion = true;
                timeEffect = 0f;
                break;
            }
        }

        if (exclusion == true) return;

        for (int i = 0; i < startAddEffect.Length; i++)
        {
            startAddEffect[i].gameObject.SetActive(true);
        }

        for (int i = 0; i < startRemoveEffect.Length; i++)
        {
            startRemoveEffect[i].timeEffect = 0f;
        }

        timeEffect = startTimeEffect * genModifer;
        InvokeRepeating(nameof(EffectModifer), 1f, 1f);
    }

    void OnDisable()
    {
        customCharacterController.runningSpeed -= speedModifer;
        customCharacterController.walkingSpeed -= speedModifer;
        customCharacterController.jumpForce -= jumpModifer;

        for (int i = 0; i < endAddEffect.Length; i++)
        {
            endAddEffect[i].gameObject.SetActive(true);
        }

        for (int i = 0; i < endRemoveEffect.Length; i++)
        {
            endRemoveEffect[i].timeEffect = 0f;
        }

        CancelInvoke();
    }

    public void EffectModifer()
    {
        indicators.healthSlider.value += healthModifer;
        indicators.foodSlider.value += foodModifer;
        indicators.waterSlider.value += waterModifer;
        indicators.coldSlider.value += coldModifer;
        
        if (infinity == false) timeEffect--;
    }
}
