using UnityEngine;
using System.Collections.Generic;

public class BuildingHealth : MonoBehaviour
{
    [HideInInspector]
    public InventoryManager inventoryManager;
    public Building building;

    [Space]
    public float startHealth = 100;

    private float _health;
    public float health
    {
        get { return _health; }
        set
        {
            _health = value;

            if(_health <= 0)
            {
                if (anim != null)
                {
                    anim.SetBool("Death", true); 
                }
                else
                {
                    DestroyBilding();
                }
            }
            else if(_health > startHealth)
            {
                health = startHealth;
            }
        }
    }

    public LutList[] Lut;
    public GameObject hitFix;

    [Space]
    [Header("Анимация заканчивания")]
    public Animator anim;

    [Space]
    [Header("Звуки")]
    public AudioClip[] audioList;

    [HideInInspector] public AudioClip currentAudio;

    [Space]
    public Transform mTransform;
    public GameObject forDestroy;

    [Space]
    [Header("Хранилище")]
    public Storage storage;

    public void Start()
    {
        health = startHealth;

        if (mTransform == null) mTransform = gameObject.transform;;
        if (forDestroy == null) forDestroy = gameObject;

        if (anim == null) anim = GetComponent<Animator>();
    }

    public void DestroyBilding()
    {
        Vector3 LutSpanw = mTransform.position + new Vector3(0f, 0.5f, 0f) + Vector3.up + mTransform.forward;

        foreach (LutList lut in Lut)
        {
            inventoryManager.AddItem(null, lut.Item, lut.Amount, lut.Item.maximumDurability, 0);
        }

        if (storage != null)
        {
            for (int i = 0; i < storage.slots.Count; i++)
            {
                if (storage.slots[i].item != null)
                {
                    inventoryManager.AddItem(null, storage.slots[i].item, storage.slots[i].amount, storage.slots[i].durability, storage.slots[i].destroy);
                }
            }
        }

        for (int i = 0; i < building.deactiveConnections.Count; i++)
        {
            building.deactiveConnections[i].SetActive(true);
            building.deactiveConnections.Remove(building.deactiveConnections[i]);
        }

        Destroy(forDestroy);
    }
}
