using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class QuastFraction : MonoBehaviour
{
    public TMP_Text text;

    public ItemScriptableObject item;
    public int Amount;

    public QuastTable QuastTable;

    void Start()
    {
        Randomaiz();
    }

    public void Randomaiz()
    {
        Amount = Random.Range(10, 100);
        text.text = Amount.ToString();
    }

    public void Chek()
    {
        QuastTable.Buy(this);
    }
}
