using UnityEngine;

public class PlayerInteractable : MonoBehaviour
{
    public void OnTriggerEnter(Collider col)
    {
        if (col.CompareTag("Item") || col.CompareTag("Door") || col.CompareTag("Table"))
        {
            InventoryManager.instance.itemObject.Add(col.gameObject);
        }
    }

    public void OnTriggerExit(Collider col)
    {
        if (col.CompareTag("Item") || col.CompareTag("Door"))
        {
            InventoryManager.instance.itemObject.Remove(col.gameObject);
        }

        if (col.CompareTag("Table"))
        {
            if (TableManager.instance.currentTable != null)
            {
                InventoryManager.instance.EditCurcorOff();
            }
            
            InventoryManager.instance.itemObject.Remove(col.gameObject);
        }
    }
}
