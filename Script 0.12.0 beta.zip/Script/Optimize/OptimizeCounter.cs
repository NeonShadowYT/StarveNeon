using UnityEngine;
using TMPro;
using Photon.Pun;

public class OptimizeCounter : MonoBehaviour
{
    public TMP_Text fpsText;
    public TMP_Text pingText;

    [Header("Интервал"), Tooltip("В секундах"), SerializeField]
    public float updateInterval = 5f;
    private int fpsAccumulator = 0;

    private void Start()
    {
        fpsText.text = "ФПС обработка";
        pingText.text = "Пинг обработка";

        InvokeRepeating(nameof(UpdateText), updateInterval, updateInterval);
    }

    private void Update()
    {
        fpsAccumulator++;
    }

    private void UpdateText()
    {
        fpsText.text = "ФПС " + (fpsAccumulator / updateInterval);
        pingText.text = "Пинг " + PhotonNetwork.GetPing();

        fpsAccumulator = 0;
    }
}