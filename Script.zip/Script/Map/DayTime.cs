using UnityEngine;

public class DayTime : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{   
    public static DayTime instance;

    [Space]
    public Sprite dayIcon;

    [Space]
    [Header("Фракция")]
    private Fraction[] fraction;

    [Space]
    private int _Day;
    public int Day
    {
        get { return _Day; }
        set
        {
            _Day = value;

            if (_Day <= DataSaveLoad.instance.data.dayInt) return;

            texnoAdd += Random.Range(50, 150);

            for (int i = 0; i < MoneyManager.instance.AllMoneySlot.Count; i++)
            {
                if (MoneyManager.instance.AllMoneySlot[i].money.moneyType == MoneyType.Texno)
                {
                    MoneyManager.instance.AllMoneySlot[i].amount += texnoAdd;
                    break;
                }
            }

            for (int i = 0; i < QuastGame.instance.quastItemList.Count; i++)
            {
                if (QuastGame.instance.quastItemList[i].quastScriptableObject.quastType == QuastType.Day)
                {
                    QuastGame.instance.quastItemList[i].PassItemProgress.value += 1;

                    if (QuastGame.instance.quastItemList[i].PassItemProgress.value == QuastGame.instance.quastItemList[i].PassItemProgress.maxValue)
                    {
                        QuastGame.instance.AddQuastReward(i);
                    }
                }
            }
        }
    }

    public bool night;
    private int texnoAdd;

    private void Awake() => instance = this;

    private void Start()
    {
        fraction = FindObjectsOfType<Fraction>();
        Day = DataSaveLoad.instance.data.dayInt;
    }

    public void DayEnd()
    {
        night = true;
        Indicators.instance.Night();
    }

    public void DayStart()
    {
        Day++;
        IventViewer.instance.IventView(dayIcon, "День " + Day + " Техно очков " + texnoAdd);

        texnoAdd = 0;
        night = false;

        Indicators.instance.Night();
    }
    
    public void OnFraction()
    {
        for (int i = 0; i < fraction.Length; i++)
        {
            fraction[i].UpdateFractChek(Day);
        }
    }

    public void OnStolery()
    {
        Stolery.instance.RandomIvent();
    }
}