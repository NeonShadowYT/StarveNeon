using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;

public class Promo : MonoBehaviour
{
    public static Promo instance;

    [Space]
    [Header("Ввод")]
    public TMP_InputField promoText;

    [Space]
    [Header("Все промокоды")]
    public List<PromoItem> promoItem;

    private void Awake() => instance = this;

    public void CheckPromo()
    {
        if (promoText.text != "")
        {
            for (int i = 0; i < promoItem.Count; i++)
            {
                if (promoText.text == promoItem[i].promo)
                {
                    DataSaveLoad.instance.data.activePromo = new string[1];
                    DataSaveLoad.instance.data.activePromo[0] = promoItem[i].promo;
                    break;
                }
            }
        }
    }
}

[System.Serializable]
public class PromoItem
{
    [Space]
    [Header("Название предмета")]
    public string itemName;

    [Space]
    [Header("Промокод")]
    public string promo;
}