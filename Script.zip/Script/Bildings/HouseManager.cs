﻿using System.Collections.Generic;
using UnityEngine;

public class HouseManager : MonoBehaviour
{
    public List<Building> buildingBlocks = new List<Building>();

    public void UpdateBuildingBlocks()
    {
        buildingBlocks.Clear();
        buildingBlocks.AddRange(transform.GetComponentsInChildren<Building>());

        foreach (Building buildingBlock in buildingBlocks)
        {
            if (buildingBlock == null)
            {
                buildingBlocks.Remove(buildingBlock);
            }
            else
            {
                switch (buildingBlock.buildingType)
                {
                    case BuildingType.Foundation:
                        for (int i = 0; i < buildingBlock.foundationConnections.Count; i++) buildingBlock.CheckNearby(i);
                        break;
                    case BuildingType.Edge:
                        for (int i = 0; i < buildingBlock.edgeConnections.Count; i++) buildingBlock.CheckNearby(i);
                        break;
                    case BuildingType.Wall:
                        for (int i = 0; i < buildingBlock.wallConnections.Count; i++) buildingBlock.CheckNearby(i);
                        break;
                }
            } 
        }
    }
}