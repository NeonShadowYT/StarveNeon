﻿using System.Collections.Generic;
using UnityEngine;

public enum RewardType { Wood, Rock, Cuprum, Gold, Diamond, Ametist, Redit, Izum, Core, Neolit, CharacterSkin, ItemSkin }
public class DataSaveLoad : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [SerializeField] private CustomCharacterController customCharacterController;
    [SerializeField] private AchievementManager achievementManager;
    [SerializeField] private InventoryManager inventoryManager;
    [SerializeField] private CraftManager craftManager;
    [SerializeField] private PassManager passManager;
    [SerializeField] private Indicators indicators;

    [Space]
    public SaveData data;

    void Awake()
    {
        Load();
    }

    public void Save()
    {
        if (indicators == null) 
        {
            BinarySavingSystem.Save(data);
            return;
        }

        data.health = indicators.healthSlider.value;
        data.food = indicators.foodSlider.value;
        data.water = indicators.waterSlider.value;
        data.cold = indicators.coldSlider.value;

        data.dayInt = indicators.daytime.Day;

        //position = new float[3];
        //var playerPosition = player.mTransform.position;

        //position[0] = playerPosition.x;
        //position[1] = playerPosition.y;
        //position[2] = playerPosition.z;

        data.itemNames = new string[inventoryManager.slots.Count];
        data.itemAmounts = new int[inventoryManager.slots.Count];

        for (int i = 0; i < inventoryManager.slots.Count; i++)
        {
            if (inventoryManager.slots[i].item != null)
            {
                data.itemNames[i] = inventoryManager.slots[i].item.name;
                data.itemAmounts[i] = inventoryManager.slots[i].amount;
            }
        }

        data.allCrafts = new string[craftManager.allCrafts.Count];

        for (int i = 0; i < craftManager.allCrafts.Count; i++) data.allCrafts[i] = craftManager.allCrafts[i].name;

        for (int i = 0; i < inventoryManager.moneyManager.AllMoneySlot.Count; i++)
        {
            switch (inventoryManager.moneyManager.AllMoneySlot[i].money.money)
            {
                case MoneyType.Ksencse:
                    data.ksenoAmount = inventoryManager.moneyManager.AllMoneySlot[i].amount;
                    break;
                case MoneyType.GC:
                    data.goldenAmount = inventoryManager.moneyManager.AllMoneySlot[i].amount;
                    break;
                case MoneyType.Oboroten:
                    data.oborotAmount = inventoryManager.moneyManager.AllMoneySlot[i].amount;
                    break;
                case MoneyType.Stasy:
                    data.stasyAmount = inventoryManager.moneyManager.AllMoneySlot[i].amount;
                    break;
                case MoneyType.Texno:
                    data.texnoAmount = inventoryManager.moneyManager.AllMoneySlot[i].amount;
                    break;
            }
        }

        data.ksenoRepAmount = inventoryManager.fractionManager.ksenoRepAmount;
        data.goldenRepAmount = inventoryManager.fractionManager.goldenRepAmount;
        data.oborotRepAmount = inventoryManager.fractionManager.oborotRepAmount;
        data.stasyRepAmount = inventoryManager.fractionManager.stasyRepAmount;

        data.passComplite = new bool[passManager.Pass.Count];

        for (int i = 0; i < passManager.Pass.Count; i++)
        {
            data.passComplite[i] = passManager.Pass[i].PassComplite;
        }

        data.nameAchievement = new string[achievementManager.achievementScriptableObject.Count];
        data.progressAchievement = new float[achievementManager.achievementScriptableObject.Count];
        data.rewardAchievement = new bool[achievementManager.achievementScriptableObject.Count];

        for (int i = 0; i < achievementManager.achievementScriptableObject.Count; i++)
        {
            data.nameAchievement[i] = achievementManager.achievementScriptableObject[i].name;
            data.progressAchievement[i] = achievementManager.achievementItem[i].sliderProgress.value;
            data.rewardAchievement[i] = achievementManager.achievementItem[i].claimProgress;
        }

        BinarySavingSystem.Save(data);
    }

    public void Load()
    {
        SaveData _data = BinarySavingSystem.Load(data);

        if (_data != null) 
        {
            data = _data;
        }
        else 
        {
            Save();
        }
    }

    public void Death()
    {
        
    }

    public void Live()
    {
        
    }
}
