using Cinemachine;
using UnityEngine;
using UnityEngine.EventSystems;

public class CameraControllerPanel : MonoBehaviour, IPointerDownHandler,IPointerUpHandler
{
    public CustomCharacterController customCharacterController;

    public CinemachineVirtualCamera CVC;
    private CinemachinePOV pov;

    [Space]
    public bool pressed = false;
    public int fingerId;

    private bool gyroEnabled;
    private Gyroscope gyro;

    private void Start()
    {
        pov = CVC.GetCinemachineComponent<CinemachinePOV>();
        gyroEnabled = EnableGyro();

        pov.m_HorizontalAxis.m_InputAxisName = "";
        pov.m_VerticalAxis.m_InputAxisName = "";
    }

    private bool EnableGyro()
    {
        if (SystemInfo.supportsGyroscope) 
        {
            gyro = Input.gyro;
            gyro.enabled = true;
            
            return true;
        }

        return false;
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if(eventData.pointerCurrentRaycast.gameObject == gameObject)
        {
            pressed = true;
            fingerId = eventData.pointerId;
        }
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        pressed = false;

        pov.m_VerticalAxis.m_InputAxisValue = 0;
        pov.m_HorizontalAxis.m_InputAxisValue = 0;
    }
    void Update()
    {
        if (gyroEnabled)
        {
            pov.m_VerticalAxis.m_InputAxisValue = gyro.attitude.y;
            pov.m_HorizontalAxis.m_InputAxisValue = gyro.attitude.x;
        }
        else if (pressed)
        {
            foreach (Touch touch in Input.touches)
            {
                if (touch.fingerId == fingerId)
                {
                    if (touch.phase == TouchPhase.Moved)
                    {
                        pov.m_VerticalAxis.m_InputAxisValue = touch.deltaPosition.y;
                        pov.m_HorizontalAxis.m_InputAxisValue = touch.deltaPosition.x;
                    }
                    if (touch.phase == TouchPhase.Stationary)
                    {
                        pov.m_VerticalAxis.m_InputAxisValue = 0;
                        pov.m_HorizontalAxis.m_InputAxisValue = 0;
                    }
                }
            }
        }
    }
}