using UnityEngine;

public class OutingManager : MonoBehaviour
{
    public static OutingManager instance;

    public GameObject outingPanel;
    public GameObject inventoryPanel;

    private void Awake() => instance = this;
    
    public void Biom(string biom) => DataSaveLoad.instance.data.biom = biom;

    public void Function(Table _table)
    {
        outingPanel.SetActive(true);
        inventoryPanel.SetActive(false);
    }

    public void Close()
    {
        outingPanel.SetActive(false);
    }
}
