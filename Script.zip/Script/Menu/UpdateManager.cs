using System;
using UnityEngine;
using System.Collections;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;

public class UpdateManager : MonoBehaviour
{    
    [Space]
    [Header("Ссылка")]
    public string versionUrl = "";
    public string updateLink;

    [Space]
    [Header("Следующая версия")]
    private string latestVersion;

    [Space]
    [Header("Визуал")]
    public GameObject newVersionAvailable;
    public TMP_Text NewVersionText;

    public void Start()
    {
        latestVersion = "";
        
        Check();
    }

    public void Check()
    {
        StartCoroutine(LoadTxtData(versionUrl));
    }

    private IEnumerator LoadTxtData(string url)
    {
        UnityWebRequest loaded = new UnityWebRequest(url);
        loaded.downloadHandler = new DownloadHandlerBuffer();

        yield return loaded.SendWebRequest();
        latestVersion = loaded.downloadHandler.text;

        if (!string.IsNullOrEmpty(loaded.error))
        {
            Debug.Log(loaded.error);
            NewVersionText.text = "Фулл сервер или нет инета";
            yield break;
        }

        CheckVersion();
    }

    private void CheckVersion()
    {
        NewVersionText.text = latestVersion;
        
        if (latestVersion != "") 
        {
            if (Application.version != latestVersion)
            {
                newVersionAvailable.SetActive(true);
            }
        }
    }

    public void UpdateButton() => Application.OpenURL(updateLink);
}