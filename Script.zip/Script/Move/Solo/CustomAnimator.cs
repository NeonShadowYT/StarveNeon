using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomAnimator : MonoBehaviour
{
    public Animator anim;

    [Space]
    [Header("Хеширование")] //экономит 30 мс ;)
    public string[] animHash;
    private int[] _animHash;

    private void Start()
    {
        for (int i = 0; i < animHash.Length; i++)
        {
            _animHash[i] = Animator.StringToHash(animHash[i]);
        }
    }

    public void SetFloat(int id, float value)
    {
        anim.SetFloat(_animHash[id], value);
    }

    public void SetInt(int id, int value)
    {
        anim.SetInteger(_animHash[id], value);
    }

    public void SetBool(int id, bool value)
    {
        anim.SetBool(_animHash[id], value);
    }
}
