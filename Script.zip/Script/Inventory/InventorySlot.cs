﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;

public enum SlotType { None, Storage, Backpack }
public class InventorySlot : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Предмет и его количество")]
    public ItemScriptableObject _item;
    public ItemScriptableObject item
    {
        get { return _item; }
        set 
        {
            _item = value;

            UpdateIcon();
        }
    }

    [Space]
    public int _amount;
    public int amount
    {
        get { return _amount; }
        set 
        {
            _amount = value;

            UpdateAmmount();
        }
    }

    public float _durability;
    public float durability
    {
        get { return _durability; }
        set 
        {
            _durability = value;

            UpdateDurability();
        }
    }

    [Space]
    [Header("Интерфейс")]
    public Image iconGO;
    public Image iconBG;

    [Space]
    public Image durabilityBar;
    public Image destroyBar;

    [Space]
    public TMP_Text itemAmountText;
    public DragAndDropItem dragAndDropItem;

    [Space]
    [Header("Информация о слоте")]
    public SlotType slotType = SlotType.None;
    public ClothType clothType = ClothType.None;

    private void UpdateIcon()
    {
        if (item != null)
        {
            iconGO.color = new Color(1, 1, 1, 1);
            iconGO.sprite = item.icon;
        }
        else
        {
            iconGO.color = new Color(1, 1, 1, 0);
            iconGO.sprite = null;
        }
    }

    private void UpdateAmmount()
    {
        if (amount <= 0 || item.maximumAmount <= 1)
        {
            itemAmountText.text = "";
        }
        else
        {
            itemAmountText.text = amount.ToString(); 
        }
    }

    private void UpdateDurability()
    {
        if (item == null || item.maximumDurability <= 0) 
        {
            durabilityBar.fillAmount = 0f;
            destroyBar.fillAmount = 0f;
            return;
        }

        durabilityBar.fillAmount = durability / item.maximumDurability;
    }

    public void SubtractDurabilityPerHit(float itemDestroy)
    {
        if (item == null || item.maximumDurability <= 0) return;

        durability -= itemDestroy;
    }
}