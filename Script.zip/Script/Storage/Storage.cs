using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class Storage : MonoBehaviour
{
    [HideInInspector] public InventoryManager inventory;

    public List<StorageSlot> slots;
}

[System.Serializable]
public class StorageSlot
{
    [Space]
    [Header("Предмет")]
    public ItemScriptableObject item;

    public int amount;
    public float durability;
    public float destroy;
}