using UnityEngine;
using UnityEngine.AI;

public class AIOptimizer : MonoBehaviour
{
    [Space]
    [Header("Аи")]
    public AIManager aIManager;
    public GameObject MobView;

    public void Startap()
    {
        aIManager.optimizer = this;
        MobView.SetActive(false);

        aIManager.navMeshAgent.enabled = false;
        aIManager.mobCollider.enabled = false;
        aIManager.animator.enabled = false;
        aIManager.audios.enabled = false;
    }

    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            if(aIManager.death == true)
            {
                MobView.SetActive(false);
                aIManager.animator.cullingMode = AnimatorCullingMode.CullCompletely;

                aIManager.navMeshAgent.enabled = false;
                aIManager.mobCollider.enabled = false;
                aIManager.animator.enabled = false;
                aIManager.audios.enabled = false;
                return;
            }

            if (aIManager.AgreAI == true || aIManager.FractionAI == true)
            {
                aIManager.animator.cullingMode = AnimatorCullingMode.CullUpdateTransforms;
            }

            if (aIManager.mobUpdate.Count != 0)
            {
                if (aIManager.daytime.Day == aIManager.mobUpdate[0].dayUpdate || aIManager.daytime.MobUpdater == true)
                {
                    aIManager.UpdateLvlMob();
                }
            }

            aIManager.globalInvoker.aiMoveAnimal.Add(aIManager);
            aIManager.globalInvoker.aiAnimUpdate.Add(aIManager);

            MobView.SetActive(true);

            aIManager.navMeshAgent.enabled = true;
            aIManager.mobCollider.enabled = true;
            aIManager.animator.enabled = true;
            aIManager.audios.enabled = true;

            if (aIManager.globalInvoker.sleepAI == false)
            {
                if (aIManager.NightAI == true)
                {
                    aIManager.animator.SetBool("Sleep", true);
                    return;
                }
            }
            else
            {
                if (aIManager.SleepAI == true)
                {
                    aIManager.animator.SetBool("Sleep", true);
                    return;
                }
            }

            aIManager.animator.SetBool("Sleep", false);
        }
    }

    void OnTriggerExit(Collider col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            aIManager.globalInvoker.aiAnimUpdate.Remove(aIManager);
            aIManager.globalInvoker.aiMoveAnimal.Remove(aIManager);
            aIManager.globalInvoker.aiViewTarget.Remove(aIManager);

            MobView.SetActive(false);
            aIManager.animator.cullingMode = AnimatorCullingMode.CullCompletely;

            aIManager.navMeshAgent.enabled = false;
            aIManager.mobCollider.enabled = false;
            aIManager.animator.enabled = false;
            aIManager.audios.enabled = false;
        }
    }
}
