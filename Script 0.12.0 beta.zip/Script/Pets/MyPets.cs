using UnityEngine;
using UnityEngine.AI;

public class MyPets : MonoBehaviour
{
    public MobScriptableObject mobScriptableObject;

    public NavMeshAgent _navMeshAgent;
    public Animator _animator;

    [HideInInspector] public CustomCharacterController customCharacterController;

    void Start()
    {
        if (customCharacterController != null) customCharacterController = FindObjectOfType<CustomCharacterController>();
        
        _navMeshAgent.speed = mobScriptableObject.movementSpeed;

        InvokeRepeating(nameof(AnimUpdate), 0.1f, 0.1f);
        InvokeRepeating(nameof(MoveAnimal), mobScriptableObject.changePositionTime, mobScriptableObject.changePositionTime);
    }

    //основное
    private void MoveAnimal()
    {
        _navMeshAgent.destination = customCharacterController.mTransform.position; // идём к цели
    }
    public void AnimUpdate()
    {
        _animator.SetFloat("Speed", _navMeshAgent.velocity.magnitude / mobScriptableObject.movementSpeed);  // ���� ����� � ��������� ��������� �������� �� ������ ��������
    }
}
