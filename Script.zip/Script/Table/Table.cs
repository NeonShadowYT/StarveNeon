using UnityEngine;

public class Table : MonoBehaviour
{
    [Space]
    public TableType tableType;

    [Range(1, 4)]
    public int tableLvl;

    [Space]
    public Storage storage;
    public FractionScriptableObject fraction;
}
