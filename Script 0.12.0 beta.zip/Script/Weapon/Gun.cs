using UnityEngine;
using System.Collections;

public class Gun : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Важное")]
    public EffectPool effectPool;
    public InventoryManager inventoryManager;
    public QuickslotInventory quickslotInventory;
    public Indicators indicators;

    [Space]
    public Transform mainCamera;
    public Recoil recoil;
    public Animator anim;

    [Space]
    [Header("Оптимизация")]
    public LayerMask layerMask;
    public float distanceFire = 50f;

    [Space]
    [Header("Характеристики")]
    public GunType gunType;
    public ItemScriptableObject bulletItem;
    
    public float damage = 20f;
    public float fireRate = 1f;
    private float nextFire = 0f;

    public Vector3 BulletRandomRazbros = new Vector3(0.2f, 0.2f, 0.2f);
    public Vector3 AimBulletRandomRazbros = new Vector3(0.1f, 0.1f, 0.1f);

    private float currentDamage;
    //private float currentDistance; на будущее

    [Space]
    [Header("Разброс и отдача")]
    public float recoilX;
    public float recoilY;
    public float recoilZ;

    public float aimRecoilX;
    public float aimRecoilY;
    public float aimRecoilZ;

    public float snappiness;
    public float returnSpeed;

    [Space]
    [Header("Эффект")]
    public ParticleSystem muzzleFlash;

    [Space]
    [Header("Патроны")]
    public int billetAmmount; // макс патрон в обойме
    public int realBilletAmmount; // сколько зарядится патрон после перезарядки

    private int _Amount;
    public int Amount
    {
        get { return _Amount; }
        set
        {
            _Amount = value;
            if (_Amount <= 0) 
            {
                Reload();
            }
        }
    }

    [Space]
    [Header("Звуки")]
    public AudioClip shotAudio;
    public AudioClip reloadAudio;
    public AudioSource audioSource;

    [HideInInspector]
    public bool reload;

    public void Shoot()
    {
        if (quickslotInventory.activeSlot.item.isDurability == true && quickslotInventory.activeSlot.itemDurability <= 0) return;

        if (Amount <= 0)
        {
            Reload();
            return;
        }

        if (Time.time >= nextFire && Amount >= 1)
        {
            nextFire = Time.time + 1f / fireRate;

            Amount -= 1;
            currentDamage = damage;

            audioSource.pitch = Random.Range(0.9f, 1.1f);
            audioSource.pitch = Random.Range(0.9f, 1.1f);
            audioSource.PlayOneShot(shotAudio);

            muzzleFlash.Play();

            recoil.RecoilFire(recoilX, recoilY, recoilZ, aimRecoilX, aimRecoilY, aimRecoilZ);

            int durability = Random.Range(1, 5);
            quickslotInventory.activeSlot.SubtractDurabilityPerHit(durability);

            RaycastHit hit;
            Vector3 direction = GetDirection();
            direction *= indicators.RazbrosPlus;

            if (Physics.Raycast(mainCamera.position, direction, out hit, distanceFire, layerMask))
            {
                if (hit.collider.CompareTag("Mob") || hit.collider.CompareTag("FractionNps"))
                {
                    MobStats hitMob = hit.collider.GetComponent<MobStats>();

                    if (hitMob != null)
                    {
                        hitMob.HitForMe(currentDamage);
                        effectPool.ViewEffect(hitMob.mobScriptableObject.hitFIX, hit.point);
                    }
                }
            }
        }
    }

    private Vector3 GetDirection()
    {
        Vector3 direction = mainCamera.forward;

        if (quickslotInventory.Aim == false)
        {
            direction += new Vector3(Random.Range(-BulletRandomRazbros.x, BulletRandomRazbros.x), Random.Range(-BulletRandomRazbros.y, BulletRandomRazbros.y), Random.Range(-BulletRandomRazbros.z, BulletRandomRazbros.z));
        }
        else
        {
            direction += new Vector3(Random.Range(-AimBulletRandomRazbros.x, AimBulletRandomRazbros.x), Random.Range(-AimBulletRandomRazbros.y, AimBulletRandomRazbros.y), Random.Range(-AimBulletRandomRazbros.z, AimBulletRandomRazbros.z));
        }

        direction.Normalize();

        return direction;
    }

    public void Reload()
    {
        if (reload == true) 
        {
            anim.SetBool("Reload", true);
            return;
        }

        int amountBulletInventory = 0;

        foreach (InventorySlot slot in inventoryManager.slots)
        {
            if (amountBulletInventory >= 1)
            {
                realBilletAmmount = amountBulletInventory;
                reload = true;
                anim.SetBool("Reload", true);
                break;
            }
            else
            {
                if (slot.item == bulletItem)
                {
                    if (billetAmmount > slot.amount)
                    {
                        amountBulletInventory += slot.amount;
                        slot.GetComponentInChildren<DragAndDropItem>().NullifySlotData();
                    }
                    else
                    {
                        slot.amount -= billetAmmount;
                        amountBulletInventory = billetAmmount;
                        if (slot.amount <= 0) slot.GetComponentInChildren<DragAndDropItem>().NullifySlotData(); else slot.itemAmountText.text = slot.amount.ToString();
                    }
                }
            }
        }
    }
}

public enum GunType
{
    Gun,
    Rifle
}