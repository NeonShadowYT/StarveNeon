using UnityEngine;

public class MinimumDistance : MonoBehaviour
{
    [Space]
    [Header("���� � ��")]
    public AIManager aIManager;
    public Pets pets;

    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            if (aIManager.CompanionAI != true)
            {
                if (aIManager.AgreAI == true)
                {
                    aIManager.animator.SetBool("Damage", true);
                    aIManager.AIStop();
                    
                    aIManager.mobStats.playerAttackeZone = true;
                }
            }
        }
        else if (col.gameObject.CompareTag("AnimalFood"))
        {
            if (pets != null)
            {
                if (pets.petsFoodObj != null)
                {
                    Destroy(pets.petsFoodObj.destroyObj);

                    int random = Random.Range(1, 100);

                    if (random >= pets.ChancePets * aIManager.globalInvoker.customCharacterController.indicators.PetsPlus) aIManager.PetsMe();
                }
            }
        }
    }

    void OnTriggerExit(Collider col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            aIManager.animator.SetBool("Damage", false);
            aIManager.AIWalk();

            aIManager.mobStats.playerAttackeZone = false;
            aIManager.nextAttackTime = Time.time + aIManager.mobScriptableObject.attackeTime;
        }
    }
}