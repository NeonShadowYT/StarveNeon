using UnityEngine;
public class SkinsItem : MonoBehaviour
{
    public int priceCharacter;
    public bool Exclusive;
}
