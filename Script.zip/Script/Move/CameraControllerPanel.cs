using UnityEngine;
using Cinemachine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;

public class CameraControllerPanel : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public CinemachineVirtualCamera CVC;
    private CinemachinePOV pov;

    private PointerEventData pointerEventData;

    private void Start()
    {
        pov = CVC.GetCinemachineComponent<CinemachinePOV>();

        pov.m_HorizontalAxis.m_InputAxisName = "";
        pov.m_VerticalAxis.m_InputAxisName = "";
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (eventData.pointerCurrentRaycast.gameObject == gameObject)
        {
            pointerEventData = eventData;
            StartCoroutine(CameraMove());
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        StopAllCoroutines();

        pov.m_VerticalAxis.m_InputAxisValue = 0;
        pov.m_HorizontalAxis.m_InputAxisValue = 0;
    }

    private IEnumerator CameraMove()
    {
        while (true)
        {
            pov.m_VerticalAxis.m_InputAxisValue = pointerEventData.delta.y;
            pov.m_HorizontalAxis.m_InputAxisValue = pointerEventData.delta.x;

            yield return null;
        }
    }
}