using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BioManager : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    [Space]
    [Header("Ксенотип")]
    public Image imageKsenoType;
    public TMP_Text textKsenoTypeName;
    public TMP_Text textKsenoTypeDescriphen;

    [Space]
    public TMP_Text ksenoTypeComplexityText;
    public TMP_Text ksenoTypeMetabalizmText;

    private int ksenoTypeComplexity;
    private int ksenoTypeMetabalizm;

    [Space]
    [Header("Ген")]
    public Image imageGen;
    public TMP_Text textGenDescriphen;

    [Space]
    public TMP_Text genComplexity;
    public TMP_Text genMetabalizm;

    [Space]
    [Header("Текущий")]
    public KsenoTypeScriptableObject currentKsenoType;
    public GenScriptableObject currentGen;

    [Space]
    [Header("Все")]
    public List<GenScriptableObject> allGenList;
    public List<GenScriptableObject> genAcceptList;

    [Space]
    public List<KsenoTypeScriptableObject> allKsenoTypeList;

    [Space]
    [Header("Контент")]
    public Transform genActiveContent;
    public Transform genDisableContent;

    [Space]
    public Transform ksenoTypeContent;

    [Space]
    [Header("Визуализация")]
    public Transform genViewContent;

    [Space]
    [Header("Префабы")]
    public GameObject genPrefab;
    public GameObject ksenoTypePrefab;

    [Space]
    [Header("В игре?")]
    public bool Game;

    void Awake()
    {
        if (Game == false)
        {
            foreach (KsenoTypeScriptableObject ksenoType in allKsenoTypeList) // ��������� ��� ������
            {
                KsenoTypeItem ksenoTypeItem = Instantiate(ksenoTypePrefab, ksenoTypeContent).GetComponent<KsenoTypeItem>();

                ksenoTypeItem.bioManager = this;

                ksenoTypeItem.ksenoTypeScriptableObject = ksenoType;

                ksenoTypeItem.icon.sprite = ksenoType.icon;
                ksenoTypeItem.text.text = ksenoType.NameKsenoType;
            }

            foreach (GenScriptableObject gen in allGenList) // ��������� ��� ��������� ������� ����� ����� ��������
            {
                GenItem genItem = Instantiate(genPrefab, genDisableContent).GetComponent<GenItem>();

                genItem.bioManager = this;

                genItem.genScriptableObject = gen;
                genItem.text.text = gen.NameGen;
                genItem.icon.sprite = gen.icon;

                genItem.removeButton.SetActive(false);
                genItem.addButton.SetActive(true);
            }

            ChangeKsenoType(currentKsenoType);
        }
        else
        {
            Load();
        }
    }

    public void Load()
    {
        RemoveAllGen();

        for (int i = 0; i < dataSaveLoad.data.genNames.Length; i++)
        {
            GenScriptableObject genScriptableObject = Resources.Load<GenScriptableObject>($"Bioteh/Gen/{dataSaveLoad.data.genNames[i]}");

            AddGen(genScriptableObject);

            for (int id = 0; id < genViewContent.childCount; id++)
            {
                GameObject genObj = genViewContent.GetChild(id).gameObject;

                if (genObj.name == genScriptableObject.NameGen) 
                {
                    genObj.SetActive(true);
                    break;
                }
            }
        }
    }

    public void ChangeKsenoType(KsenoTypeScriptableObject ksenoTypeScriptableObject) // ������������� ��������� ������
    {
        currentKsenoType = ksenoTypeScriptableObject;

        textKsenoTypeName.text = currentKsenoType.NameKsenoType;
        textKsenoTypeDescriphen.text = currentKsenoType.Descriphen;
        imageKsenoType.sprite = currentKsenoType.icon;

        RemoveAllGen();

        foreach (GenScriptableObject genScriptableObject in currentKsenoType.GenKsenoType)
        {
            AddGen(genScriptableObject);
        }
    }

    public void AddGen(GenScriptableObject genScriptableObject) // ��������� ���������
    {
        allGenList.Remove(genScriptableObject);
        genAcceptList.Add(genScriptableObject);

        GenItem genItem = Instantiate(genPrefab, genActiveContent).GetComponent<GenItem>();

        genItem.bioManager = this;

        genItem.genScriptableObject = genScriptableObject;
        genItem.text.text = genScriptableObject.NameGen;
        genItem.icon.sprite = genScriptableObject.icon;

        ksenoTypeComplexity += genScriptableObject.Complexity;
        ksenoTypeMetabalizm += genScriptableObject.Metabalizm;

        ksenoTypeComplexityText.text = ksenoTypeComplexity.ToString();
        ksenoTypeMetabalizmText.text = ksenoTypeMetabalizm.ToString();

        genItem.removeButton.SetActive(true);
        genItem.addButton.SetActive(false);

        for (int i = 0; i < genDisableContent.childCount; i++)
        {
            GenItem genPrewiew = genDisableContent.GetChild(i).GetComponent<GenItem>();

            if (genScriptableObject == genPrewiew.genScriptableObject)
            {
                Destroy(genPrewiew.gameObject);
                break;
            }
        }
    }

    public void RemoveGen(GenScriptableObject genScriptableObject)
    {
        allGenList.Add(genScriptableObject);
        genAcceptList.Remove(genScriptableObject);

        GenItem genItem = Instantiate(genPrefab, genDisableContent).GetComponent<GenItem>();

        genItem.bioManager = this;
        
        genItem.genScriptableObject = genScriptableObject;
        genItem.text.text = genScriptableObject.NameGen;
        genItem.icon.sprite = genScriptableObject.icon;

        ksenoTypeComplexity -= genScriptableObject.Complexity;
        ksenoTypeMetabalizm -= genScriptableObject.Metabalizm;

        ksenoTypeComplexityText.text = ksenoTypeComplexity.ToString();
        ksenoTypeMetabalizmText.text = ksenoTypeMetabalizm.ToString();

        genItem.removeButton.SetActive(false);
        genItem.addButton.SetActive(true);

        for (int i = 0; i < genActiveContent.childCount; i++)
        {
            GenItem genActive = genActiveContent.GetChild(i).GetComponent<GenItem>();

            if (genScriptableObject == genActive.genScriptableObject)
            {
                Destroy(genActive.gameObject);
                break;
            }
        }
    }

    public void InfoGen(GenScriptableObject genScriptableObject) // ��������� ���������
    {
        imageGen.sprite = genScriptableObject.icon;
        textGenDescriphen.text = genScriptableObject.NameGen + " : " + genScriptableObject.Descriphen;

        genComplexity.text = genScriptableObject.Complexity.ToString();
        genMetabalizm.text = genScriptableObject.Metabalizm.ToString();
    }

    public void RemoveAllGen()
    {
        for (int i = 0; i < genActiveContent.childCount; i++)
        {
            GenItem genItem = genActiveContent.GetChild(i).GetComponent<GenItem>();

            RemoveGen(genItem.genScriptableObject);

            Destroy(genItem.gameObject);
        }
    }

    public void CurrentKsenotyper()
    {
        ChangeKsenoType(currentKsenoType);
    }
}
