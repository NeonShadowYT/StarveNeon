using UnityEngine;

public class ItemSkins : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    public GameObject[] allSkinObj;
    public GameObject OriginalObj;

    void Start()
    {
        Load();
    }

    public void Load()
    {
        for (int i = 0; i < allSkinObj.Length; i++)
        {
            ItemSkinScriptableObject itemSkinScriptableObject = Resources.Load<ItemSkinScriptableObject>($"ItemSkinScriptableObject/{dataSaveLoad.data.currentItemSkin[i]}");

            if (itemSkinScriptableObject.Name == allSkinObj[i].name)
            {
                allSkinObj[i].SetActive(true);
                OriginalObj.SetActive(false);
                break;
            }
        }
    }
}