using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalInvoker : MonoBehaviour
{
    public static GlobalInvoker instance;

    [Space]
    public List<AIManager> aiAnimUpdate;
    public List<AIManager> aiLogicUpdate;
    public List<AIManager> aiMoveUpdate;
    public List<Spawner> spawnLogicUpdate;

    private WaitForSecondsRealtime animWait = new WaitForSecondsRealtime(0.1f);
    private WaitForSecondsRealtime logicWait = new WaitForSecondsRealtime(0.125f);
    private WaitForSecondsRealtime moveWait = new WaitForSecondsRealtime(5f);
    private WaitForSecondsRealtime spawnWait = new WaitForSecondsRealtime(10f);

    private void Awake() => instance = this;

    private void Start()
    {
        StartCoroutine(AnimUpdateCoroutine());
        StartCoroutine(LogicUpdateCoroutine());
        StartCoroutine(MoveUpdateCoroutine());
        StartCoroutine(SpawnUpdateCoroutine());
    }

    private IEnumerator AnimUpdateCoroutine()
    {
        while (true)
        {
            for (int i = 0; i < aiAnimUpdate.Count; i++)
            {
                aiAnimUpdate[i].AnimUpdate();
            }
            yield return animWait;
        }
    }

    private IEnumerator LogicUpdateCoroutine()
    {
        while (true)
        {
            for (int i = 0; i < aiLogicUpdate.Count; i++)
            {
                aiLogicUpdate[i].ViewTarget();
            }
            yield return logicWait;
        }
    }

    private IEnumerator MoveUpdateCoroutine()
    {
        while (true)
        {
            for (int i = 0; i < aiMoveUpdate.Count; i++)
            {
                aiMoveUpdate[i].MoveAnimal();
            }
            yield return moveWait;
        }
    }

    private IEnumerator SpawnUpdateCoroutine()
    {
        while (true)
        {
            for (int i = 0; i < spawnLogicUpdate.Count; i++)
            {
                spawnLogicUpdate[i].ChangSpawn();
            }
            yield return spawnWait;
        }
    }
}