using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class KsenoTypeItem : MonoBehaviour
{
    [HideInInspector] public BioManager bioManager;

    public KsenoTypeScriptableObject ksenoTypeScriptableObject;

    public Image icon;
    public TMP_Text text;

    public void ChangeKsenoType()
    {
        bioManager.ChangeKsenoType(ksenoTypeScriptableObject);
    }
}