using UnityEngine;

[HelpURL("https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg")]
public class ExampleClass : MonoBehaviour
{
    public void YouTube() => Application.OpenURL("https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg");
    public void Discord() => Application.OpenURL("https://discord.com/invite/9gv5sRhk9R");
    public void Donate() => Application.OpenURL("https://www.donationalerts.com/r/alexplay330");
    public void Site() => Application.OpenURL("https://sites.google.com/view/neonimperium/starve-neon");
}