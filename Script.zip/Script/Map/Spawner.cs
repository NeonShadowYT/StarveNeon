using UnityEngine;

public class Spawner : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Настройки")]
    public bool spawn;
    public bool main;

    [Space]
    [Header("Ссылки")]
    public GameObject[] ItemObj;

    [Space]
    [Header("Рандом при старте")]
    public int startRandom;
    public bool failRandom;

    [Space]
    [Header("Эффект")]
    public GameObject Effect;

    [Space]
    [Header("Время")]
    public float TimeBtwSpawns;
    public float CurrentTime;

    private void Start()
    {
        if (DayTime.instance == null) return;

        if (main) 
        {
            TimeBtwSpawns *= FindObjectOfType<GenStats>().plants;
        }

        for (int i = 0; i < ItemObj.Length; i++)
        {
            ItemObj[i].SetActive(false);
        }

        CurrentTime = TimeBtwSpawns;
        StartRandom();
    }

    private void StartRandom()
    {
        if (startRandom <= 0) return;

        startRandom -= 1;
        CurrentTime = 0;

        if (failRandom == true)
        {
            if (Random.Range(0, 3) >= 2)
            {
                ChangSpawn();
            }
        }
        else
        {
            ChangSpawn();
        }

        if (startRandom > 0) StartRandom();
    }

    public void ChangSpawn()
    {
        if (DayTime.instance.night == true) CurrentTime -= 3.5f;
        else CurrentTime -= 10f;

        if (CurrentTime > 0f) return;
        CurrentTime = TimeBtwSpawns;

        if (Effect != null) 
        {
            Effect.SetActive(true);
        }

        if (spawn)
        {
            ItemObj[Random.Range(0, ItemObj.Length)].SetActive(true);
        }
        else 
        {
            ItemObj[Random.Range(0, ItemObj.Length)].SetActive(false);
        }
    }

    private void OnTriggerEnter(Collider col)
    {
        if(col.gameObject.CompareTag("Player"))
        {
            GlobalInvoker.instance.spawnLogicUpdate.Add(this);
        }
    }

    private void OnTriggerExit(Collider col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            GlobalInvoker.instance.spawnLogicUpdate.Remove(this);
        }
    }
}