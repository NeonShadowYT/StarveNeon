using Discord;
using UnityEngine;

public class DiscordManager : MonoBehaviour
{
    public Discord.Discord discord;
    public long appId;

    public void ChangActivity()
    {
        if (discord != null)
        {
            var activityManager = discord.GetActivityManager();
            var activity = new Discord.Activity {
                State = "Ссылка в иконке",
                Details = "Хардкорное выживание",
                Assets = 
                {
                    LargeImage = "starve_neon_icon",
                    LargeText = "sites.google.com/view/neonimperium/starve-neon"
                },
            };

            activityManager.UpdateActivity(activity, (res) => Debug.Log("Дискорд обновлён"));
        }
        else 
        {
            Destroy(gameObject);
        }
    }

    void OnEnable()
    {
        if(Application.internetReachability != NetworkReachability.NotReachable) 
        {
            DontDestroyOnLoad(gameObject);
            discord = new Discord.Discord(appId, (System.UInt64)Discord.CreateFlags.Default);

            ChangActivity();
        }
        else
        {
            gameObject.SetActive(false);
        }
    }

    void OnDisable()
    {
        if (discord != null) discord.Dispose();
    }

    void Update()
    {
        discord.RunCallbacks();
    }
}
