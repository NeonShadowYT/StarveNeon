using UnityEngine;
using System.Collections;

public class WeatherPlayer : MonoBehaviour
{
    public Indicators indicators;

    public WeatherType currentWeatherType;

    [Space]
    [Header("Визуал")]
    public GameObject RainObj;
    public GameObject RainToxinObj;
    public GameObject RainAdObj;

    [Space]
    public GameObject FireObj;
    public GameObject ColdObj;

    [Space]
    [Header("Характеристика")]
    public int WeatherArmor;
    public float ColdChang;

    public void StartWeather()
    {
        StopCoroutine(WeatherIndicator());

        if (currentWeatherType == WeatherType.Default || ColdChang == 0) return;

        if (indicators.ColdArmor < WeatherArmor)
        {
            StartCoroutine(WeatherIndicator());
        }
    }

    IEnumerator WeatherIndicator()
    {
        while (true)
        {
            indicators.coldSlider.value += ColdChang * Time.deltaTime;
            yield return null;
        }
    }
}
