using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PassGameItem : MonoBehaviour
{
    public QuastScriptableObject quastScriptableObject;

    [Space]
    [Header("Визуал")]
    public Image PassItemImage;
    public TMP_Text PassNameItems;

    [Space]
    public TMP_Text PassItemReward;
    public Slider PassItemProgress;

    [Space]
    public bool claimProgress;
}