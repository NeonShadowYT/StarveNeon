using UnityEngine;
using System.Collections;

public class Recoil : MonoBehaviour
{
    public static Recoil instance;

    [Space]
    [Header("Оптимизация")]
    public Transform mTransform;

    [Space]
    [Header("Значения")]
    private Vector3 currentRotation;
    private Vector3 targetRotation;

    public float snappiness = 6f;
    public float returnSpeed = 2f;

    private void Awake() => instance = this;

    IEnumerator UpdateRecoil()
    {
        while (targetRotation != currentRotation)
        {
            targetRotation = Vector3.Lerp(targetRotation, Vector3.zero, returnSpeed * Time.deltaTime);
            currentRotation = Vector3.Slerp(currentRotation, targetRotation, snappiness * Time.deltaTime);
            mTransform.localRotation = Quaternion.Euler(currentRotation);
            yield return null;
        }

        StopCoroutine(UpdateRecoil());
    }

    public void RecoilFire(float recoilX, float recoilY, float recoilZ, float aimRecoilX, float aimRecoilY, float aimRecoilZ)
    {
        StopCoroutine(UpdateRecoil());

        if(QuickslotInventory.instance.special == false)
        {
            targetRotation += new Vector3(recoilX, Random.Range(-recoilY, recoilY), Random.Range(-recoilZ, recoilZ));
        }
        else
        {
            targetRotation += new Vector3(aimRecoilX, Random.Range(-aimRecoilY, aimRecoilY), Random.Range(-aimRecoilZ, aimRecoilZ));
        }

        StartCoroutine(UpdateRecoil());
    }
}
