using System.Collections.Generic;
using UnityEngine;

public enum FractionProfesion { Defender, Villager, Traider }
public class FractionNPS : MonoBehaviour
{
    [Space]
    [Header("Важно")]
    public Fraction myFraction;
    public FractionScriptableObject NPSFraction;

    public MobStats mobStats;
    public AIManager aIManager;
    public AICollider aICollider;

    public FractionProfesion mProfesion;
    private bool lowRep;

    [Space]
    [Header("Экиперовка")]
    public List<FractionEquipStats> villagerEquipStats;
    public List<FractionEquipStats> defenderEquipStats;
    public List<FractionEquipStats> traiderEquipStats;

    [Space]
    public FractionEquipStats mEquipStats;

    public void Startnps()
    {
        for (int i = 0; i < villagerEquipStats.Count; i++)
        {
            for (int ii = 0; ii < villagerEquipStats[i].obj.Length; ii++)
            {
                villagerEquipStats[i].obj[ii].SetActive(false);
            }
        }

        for (int i = 0; i < defenderEquipStats.Count; i++)
        {
            for (int ii = 0; ii < defenderEquipStats[i].obj.Length; ii++)
            {
                defenderEquipStats[i].obj[ii].SetActive(false);
            }
        }

        for (int i = 0; i < traiderEquipStats.Count; i++)
        {
            for (int ii = 0; ii < traiderEquipStats[i].obj.Length; ii++)
            {
                traiderEquipStats[i].obj[ii].SetActive(false);
            }
        }

        int randomNum = Random.Range(0, 4);
        if (ArenaManager.instance != null) randomNum = 2;

        switch (randomNum)
        {
            case 0:
                mProfesion = FractionProfesion.Traider;

                randomNum = Random.Range(0, traiderEquipStats.Count);
                mEquipStats = traiderEquipStats[randomNum];
                break;
            case 1:
                mProfesion = FractionProfesion.Villager;

                randomNum = Random.Range(0, villagerEquipStats.Count);
                mEquipStats = villagerEquipStats[randomNum];
                break;
            default:
                mProfesion = FractionProfesion.Defender;

                randomNum = Random.Range(0, defenderEquipStats.Count);
                mEquipStats = defenderEquipStats[randomNum];
                break;
        }

        for (int i = 0; i < mEquipStats.obj.Length; i++)
        {
            mEquipStats.obj[i].SetActive(true);
        }

        mobStats.health += mEquipStats.healthValue;
        aICollider.mobCollider[2].radius += mEquipStats.distanceValue;
        
        CheckRep();
    }

    public void CheckRep()
    {
        if (myFraction == null) return;
        lowRep = false;

        switch (NPSFraction.fractionRace)
        {
            case FractionRace.Ksencse:
                if (FractionManager.instance.ksenoRepAmount < 0) lowRep = true;
                break;
            case FractionRace.GC:
                if (FractionManager.instance.goldenRepAmount < 0) lowRep = true;
                break;
            case FractionRace.Oboroten:
                if (FractionManager.instance.oborotRepAmount < 0) lowRep = true;
                break;
            case FractionRace.Stasy:
                if (FractionManager.instance.stasyRepAmount < 0) lowRep = true;
                break;
        }

        if (lowRep == true)
        {
            if (mEquipStats.lowRepPanic)
            {
                aIManager.PanicAI = true;
            }
            else
            {
                aIManager.AgreAI = true;
            }
        }
        else
        {
            aIManager.PanicAI = false;
        }
    }
}

[System.Serializable]
public class FractionEquipStats
{
    [Space]
    [Header("Визуал")]
    public string name;
    public GameObject[] obj;

    [Space]
    [Header("Статы")]
    public float healthValue;
    public float damageValue;
    public float distanceValue;

    [Space]
    public MobPerc percValue = MobPerc.Common;
    public bool lowRepPanic;
}