using UnityEngine;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine.SceneManagement;

public class PhotonSetManager : MonoBehaviourPunCallbacks
{
    public static PhotonSetManager instance;

    [Space]
    public PhotonView _photonView;
    public CustomCharacterController customCharacterController;
    public AnimIvents animIvents;
    public GameObject[] localObj;

    [Space]
    public Transform allWeapons;
    public Transform[] allArmor;
    public Transform allShield;
    public Transform allBackpack;

    [HideInInspector] private string weapon;
    [HideInInspector] private string armor;
    [HideInInspector] private string shield;
    [HideInInspector] private string backpack;

    private void Awake() 
    {
        if (PhotonNetwork.InRoom && !_photonView.IsMine)
        {
            gameObject.tag = "Untagged";

            for (int i = 0; i < localObj.Length; i++)
            {
                Destroy(localObj[i]);
            }

            Destroy(customCharacterController.rig);
            Destroy(customCharacterController);

            animIvents.customCharacterController = null;
            animIvents.quickslotInventory = null;

            this.enabled = false;
        }
        else
        {
            instance = this;

            for (int i = 0; i < localObj.Length; i++)
            {
                localObj[i].SetActive(true);
            }

            customCharacterController.enabled = true;
        }
    }

    public override void OnPlayerEnteredRoom(Player player) //когда игрок заходит в комнату
    {
        SetWeapon(weapon, player);
        SetArmor(armor, player);
        SetShield(shield, player);
        SetBackpack(backpack, player);
    }

    public void SetWeapon(string nameObj, Player player) 
    { 
        weapon = nameObj;

        if (!PhotonNetwork.InRoom || SceneManager.GetActiveScene().name == "База") return;

        if (player != null)
        {
            _photonView.RPC(nameof(PhotonWeaponData), player, nameObj);
        }
        else
        {
            _photonView.RPC(nameof(PhotonWeaponData), RpcTarget.All, nameObj);
        }
    }

    public void SetArmor(string nameObj, Player player) 
    {
        armor = nameObj;

        if (!PhotonNetwork.InRoom || SceneManager.GetActiveScene().name == "База") return;

        if (player != null)
        {
            _photonView.RPC(nameof(PhotonArmorData), player, nameObj);
        }
        else
        {
            _photonView.RPC(nameof(PhotonArmorData), RpcTarget.All, nameObj);
        }
    }

    public void SetShield(string nameObj, Player player) 
    {
        shield = nameObj;

        if (!PhotonNetwork.InRoom || SceneManager.GetActiveScene().name == "База") return;

        if (player != null)
        {
            _photonView.RPC(nameof(PhotonShieldData), player, nameObj);
        }
        else
        {
            _photonView.RPC(nameof(PhotonShieldData), RpcTarget.All, nameObj);
        }
    }

    public void SetBackpack(string nameObj, Player player) 
    {
        backpack = nameObj;

        if (!PhotonNetwork.InRoom || SceneManager.GetActiveScene().name == "База") return;

        if (player != null)
        {
            _photonView.RPC(nameof(PhotonBackpackData), player, nameObj);
        }
        else
        {
            _photonView.RPC(nameof(PhotonBackpackData), RpcTarget.All, nameObj);
        }
    }

    [PunRPC]
    private void PhotonWeaponData(string weapon)
    {
        GameObject weaponObj = null;

        for (int i = 0; i < allWeapons.childCount; i++)
        {
            weaponObj = allWeapons.GetChild(i).gameObject;

            if (weaponObj.name == weapon) 
            {
                weaponObj.SetActive(true);
            }
            else
            {
                weaponObj.SetActive(false);
            }
        }
    }

    [PunRPC]
    private void PhotonArmorData(string armor)
    {
        GameObject armorObj = null;

        for (int ii = 0; ii < allArmor.Length; ii++)
        {
            for (int i = 0; i < allArmor[ii].childCount; i++)
            {
                armorObj = allArmor[ii].GetChild(i).gameObject;

                if (armorObj.name == armor) 
                {
                    armorObj.SetActive(true);
                }
                else
                {
                    armorObj.SetActive(false);
                }
            }
        }
    }

    [PunRPC]
    private void PhotonShieldData(string shield)
    {
        GameObject shieldObj = null;

        for (int i = 0; i < allShield.childCount; i++)
        {
            shieldObj = allShield.GetChild(i).gameObject;

            if (shieldObj.name == shield) 
            {
                shieldObj.SetActive(true);
            }
            else
            {
                shieldObj.SetActive(false);
            }
        }
    }

    [PunRPC]
    private void PhotonBackpackData(string backpack)
    {
        GameObject backpackObj = null;

        for (int i = 0; i < allBackpack.childCount; i++) 
        {
            backpackObj = allBackpack.GetChild(i).gameObject;

            if (backpackObj.name == backpack) 
            {
                backpackObj.SetActive(true);
            }
            else
            {
                backpackObj.SetActive(false);
            }
        }
    }
}