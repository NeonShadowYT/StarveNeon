using UnityEngine;

public class QuastTable : MonoBehaviour
{
    private InventoryManager inventoryManager;
    private MoneyManager moneyManager;

    public Fraction currentFraction;

    void Start()
    {
        if (currentFraction == null) currentFraction = FindObjectOfType<Fraction>();
        Invoke("GetInventory", 0.1f);
    }

    private void GetInventory()
    {
        inventoryManager = FindObjectOfType<InventoryManager>();
        moneyManager = inventoryManager.moneyManager;
    }

    public void Buy(QuastFraction quast)
    {
        foreach (InventorySlot slot in inventoryManager.slots)
        {
            if (slot.item == quast.item)
            {
                if (quast.Amount <= slot.amount)
                {
                    slot.amount -= quast.Amount;
                    if (slot.amount <= 0) slot.GetComponentInChildren<DragAndDropItem>().NullifySlotData(); else slot.itemAmountText.text = slot.amount.ToString();

                    if (currentFraction.MyFraction.fractionRace == FractionRace.Ksencse)
                    {
                        currentFraction.fractionManager.ksenoRepAmount += Random.Range(5, 25);
                    }
                    else if (currentFraction.MyFraction.fractionRace == FractionRace.GC)
                    {
                        currentFraction.fractionManager.goldenRepAmount += Random.Range(5, 25);
                    }
                    else if (currentFraction.MyFraction.fractionRace == FractionRace.Oboroten)
                    {
                        currentFraction.fractionManager.oborotRepAmount += Random.Range(5, 25);
                    }

                    AddMoney(currentFraction.MyFraction);

                    quast.Randomaiz();
                    quast.gameObject.SetActive(false);

                    break;
                }
            }
        }
    }

    public void AddMoney(FractionScriptableObject currentFraction)
    {
        foreach (MoneySlot mos in moneyManager.AllMoneySlot)
        {
            if (mos.money == currentFraction.fractionMoney)
            {
                mos.amount += Random.Range(5, 20);
                break;
            }
        }
    }
}
