using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameSettingsItem : MonoBehaviour
{
    public GameModeManager gameModeManager;
    public string settingsName;

    private bool _active;
    public bool active
    {
        get { return _active; }
        set
        {
            _active = value;

            if (active)
            {
                imageSettings.color = enableColor;
            }
            else
            {
                imageSettings.color = disableColor;
            }

            switch (settingsName)
            {
                case "Рой":
                    gameModeManager.RouSpawner.SetActive(active);
                    break;
                case "Мутация мобов":
                    foreach (GameObject Ultimate in gameModeManager.Ultimateobj) Ultimate.SetActive(active);
                    break;
                case "Голод хищников":
                    gameModeManager.NobjForDay = active;
                    foreach (GameObject Nobj in gameModeManager.Nobj) Nobj.SetActive(active);
                    break;
                case "Усиленные мобы":
                    gameModeManager.MobUpdater = active;
                    break;
                case "Больше ресурсов":
                    gameModeManager.MoreResoursSpawner.SetActive(active);
                    break;
                case "Густые зарасли":
                    gameModeManager.PlantsExpanded.SetActive(active);
                    break;
                case "Обер сет":
                    gameModeManager.OberSet.SetActive(active);
                    break;
                case "Медный сет":
                    gameModeManager.MediSet.SetActive(active);
                    break;
            }
        }
    }

    [Space]
    public Image imageSettings;

    [Space]
    public Color enableColor;
    public Color disableColor;

    public void ChangValueSettings()
    {
        active = !active;
    }
}