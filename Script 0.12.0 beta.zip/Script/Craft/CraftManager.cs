﻿using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
using UnityEngine.UI;
using TMPro;

public class CraftManager : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Скрипты")]
    public InventoryManager inventoryManager;
    public CraftQueueManager craftQueueManager;

    [Space]
    [Header("Текущая информация о крафте")]
    public FillCraftItemDetails currentCraftItem;

    [Space]
    [Header("Крафт предмета детали")]
    public Image craftItemImage;
    public TMP_Text craftItemName, craftItemDescription;

    [Space]
    [Header("Все крафты")]
    public List<CraftScriptableObject> allCrafts;
    public List<CraftResourceDetails> allResDetails;

    [Space]
    [Header("Объекты")]
    public GameObject craftItemButtonPrefab;

    [Space]
    [Header("Информация")]
    public Transform craftItemsPanel;
    public Button craftBtn;
    public Button buildingBtn;

    void Start()
    {
        FillItemDetailsHelper();
    }

    public void FillItemDetailsHelper() => currentCraftItem.FillItemDetails();

    public void LoadCraftItems(string craftType)
    {
        for (int i = 0; i < craftItemsPanel.childCount; i++) Destroy(craftItemsPanel.GetChild(i).gameObject);
        foreach (CraftScriptableObject cso in allCrafts)
        {
            if (cso.craftType.ToString().ToLower() == craftType.ToLower())
            {
                FillCraftItemDetails fillCraftItemDetails = Instantiate(craftItemButtonPrefab, craftItemsPanel).GetComponent<FillCraftItemDetails>(); //закешировал для оптимизации

                fillCraftItemDetails.currentCraftItem = cso;
                fillCraftItemDetails.craftManager = this;
                fillCraftItemDetails.image.sprite = cso.finalCraft.icon;
                fillCraftItemDetails.craftQueueManager = craftQueueManager;
                fillCraftItemDetails.inventoryManager = inventoryManager;
            }
        }
    }
}