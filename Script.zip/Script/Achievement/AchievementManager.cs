using System.Collections.Generic;
using UnityEngine;

public class AchievementManager : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    [Space]
    public List<AchievementScriptableObject> achievementScriptableObject;

    [HideInInspector]
    public List<AchievementItem> achievementItem;

    [Space]
    public GameObject AchievementPrefab;
    public Transform Content;

    private void Start()
    {
        foreach (AchievementScriptableObject achievementScriptable in achievementScriptableObject) // ��������� ��� ������
        {
            AchievementItem achievement = Instantiate(AchievementPrefab, Content).GetComponent<AchievementItem>();
            achievementItem.Add(achievement);

            achievement.achievementManager = this;
            achievement.dataSaveLoad = dataSaveLoad;

            achievement.achievementScriptableObject = achievementScriptable;
            achievement.achievementIcon.sprite = achievementScriptable.achievementIcon;
            achievement.achievementText.text = achievementScriptable.name;

            achievement.rewardIcon.sprite = achievementScriptable.rewardIcon;
            achievement.rewardText.text = achievementScriptable.rewardAmount.ToString();

            achievement.sliderProgress.maxValue = achievementScriptable.progressAmount;
            achievement.sliderProgress.value = 0;

            achievement.claimProgress = false;
        }
        
        for (int i = 0; i < DataSaveLoad.instance.data.nameAchievement.Length; i++)
        {
            AchievementScriptableObject achievementScriptableObject = Resources.Load<AchievementScriptableObject>($"AchievementScriptableObject/{DataSaveLoad.instance.data.nameAchievement[i]}");

            achievementItem[i].sliderProgress.value = DataSaveLoad.instance.data.progressAchievement[i];
            achievementItem[i].claimProgress = DataSaveLoad.instance.data.rewardAchievement[i];

            if(achievementItem[i].sliderProgress.value >= achievementItem[i].sliderProgress.maxValue)
            {
                achievementItem[i].buttonAchievement.interactable = true;
            }
            else
            {
                achievementItem[i].buttonAchievement.interactable = false;
            }
        }
    }

    public void ViewComplite(AchievementScriptableObject achievementScriptable)
    {
        IventViewer.instance.IventView(achievementScriptable.achievementIcon, "Достижение выполнено: " + achievementScriptable.name);
    }
}