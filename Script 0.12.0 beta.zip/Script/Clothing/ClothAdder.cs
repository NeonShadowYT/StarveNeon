using System.Collections.Generic;
using UnityEngine;

public class ClothAdder : MonoBehaviour //Ваш скрипт должен иметь название "ClothAdder" 
{
    public Indicators indicators;
    public PhotonSetManager photonSetManager; // синхранизация в мультиплеере

    [Space]
    public Transform[] allArmorClothes;
    public Transform allBackpackClothes;
    public Transform allShieldClothes;

    [Space]
    public ArmorManager armorManager;
    public ArmorManager backpackManager;
    public ArmorManager shieldManager;

    [Space]
    public InventorySlot armorSlot;
    public InventorySlot backpackSlot;
    public InventorySlot shieldSlot;

    public void UpdateClothes()
    {
        indicators.Armor = 0;
        indicators.ColdArmor = 0;
        indicators.Water = 0;
        indicators.Infected = 0;
        indicators.JumpPower = 0;
        indicators.StormArmor = 0;

        if (armorManager != null)
        {
            for (int ii = 0; ii < allArmorClothes.Length; ii++)
            {
                for (int i = 0; i < allArmorClothes[ii].childCount; i++) 
                {
                    allArmorClothes[ii].GetChild(i).gameObject.SetActive(false);

                    indicators.customCharacterController.walkingSpeed -= armorManager.SpeedPoints;
                    indicators.customCharacterController.runningSpeed -= armorManager.SpeedPoints;
                }
            }
        }

        if (backpackManager != null)
        {
            for (int i = 0; i < allBackpackClothes.childCount; i++)
            {
                allBackpackClothes.GetChild(i).gameObject.SetActive(false);

                indicators.customCharacterController.walkingSpeed -= backpackManager.SpeedPoints;
                indicators.customCharacterController.runningSpeed -= backpackManager.SpeedPoints;
            }
        }

        if (shieldManager != null)
        {
            for (int i = 0; i < allShieldClothes.childCount; i++)
            {
                allShieldClothes.GetChild(i).gameObject.SetActive(false);

                indicators.customCharacterController.walkingSpeed -= shieldManager.SpeedPoints;
                indicators.customCharacterController.runningSpeed -= shieldManager.SpeedPoints;
            }
        }

        armorManager = null;
        backpackManager = null;
        shieldManager = null;

        if (armorSlot.item != null && armorSlot.itemDurability >= 1) // для брони
        {
            for (int ii = 0; ii < allArmorClothes.Length; ii++)
            {
                for (int i = 0; i < allArmorClothes[ii].childCount; i++)
                {
                    GameObject clothObj = allArmorClothes[ii].GetChild(i).gameObject;

                    if (armorSlot.item.inHandName == clothObj.name)
                    {
                        if (photonSetManager != null) photonSetManager.SetArmor(true, i);

                        armorManager = clothObj.GetComponent<ArmorManager>();

                        if (armorManager != null)
                        {
                            armorManager.indicators = indicators;
                            armorManager.EquipArmor();
                        }
                        else 
                        { 
                            clothObj.SetActive(true);
                        }

                        break;
                    }
                }
            }
        }
        else if (photonSetManager != null) photonSetManager.SetArmor(false, 1);
        
        if (backpackSlot.item != null && backpackSlot.itemDurability >= 1) // для доп брони
        {
            for (int i = 0; i < allShieldClothes.childCount; i++)
            {
                GameObject clothObj = allShieldClothes.GetChild(i).gameObject;

                if (backpackSlot.item.inHandName == clothObj.name)
                {
                    if (photonSetManager != null) photonSetManager.SetBackpack(true, i);

                    backpackManager = clothObj.GetComponent<ArmorManager>();
                    backpackManager.indicators = indicators;

                    backpackManager.EquipArmor();
                    break;
                }
            }
        }
        else if (photonSetManager != null) photonSetManager.SetBackpack(false, 1);
        
        if (shieldSlot.item != null && shieldSlot.itemDurability >= 1) // для щитов
        {
            for (int i = 0; i < allShieldClothes.childCount; i++)
            {
                GameObject clothObj = allShieldClothes.GetChild(i).gameObject; 

                if (shieldSlot.item.inHandName == clothObj.name)
                {
                    if (photonSetManager != null) photonSetManager.SetShield(true, i);

                    shieldManager = clothObj.GetComponent<ArmorManager>();
                    shieldManager.indicators = indicators;

                    shieldManager.EquipArmor();
                    break;
                }
            }
        }
        else if (photonSetManager != null) photonSetManager.SetShield(false, 1);

        indicators.UpdateText();
    }
}