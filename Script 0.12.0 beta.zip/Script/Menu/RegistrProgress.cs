using UnityEngine;
using TMPro;

public class RegistrProgress : MonoBehaviour
{
    public TMP_Text buttonText;

    [Space]
    public bool regGJ;

    void Start()
    {
        DontDestroyOnLoad(gameObject);
        RegUpdate();
    }

    public void RegUpdate()
    {
        var isSignedIn = GameJolt.API.GameJoltAPI.Instance.CurrentUser != null;
        
        if (isSignedIn)
        {
            regGJ = true;
        }
        else
        {
            regGJ = false;
        }

        if (regGJ == true)
        {        
            if (buttonText != null) buttonText.text = "Зарегистрирован";
        }
        else
        {
            if (buttonText != null) buttonText.text = "Зарегистрировать";
        }
    }

    public void RegButton()
    {
        if (GameJolt.API.GameJoltAPI.Instance.HasUser) 
        {
            regGJ = true;
            RegUpdate();
        }
        else
        {
            GameJolt.UI.GameJoltUI.Instance.ShowSignIn( 
            (bool signInSuccess) =>
            {
                if (signInSuccess)
                {
                    regGJ = true;
                    RegUpdate();
                }
                else
                {
                    regGJ = false;
                    RegUpdate();
                }
            }, 
            (bool userFetchedSuccess) => 
            {
                if (userFetchedSuccess)
                {
                    regGJ = true;
                    RegUpdate();
                }
                else
                {
                    regGJ = false;
                    RegUpdate();
                }
            });
        }
    }
}