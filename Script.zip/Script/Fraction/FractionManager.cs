using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;

public class FractionManager : MonoBehaviour
{
    public static FractionManager instance;

    [Space]
    [Header("Данные")]
    public List<Fraction> allBiomFraction;

    [Space]
    public FractionScriptableObject currentFraction;
    public MoneySlot currentMoneySlot;

    [Space]
    [Header("Визуал")]
    public Image fractionImage;
    public TMP_Text fractionNameText;
    public TMP_Text fractionReputationText;

    public GameObject fractionPanel;

    [Space]
    [Header("Торговля")]
    public Transform tovareContent;
    public GameObject tovarePrefab;

    public List<TovareList> tovare;
    private Tovare currentTovare;

    [Space]
    [Header("Ксенксы")]
    public TMP_Text ksencseStatsReputationText;

    public int _ksenoRepAmount;
    public int ksenoRepAmount
    {
        get { return _ksenoRepAmount; }
        set
        {
            _ksenoRepAmount = value;
            ksencseStatsReputationText.text = "Репутация " + _ksenoRepAmount.ToString();

            for (int i = 0; i < allBiomFraction.Count; i++)
            {
                if (allBiomFraction[i].MyFraction.fractionRace == FractionRace.Ksencse)
                {
                    foreach (FractionNPS fractNps in allBiomFraction[i].fractionNps)
                    {
                        fractNps.CheckRep();
                    }
                }
            }
        }
    }

    [Space]
    [Header("Гк")]
    public TMP_Text gcStatsReputationText;

    public int _goldenRepAmount;
    public int goldenRepAmount
    {
        get { return _goldenRepAmount; }
        set
        {
            _goldenRepAmount = value;
            gcStatsReputationText.text = "Репутация " + _goldenRepAmount.ToString();

            for (int i = 0; i < allBiomFraction.Count; i++)
            {
                if (allBiomFraction[i].MyFraction.fractionRace == FractionRace.GC)
                {
                    foreach (FractionNPS fractNps in allBiomFraction[i].fractionNps)
                    {
                        fractNps.CheckRep();
                    }
                }
            }
        }
    }

    [Space]
    [Header("Оборотни")]
    public TMP_Text oborotenStatsReputationText;

    public int _oborotRepAmount;
    public int oborotRepAmount
    {
        get { return _oborotRepAmount; }
        set
        {
            _oborotRepAmount = value;
            oborotenStatsReputationText.text = "Репутация " + _oborotRepAmount.ToString();

            for (int i = 0; i < allBiomFraction.Count; i++)
            {
                if (allBiomFraction[i].MyFraction.fractionRace == FractionRace.Oboroten)
                {
                    foreach (FractionNPS fractNps in allBiomFraction[i].fractionNps)
                    {
                        fractNps.CheckRep();
                    }
                }
            }
        }
    }

    [Space]
    [Header("Стейси")]
    public TMP_Text stasyStatsReputationText;

    public int _stasyRepAmount;
    public int stasyRepAmount
    {
        get { return _stasyRepAmount; }
        set
        {
            _stasyRepAmount = value;
            stasyStatsReputationText.text = "Репутация " + _stasyRepAmount.ToString();

            for (int i = 0; i < allBiomFraction.Count; i++)
            {
                if (allBiomFraction[i].MyFraction.fractionRace == FractionRace.Stasy)
                {
                    foreach (FractionNPS fractNps in allBiomFraction[i].fractionNps)
                    {
                        fractNps.CheckRep();
                    }
                }
            }
        }
    }

    private void Awake() => instance = this;

    private void Start()
    {
        ksenoRepAmount = DataSaveLoad.instance.data.ksenoRepAmount;
        goldenRepAmount = DataSaveLoad.instance.data.goldenRepAmount;
        oborotRepAmount = DataSaveLoad.instance.data.oborotRepAmount;
        stasyRepAmount = DataSaveLoad.instance.data.stasyRepAmount;
    }

    public void Function(Table _table)
    {
        currentFraction = _table.fraction;

        switch (currentFraction.fractionRace)
        {
            case FractionRace.Ksencse:
                fractionReputationText.text = ksenoRepAmount.ToString();
                break;
            case FractionRace.GC:
                fractionReputationText.text = goldenRepAmount.ToString();
                break;
            case FractionRace.Oboroten:
                fractionReputationText.text = oborotRepAmount.ToString();
                break;
            case FractionRace.Stasy:
                fractionReputationText.text = stasyRepAmount.ToString();
                break;
        }

        fractionImage.sprite = currentFraction.FractionIcon;
        fractionNameText.text = currentFraction.FractionName;

        CheckCurrentMoney();

        fractionPanel.SetActive(true);
        tovare = currentFraction.Tovare;

        LoadTovareItems();
    }

    public void Close() => fractionPanel.SetActive(false);

    public void AddMoney(MoneyItem money)
    {
        MoneyManager.instance.CurrentAddMoney(money);

        if (currentMoneySlot != null && currentTovare != null) currentTovare.UpdateTovare(currentMoneySlot);
    }

    public void LoadTovareItems()
    {
        for (int i = 0; i < tovareContent.childCount; i++) Destroy(tovareContent.GetChild(i).gameObject);

        for (int i = 0; i < currentFraction.Tovare.Count; i++)
        {
            Tovare currentTovare = Instantiate(tovarePrefab, tovareContent).GetComponent<Tovare>(); // У СУА ИЗМЕНИ ЧТОБЫ БЕЗ ИНСТАНТИЭЙТОВ // НУ ТРАТЬ ВРЕМЯ НА НАСТРОЙКУ КАЖДОГО ЧИХА УААА //СОГЛ УЙНЯ КАКАЯ-ТО УАААААААААА
            currentTovare.item = currentFraction.Tovare[i].TovareItem;

            switch (currentFraction.fractionRace)
            {
                case FractionRace.Ksencse:
                    if (ksenoRepAmount >= 75) currentTovare.price = currentFraction.Tovare[i].TovarePrice / 2;
                    else if (ksenoRepAmount <= 15) currentTovare.price = currentFraction.Tovare[i].TovarePrice * 2;
                    break;
                case FractionRace.GC:
                    if (goldenRepAmount >= 65) currentTovare.price = currentFraction.Tovare[i].TovarePrice / 2;
                    else if (goldenRepAmount <= 10) currentTovare.price = currentFraction.Tovare[i].TovarePrice * 2;
                    break;
                case FractionRace.Oboroten:
                    if (oborotRepAmount >= 80) currentTovare.price = currentFraction.Tovare[i].TovarePrice / 2;
                    else if (oborotRepAmount <= 15) currentTovare.price = currentFraction.Tovare[i].TovarePrice * 2;
                    break;
                case FractionRace.Stasy:
                    if (stasyRepAmount >= 70) currentTovare.price = currentFraction.Tovare[i].TovarePrice / 2;
                    else if (stasyRepAmount <= 20) currentTovare.price = currentFraction.Tovare[i].TovarePrice * 2;
                    break;
            }

            currentTovare.UpdateTovare(currentMoneySlot);
        }
    }

    public void CheckCurrentMoney() => MoneyManager.instance.CheckCurrentMoney(currentFraction);
}