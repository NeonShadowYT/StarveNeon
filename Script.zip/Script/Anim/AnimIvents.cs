using UnityEngine;

public class AnimIvents : MonoBehaviour
{
    public CustomCharacterController customCharacterController;
    public QuickslotInventory quickslotInventory;
    public RunEffect runEffect;
    public AudioStep audioStep;
    public Animator anim;

    public void OnStep()
    {
        if (customCharacterController != null)
        {
            if (customCharacterController.currentSpeed >= 0.05f)
            {
                runEffect.RunEffectManager();
                audioStep.AudioStepManager();
            }
        }
    }

    public void OnAudioHit()
    {
        if (customCharacterController != null)
        {
            customCharacterController.StartHit();
        }
    }

    public void RandomAnimated()
    {
        anim.SetInteger("RandomAnim", Random.Range(0, 4));
    }

    public void OnAudioReload()
    {
        if (quickslotInventory != null)
        {
            quickslotInventory.AudioReload();
        }
    }

    public void OnEndReload()
    {
        if (quickslotInventory != null)
        {
            quickslotInventory.EndReload();
        }
    }

    public void EndAddItem() 
    {
        anim.SetBool("addItem", false);
    }

    public void EndSmenaItem() 
    {
        anim.SetBool("Smena", false);
    }
}
