using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using TMPro;

public class Launcher : MonoBehaviourPunCallbacks
{
    public DataSaveLoad dataSaveLoad;

    public int gameModeID = 10;
    public string region = "ru";

    [Space]
    [Header("Меню")]
    public TMP_Text onlineText;

    [Space]
    [Header("Вылазки")]
    public TMP_InputField roomNameInputField;

    public TMP_Text roomNameText;
    public TMP_Text errorText;

    public Transform _roomList;
    public GameObject roomButtonPrefab;

    public Transform playerList;
    public GameObject playerNamePrefab;

    public Button startGameButton;

    void Start()
    {
        PhotonNetwork.AutomaticallySyncScene = true; //переносит всех игроков за создателем лобби
        PhotonNetwork.NickName = dataSaveLoad.data.playerNick;
        PhotonNetwork.GameVersion = dataSaveLoad.data.saveVersion;

        PhotonNetwork.ConnectUsingSettings();
        PhotonNetwork.ConnectToRegion(region);

        if (onlineText != null) //loading.SetActive(true);
        {
            onlineText.text = "Оффлайн";
        }
    }

    public override void OnConnectedToMaster()
    {
        Debug.Log("Присоеденился к мастер серверу");
        
        if (!PhotonNetwork.InLobby) PhotonNetwork.JoinLobby();
        else OnJoinedLobby();

        if (onlineText != null)
        {
            onlineText.text = "Онлайн";
        }

        //photonChatManager.OnStart();
    }

    public override void OnJoinedLobby() //если мы смогли подключиться к инету
    {
        Debug.Log("Присоеденился к лобби");
        //loading.SetActive(false);
    }

    public void StartGame()
    {
        Invoke(nameof(ChangSceneMP), 5f);
    }

    public void ChangGameModeID(int i)
    {
        gameModeID = i;
    }

    public void ChangSceneMP()
    {
        PhotonNetwork.LoadLevel(gameModeID);
    }

    public void CreateRoom() //создание комнаты
    {
        if (string.IsNullOrEmpty(roomNameInputField.text))
        {
            return;
        }

        PhotonNetwork.CreateRoom(roomNameInputField.text);
        //loading.SetActive(true);
    }

    public override void OnJoinedRoom() //зашли в лобби
    {
        roomNameText.text = PhotonNetwork.CurrentRoom.Name;

        Player[] players = PhotonNetwork.PlayerList;

        for (int i = 0; i < playerList.childCount; i++)
        {
            Destroy(playerList.GetChild(i).gameObject);
        }
        
        for (int i = 0; i < players.Length; i++)
        {
            OnPlayerEnteredRoom(players[i]);
        }

        startGameButton.interactable = PhotonNetwork.IsMasterClient; //мастер клиент, создатель лобби
        //room.SetActive(true);
    }

    public override void OnMasterClientSwitched(Player newMasterClient) //когда меняется мастер клиент
    {
        startGameButton.interactable = PhotonNetwork.IsMasterClient; //мастер клиент, создатель лобби
    }

    public override void OnCreateRoomFailed(short returnCode, string message) //ошибОчка
    {
        errorText.text = "ОшибОчка: " + message;

        //error.SetActive(true);
    }

    public void LeaveRoom() //выход из лобби
    {
        PhotonNetwork.LeaveRoom();

        //loading.SetActive(true);
    }

    public override void OnLeftRoom() //при загрузке после выхода из лобби
    {
        //title.SetActive(true);
    }

    public void JoinRoom(RoomInfo info) //подключение к комнате
    {
        PhotonNetwork.JoinRoom(info.Name);

        //loading.SetActive(true);
    }

    public override void OnRoomListUpdate(List<RoomInfo> roomList) //когда создатся комната
    {
        if (_roomList == null) return;

        for (int i = 0; i < _roomList.childCount; i++)
        {
            Destroy(_roomList.GetChild(i).gameObject);
        }

        for (int i = 0; i < roomList.Count; i++)
        {
            if (roomList[i].RemovedFromList) 
            {
                continue;
            }

            RoomListItem roomListItem = Instantiate(roomButtonPrefab, _roomList).GetComponent<RoomListItem>();

            roomListItem.launcher = this;
            roomListItem.SetUp(roomList[i]);
        }
    }

    public override void OnPlayerEnteredRoom(Player player) //когда игрок заходит в комнату
    {
        Instantiate(playerNamePrefab, playerList).GetComponent<PlayerListItem>().SetUp(player);
    }
}