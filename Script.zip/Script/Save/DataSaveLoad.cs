﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum RewardType { Wood, Rock, Cuprum, Gold, Diamond, Ametist, Redit, Izum, Core, Neolit, CharacterSkin, ItemSkin }
public class DataSaveLoad : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public static DataSaveLoad instance;
    public AchievementManager achievementManager;

    [Space]
    [Header("Game Jolt")]
    public int GameJoltScoreID;
    public int GameJoltDayID;

    [Space]
    public SaveData data;

    private void Awake() 
    {
        instance = this;
        
        Load();
    }

    public void Save()
    {
        if (SceneManager.GetActiveScene().name == "Меню")
        {
            BinarySavingSystem.Save(data);
            return;
        }

        data.health = Indicators.instance.healthSlider.value;
        data.food = Indicators.instance.foodSlider.value;
        data.water = Indicators.instance.waterSlider.value;
        data.cold = Indicators.instance.coldSlider.value;

        data.dayInt = FindObjectOfType<DayTime>().Day;

        data.itemNames = new string[InventoryManager.instance.slots.Count];
        data.itemAmounts = new int[InventoryManager.instance.slots.Count];
        data.itemDurability = new float[InventoryManager.instance.slots.Count];
        data.itemDestroy = new float[InventoryManager.instance.slots.Count];

        for (int i = 0; i < InventoryManager.instance.slots.Count; i++)
        {
            if (InventoryManager.instance.slots[i].item != null)
            {
                data.itemNames[i] = InventoryManager.instance.slots[i].item.name;
                data.itemAmounts[i] = InventoryManager.instance.slots[i].amount;
                data.itemDurability[i] = InventoryManager.instance.slots[i].durability;
                data.itemDestroy[i] = InventoryManager.instance.slots[i].destroyBar.fillAmount;
            }
        }

        List<string> craftsList = new List<string>();

        for (int i = 0; i < CraftManager.instance.allCraftItemDetails.Count; i++)
        {
            if (CraftManager.instance.allCraftItemDetails[i].currentCraftItem.verstLevel > 0)
            {
                craftsList.Add(CraftManager.instance.allCraftItemDetails[i].currentCraftItem.name);
            }
        }

        data.allCrafts = craftsList.ToArray();

        for (int i = 0; i < MoneyManager.instance.AllMoneySlot.Count; i++)
        {
            switch (MoneyManager.instance.AllMoneySlot[i].money.moneyType)
            {
                case MoneyType.Ksencse:
                    data.ksenoAmount = MoneyManager.instance.AllMoneySlot[i].amount;
                    break;
                case MoneyType.GC:
                    data.goldenAmount = MoneyManager.instance.AllMoneySlot[i].amount;
                    break;
                case MoneyType.Oboroten:
                    data.oborotAmount = MoneyManager.instance.AllMoneySlot[i].amount;
                    break;
                case MoneyType.Stasy:
                    data.stasyAmount = MoneyManager.instance.AllMoneySlot[i].amount;
                    break;
                case MoneyType.Texno:
                    data.texnoAmount = MoneyManager.instance.AllMoneySlot[i].amount;
                    break;
            }
        }

        data.ksenoRepAmount = FractionManager.instance.ksenoRepAmount;
        data.goldenRepAmount = FractionManager.instance.goldenRepAmount;
        data.oborotRepAmount = FractionManager.instance.oborotRepAmount;
        data.stasyRepAmount = FractionManager.instance.stasyRepAmount;

        data.passComplite = new bool[PassManager.instance.Pass.Count];

        for (int i = 0; i < PassManager.instance.Pass.Count; i++)
        {
            data.passComplite[i] = PassManager.instance.Pass[i].PassComplite;
        }

        data.nameAchievement = new string[achievementManager.achievementScriptableObject.Count];
        data.progressAchievement = new float[achievementManager.achievementScriptableObject.Count];
        data.rewardAchievement = new bool[achievementManager.achievementScriptableObject.Count];

        for (int i = 0; i < achievementManager.achievementScriptableObject.Count; i++)
        {
            data.nameAchievement[i] = achievementManager.achievementScriptableObject[i].name;
            data.progressAchievement[i] = achievementManager.achievementItem[i].sliderProgress.value;
            data.rewardAchievement[i] = achievementManager.achievementItem[i].claimProgress;
        }

        BinarySavingSystem.Save(data);

        if (GameJolt.API.GameJoltAPI.Instance != null && GameJolt.API.GameJoltAPI.Instance.CurrentUser != null)
        {
            GameJolt.API.Scores.Add(data.playerScore, "", GameJoltScoreID);
            GameJolt.API.Scores.Add(data.dayInt, "", GameJoltDayID);
        }
    }

    private void Load()
    {
        SaveData _data = BinarySavingSystem.Load(data);

        if (_data != null) 
        {
            data = _data;
        }
        else
        {
            Save();
        }
    }

    public void Death()
    {
        data.biom = "База";

        Indicators.instance.healthSlider.value = 200f;
        Indicators.instance.foodSlider.value = 200f;
        Indicators.instance.waterSlider.value = 200f;
        Indicators.instance.coldSlider.value = 200f;

        for (int i = 0; i < InventoryManager.instance.slots.Count; i++)
        {
            InventoryManager.instance.slots[i].item = null;
            InventoryManager.instance.slots[i].amount = 0;
            InventoryManager.instance.slots[i].durability = 0f;
            InventoryManager.instance.slots[i].destroyBar.fillAmount = 0f;
        }

        Save();
        Launcher.instance.ChangScene();
    }

    public void Live()
    {
        data.biom = "База";
        
        Save();
        Launcher.instance.ChangScene();
    }

    public void Quit() => Application.Quit();

    private void OnApplicationQuit()
    {
        switch (SceneManager.GetActiveScene().name)
        {
            case "База":
                Save();
                break;
            case "Меню":
                Save();
                break;
            default:
                Indicators.instance.healthSlider.value = 200f;
                Indicators.instance.foodSlider.value = 200f;
                Indicators.instance.waterSlider.value = 200f;
                Indicators.instance.coldSlider.value = 200f;

                for (int i = 0; i < InventoryManager.instance.slots.Count; i++)
                {
                    InventoryManager.instance.slots[i].item = null;
                    InventoryManager.instance.slots[i].amount = 0;
                    InventoryManager.instance.slots[i].durability = 0f;
                    InventoryManager.instance.slots[i].destroyBar.fillAmount = 0f;
                }

                Save();
                break;
        }
    }
}
