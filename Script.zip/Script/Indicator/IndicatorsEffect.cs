using UnityEngine;
using UnityEngine.UI;

public class IndicatorsEffect : MonoBehaviour
{
    [Space]
    [Header("Скрипты")]
    public Indicators indicators;
    public CustomCharacterController customCharacterController;

    [Space] 
    [Header("Индикаторы")]
    public float healthModifer;
    public float foodModifer;
    public float waterModifer;
    public float coldModifer;

    [Space]
    [Header("Движение")]
    public float speedModifer;
    public float jumpModifer;

    [Space]
    [Header("Исключения")]
    public IndicatorsEffect[] exclusionEffect;

    [Space]
    [Header("Дополнения")]
    public IndicatorsEffect[] maxAdditionEffect;
    public IndicatorsEffect[] minAdditionEffect;

    public Slider additionSlider;

    [Space]
    [Header("При появлении")]
    public IndicatorsEffect[] startAddEffect;
    public IndicatorsEffect[] startRemoveEffect;

    [Space]
    public GameObject startParticle;

    [Space]
    [Header("При исчезновении")]
    public IndicatorsEffect[] endAddEffect;
    public IndicatorsEffect[] endRemoveEffect;

    [Space]
    public GameObject endParticle;

    [Space]
    [Header("Время")]
    public float startTimeEffect;
    public float genModifer = 1f;
    public bool infinity;

    private float _timeEffect;
    public float timeEffect
    {
        get { return _timeEffect; }
        set
        {
            _timeEffect = value;

            if (_timeEffect <= 0)
            {
                gameObject.SetActive(false);
            }
        }
    }

    private bool equip;

    private void OnEnable()
    {
        bool exclusion = false;

        for (int i = 0; i < exclusionEffect.Length; i++)
        {
            if (exclusionEffect[i].timeEffect >= 1)
            {
                exclusion = true;
                timeEffect = 0f;
                break;
            }
        }

        if (exclusion == true) return;

        for (int i = 0; i < startAddEffect.Length; i++)
        {
            startAddEffect[i].gameObject.SetActive(true);
        }

        for (int i = 0; i < startRemoveEffect.Length; i++)
        {
            startRemoveEffect[i].timeEffect = 0f;
        }

        if (startParticle != null) 
        {
            startParticle.SetActive(true);
        }

        timeEffect = startTimeEffect * genModifer;

        if (equip == false)
        {
            customCharacterController.runningSpeed += speedModifer;
            customCharacterController.walkingSpeed += speedModifer;
            customCharacterController.jumpForce += jumpModifer;

            equip = true;
        }

        CancelInvoke();

        if (additionSlider == null)
        {
            InvokeRepeating(nameof(EffectModifer), 1f, 1f);
        }
        else
        {
            InvokeRepeating(nameof(AdditionModifer), 1f, 1f);
        }
    }

    private void OnDisable()
    {
        for (int i = 0; i < endAddEffect.Length; i++)
        {
            endAddEffect[i].gameObject.SetActive(true);
        }

        for (int i = 0; i < endRemoveEffect.Length; i++)
        {
            endRemoveEffect[i].timeEffect = 0f;
        }

        if (endParticle != null) 
        {
            endParticle.SetActive(true);
        }

        if (equip == true)
        {
            customCharacterController.runningSpeed -= speedModifer;
            customCharacterController.walkingSpeed -= speedModifer;
            customCharacterController.jumpForce -= jumpModifer;

            equip = false;
        }
        
        CancelInvoke();
    }

    private void EffectModifer()
    {
        indicators.ChangeFoodAmount(foodModifer);
        indicators.ChangeWaterAmount(waterModifer);
        indicators.ChangeHealthAmount(healthModifer);
        indicators.ChangeColdAmount(coldModifer);
            
        if (infinity == false) timeEffect--;
    }

    private void AdditionModifer()
    {
        EffectModifer();

        if (additionSlider.value > additionSlider.maxValue * 0.95f)
        {
            for (int i = 0; i < maxAdditionEffect.Length; i++)
            {
                maxAdditionEffect[i].gameObject.SetActive(true);
            }
        }
        else if (additionSlider.value < additionSlider.maxValue * 0.05f)
        {
            for (int i = 0; i < minAdditionEffect.Length; i++)
            {
                minAdditionEffect[i].gameObject.SetActive(true);
            }
        }
    }
}