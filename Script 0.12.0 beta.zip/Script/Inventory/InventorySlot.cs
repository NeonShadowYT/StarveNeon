﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;

public enum SlotType { None, Storage }
public class InventorySlot : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Предмет и его количество")]
    public ItemScriptableObject item;
    public TMP_Text itemAmountText;

    [Space]
    public int amount;
    public float _itemDurability;
    public float itemDurability
    {
        get { return _itemDurability; }
        set 
        {
            _itemDurability = value;

            UpdateDurabilityBar();
        }
    }

    [Space]
    [Header("Иконка и прочность")]
    public Image iconGO;
    public Image durabilityBar;
    public Image destroyBar;

    [Space]
    [Header("Информация о слоте")]
    public SlotType slotType = SlotType.None;
    public ClothType clothType = ClothType.None;

    public void SetIcon(Sprite icon)
    {
        iconGO.color = new Color(1, 1, 1, 1);
        iconGO.sprite = icon;
    }

    public void UpdateDurabilityBar()
    {
        if (item == null || item.isDurability == false) 
        {
            durabilityBar.fillAmount = 0f;
            destroyBar.fillAmount = 0f;
            return;
        }

        durabilityBar.fillAmount = itemDurability / item.maximumDurability;
    }

    public void SubtractDurabilityPerHit(float itemDestroy)
    {
        if (item == null || item.isDurability == false) return;

        itemDurability -= itemDestroy;
    }
}