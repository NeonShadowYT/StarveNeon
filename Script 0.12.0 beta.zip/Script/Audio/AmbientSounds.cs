using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmbientSounds : MonoBehaviour
{
    [Space]
    public AudioSource shortSound;
    public AudioSource longSound;
    public List<AudioClip> shortSoundClip;
    public List<AudioClip> longSoundClip;

    public float nextMinDelay = 30;
    public float nextMaxDelay = 60;

    public float nextLongTime = 2;

    IEnumerator Start()
    {
        StartCoroutine(nameof(ShortPlay));

        int random = 0;
        int currentLongSound = 0;

        while(true)
        {
            random = Random.Range(0, longSoundClip.Count);

            if (random == currentLongSound) random = random + 1;
            if (random == longSoundClip.Count) random = 0;

            currentLongSound = random;
            longSound.clip = longSoundClip[random];
            longSound.Play();

            yield return new WaitForSeconds(longSound.clip.length - nextLongTime);
        }
    }

    IEnumerator ShortPlay()
    {
        while(true)
        {
            yield return new WaitForSeconds(Random.Range(nextMinDelay, nextMaxDelay));
            shortSound.clip = shortSoundClip[Random.Range(0, shortSoundClip.Count)];
            shortSound.Play();
        }
    }
}