using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class Indicators : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public static Indicators instance;
    public GenStats genStats;

    [Space]
    [Header("Эффекты")]
    public IndicatorsEffect healEffect;
    public IndicatorsEffect waterEffect;

    [Space]
    public IndicatorsEffect webEffect;
    public IndicatorsEffect jumpEffect;
    public IndicatorsEffect speedEffect;

    [Space]
    public IndicatorsEffect infectionEffect;
    public IndicatorsEffect poisonEffect;

    [Space]
    public IndicatorsEffect hotEffect;
    public IndicatorsEffect fireEffect;

    [Space]
    public IndicatorsEffect coldEffect;
    public IndicatorsEffect frostEffect;

    [Space]
    public IndicatorsEffect damageEffect;
    public IndicatorsEffect bloodEffect;

    [Space]
    public IndicatorsEffect changBiomEffect;

    [Space]
    [Header("Интерфейс")]
    [SerializeField] private TMP_Text healthText;
    [SerializeField] private TMP_Text foodText;
    [SerializeField] private TMP_Text waterText;
    [SerializeField] private TMP_Text сoldText;

    [Space]
    public Slider healthSlider;
    public Slider foodSlider;
    public Slider waterSlider;
    public Slider coldSlider;

    private float secondsToEmptyFood;
    private float secondsToEmptyWater;
    private float secondsToEmptyHealth;
    private float secondsToEmptyCold;

    private float saveSecondsToEmptyCold;

    private void Awake() => instance = this;

    private void Start()
    {
        LoadIndicators();
        ComplexityEquip();
        MetabalizmEquip();

        saveSecondsToEmptyCold = secondsToEmptyCold;

        coldEffect.genModifer *= genStats.coldPlus;
        hotEffect.genModifer *= genStats.coldPlus;
        
        fireEffect.genModifer *= genStats.adColdPlus;
        frostEffect.genModifer *= genStats.snowColdPlus;

        InvokeRepeating(nameof(IndicatorsUpdate), 1f, 1f);
    }

    private void LoadIndicators()
    {
        healthSlider.value = DataSaveLoad.instance.data.health;
        foodSlider.value = DataSaveLoad.instance.data.food;
        waterSlider.value = DataSaveLoad.instance.data.water;
        coldSlider.value = DataSaveLoad.instance.data.cold;
    }

    private void IndicatorsUpdate()
    {
        foodSlider.value -= foodSlider.maxValue / secondsToEmptyFood;
        waterSlider.value -= waterSlider.maxValue / secondsToEmptyWater;
        coldSlider.value -= coldSlider.maxValue / secondsToEmptyCold;

        if (foodSlider.value <= 0.05f) 
        {
            healthSlider.value -= healthSlider.maxValue / secondsToEmptyHealth;
        }

        if (waterSlider.value <= 0.05f)
        {
            healthSlider.value -= healthSlider.maxValue / secondsToEmptyHealth;
        }

        if (coldSlider.value <= 0.05f)
        {
            healthSlider.value -= healthSlider.maxValue / secondsToEmptyHealth;
        }

        if (healthSlider.value <= 0.05f)
        {
            DataSaveLoad.instance.Death();
        }
        else
        {
            if (healthSlider.value < healthSlider.maxValue && foodSlider.value >= foodSlider.maxValue * 0.75f &&
             waterSlider.value >= waterSlider.maxValue * 0.75f && coldSlider.value >= coldSlider.maxValue * 0.75f)
            {
                healEffect.gameObject.SetActive(true);
                healEffect.infinity = true;
            }
            else
            {
                healEffect.gameObject.SetActive(false);
                healEffect.infinity = false;
            }
        }

        healthText.text = healthSlider.value.ToString("F0");
        foodText.text = foodSlider.value.ToString("F0");
        waterText.text = waterSlider.value.ToString("F0");
        сoldText.text = coldSlider.value.ToString("F0");
    }

    public void ChangeHealthAmount(float changeValue)
    {
        if (changeValue == 0) return;
        StartCoroutine(SmoothChange(healthSlider, changeValue * genStats.regenPlus));
    }

    public void ChangeFoodAmount(float changeValue)
    {
        if (changeValue == 0) return;
        StartCoroutine(SmoothChange(foodSlider, changeValue * genStats.foodPlus));
    }

    public void ChangeWaterAmount(float changeValue)
    {
        if (changeValue == 0) return;
        StartCoroutine(SmoothChange(waterSlider, changeValue * genStats.waterPlus));
    }

    public void ChangeColdAmount(float changeValue)
    {
        if (changeValue == 0) return;
        StartCoroutine(SmoothChange(coldSlider, changeValue * genStats.coldPlus));
    }

    private IEnumerator SmoothChange(Slider slider, float targetValue)
    {
        float elapsedTime = 0f;
        float smoothTime = 0.25f;
        float changeSpeed = targetValue / smoothTime;

        while (elapsedTime < smoothTime)
        {
            slider.value += changeSpeed * Time.deltaTime;
            elapsedTime += Time.deltaTime;
            yield return null;
        }
    }

    public void Night()
    {
        if (DayTime.instance.night)
        {
            switch (ArmorStats.instance.cold)
            {
                case 0:
                    secondsToEmptyCold = saveSecondsToEmptyCold *= 0.4f;
                    break;
                case 1:
                    secondsToEmptyCold = saveSecondsToEmptyCold *= 0.5f;
                    break;
                case 2:
                    secondsToEmptyCold = saveSecondsToEmptyCold * 0.6f;
                    break;
                case 3:
                    secondsToEmptyCold = saveSecondsToEmptyCold * 0.7f;
                    break;
                case 4:
                    secondsToEmptyCold = saveSecondsToEmptyCold * 0.8f;
                    break;
            }

            //CustomCharacterController.instance.walkingSpeed *= genStats.nightSpeed;
            //CustomCharacterController.instance.runningSpeed *= genStats.nightSpeed;
        }
        else
        {
            switch (ArmorStats.instance.cold)
            {
                case 1:
                    secondsToEmptyCold = saveSecondsToEmptyCold * 1.1f;
                    break;
                case 2:
                    secondsToEmptyCold = saveSecondsToEmptyCold * 1.2f;
                    break;
                case 3:
                    secondsToEmptyCold = saveSecondsToEmptyCold * 1.3f;
                    break;
                case 4:
                    secondsToEmptyCold = saveSecondsToEmptyCold * 1.4f;
                    break;
            }

            //CustomCharacterController.instance.walkingSpeed *= genStats.daySpeed;
            //CustomCharacterController.instance.runningSpeed *= genStats.daySpeed;
        }
    }

    private void ComplexityEquip()
    {
        switch (DataSaveLoad.instance.data.complexity)
        {
            case 0:
                secondsToEmptyFood = 400f;
                secondsToEmptyWater = 380f;
                secondsToEmptyHealth = 75f;
                secondsToEmptyCold = 640f;
                break;
            case 1:
                secondsToEmptyFood = 360f;
                secondsToEmptyWater = 340f;
                secondsToEmptyHealth = 60f;
                secondsToEmptyCold = 600f;
                break;
            case 2:
                secondsToEmptyFood = 320f;
                secondsToEmptyWater = 300f;
                secondsToEmptyHealth = 45f;
                secondsToEmptyCold = 560f;
                break;
            case 3:
                secondsToEmptyFood = 280f;
                secondsToEmptyWater = 260f;
                secondsToEmptyHealth = 30f;
                secondsToEmptyCold = 520f;
                break;
        }
    }

    private void MetabalizmEquip()
    {
        for (int i = genStats.ksenoTypeMetabalizm; i < 0; i--)
        {
            if (genStats.ksenoTypeMetabalizm > 0)
            {
                genStats.ksenoTypeMetabalizm -= 1;
                
                secondsToEmptyHealth += 5;
                secondsToEmptyFood += 25;
                secondsToEmptyWater += 25;
                secondsToEmptyCold += 50;
            }
            else if (genStats.ksenoTypeMetabalizm < 0)
            {
                genStats.ksenoTypeMetabalizm += 1;

                secondsToEmptyHealth -= 15;
                secondsToEmptyFood -= 75;
                secondsToEmptyWater -= 75;
                secondsToEmptyCold -= 100;
            }

            if (secondsToEmptyHealth < 15)
            {
                secondsToEmptyHealth = 15;
            }

            if (secondsToEmptyWater < 25)
            {
                secondsToEmptyWater = 25;
            }

            if (secondsToEmptyFood < 25)
            {
                secondsToEmptyFood = 25;
            }
            
            if (secondsToEmptyCold < 25)
            {
                secondsToEmptyCold = 25;
            }
        }
    }
}