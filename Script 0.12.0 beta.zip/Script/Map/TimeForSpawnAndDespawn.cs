using System.Collections;
using UnityEngine;

public class TimeForSpawnAndDespawn : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [HideInInspector] public GlobalInvoker globalInvoker;

    [Space]
    [Header("Настройки")]
    public bool spawn;
    public bool main;

    [Space]
    [Header("Ссылки")]
    public GameObject[] ItemObj;

    [Space]
    [Header("Рандом при старте")]
    public int startRandom;
    public bool failRandom;

    [Space]
    [Header("Эффект")]
    public GameObject Effect;

    [Space]
    [Header("Время")]
    public float TimeBtwSpawns;
    public float CurrentTime;

    void Start()
    {
        globalInvoker = FindObjectOfType<GlobalInvoker>();
        if (globalInvoker == null) return;

        if (main) 
        {
            TimeBtwSpawns *= globalInvoker.customCharacterController.indicators.MyPlants;
        }

        CurrentTime = TimeBtwSpawns;
        StartRandom();
    }

    void StartRandom()
    {
        if (startRandom <= 0) return;

        startRandom -= 1;
        CurrentTime = 0;

        if (failRandom == true)
        {
            if (Random.Range(0, 3) >= 2)
            {
                ChangSpawn();
            }
        }
        else
        {
            ChangSpawn();
        }

        if (startRandom > 0) StartRandom();
    }

    public void ChangSpawn()
    {
        if (globalInvoker.sleepAI == true) CurrentTime -= 5;
        else CurrentTime -= 10;

        if (CurrentTime > 0) return;
        CurrentTime = TimeBtwSpawns;

        if (Effect != null) 
        {
            Effect.SetActive(true);
        }

        if (spawn)
        {
            ItemObj[Random.Range(0, ItemObj.Length)].SetActive(true);
        }
        else 
        {
            ItemObj[Random.Range(0, ItemObj.Length)].SetActive(false);
        }
    }

    void OnTriggerEnter(Collider col)
    {
        if(col.gameObject.CompareTag("Player"))
        {
            globalInvoker.spawnAndDespawn.Add(this);
        }
    }

    void OnTriggerExit(Collider col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            globalInvoker.spawnAndDespawn.Remove(this);
        }
    }
}