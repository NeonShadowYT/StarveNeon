using UnityEngine;
using TMPro;

public class ArmorStats : MonoBehaviour
{
    public static ArmorStats instance;

    private int _armor;
    public int armor
    {
        get { return _armor; }
        set
        {
            _armor = value;
        }
    }
    
    private int _water;
    public int water
    {
        get { return _water; }
        set
        {
            _water = value;
        }
    }

    private int _speed;
    public int speed
    {
        get { return _speed; }
        set
        {
            _speed = value;
        }
    }
    
    private int _infected;
    public int infected
    {
        get { return _infected; }
        set
        {
            _infected = value;
        }
    }
    
    private int _storm;
    public int storm
    {
        get { return _storm; }
        set
        {
            _storm = value;
        }
    }

    private int _cold;
    public int cold
    {
        get { return _cold; }
        set
        {
            _cold = value;
            Indicators.instance.Night();
        }
    }

    private int _jump;
    public int jump
    {
        get { return _jump; }
        set
        {
            _jump = value;
        }
    }

    [Space]
    [Header("Интерфейс")]
    [SerializeField] private TMP_Text armorText;
    [SerializeField] private TMP_Text waterText;
    [SerializeField] private TMP_Text speedText;
    [SerializeField] private TMP_Text infectedText;
    [SerializeField] private TMP_Text stormText;
    [SerializeField] private TMP_Text coldText;
    [SerializeField] private TMP_Text jumpText;

    private void Awake() => instance = this;

    public void ChangStats()
    {
        armorText.text = armor.ToString();
        waterText.text = water.ToString();
        speedText.text = speed.ToString();
        infectedText.text = infected.ToString();
        stormText.text = storm.ToString();
        coldText.text = cold.ToString();
        jumpText.text = jump.ToString();
    }
}
