using UnityEngine;
using UnityEngine.Advertisements;

public class RewardedAds : MonoBehaviour, IUnityAdsLoadListener, IUnityAdsShowListener
{
    public string appKeyAndroid;
    public DataSaveLoad dataSaveLoad;
    public RewardType rewardType;

    public void AdsReward(RewardType _rewardType)
    {
        rewardType = _rewardType;
    }

    public void ShowAd()
    {
        Advertisement.Load(appKeyAndroid, this);
        Advertisement.Show(appKeyAndroid, this);
    }

    public void OnUnityAdsAdLoaded(string placementId)
    {
        Debug.Log("Реклама загружена: " + placementId);
    }

    public void OnUnityAdsFailedToLoad(string placementId, UnityAdsLoadError error, string message)
    {
        Debug.Log($"Не удалось загрузить рекламу: {error.ToString()} - {message}");
        ShowAd();
    }

    public void OnUnityAdsShowFailure(string placementId, UnityAdsShowError error, string message)
    {
        Debug.Log($"Не удалось показать рекламу: {error.ToString()} - {message}");
        ShowAd();
    }

    public void OnUnityAdsShowStart(string placementId)
    {
        Debug.Log("Начался показ рекламы: " + placementId);
    }

    public void OnUnityAdsShowClick(string placementId)
    {
        Debug.Log("Нажатие на рекламу: " + placementId);

        switch(rewardType)
        {
            case RewardType.Wood :
                dataSaveLoad.data.woodValue += Random.Range(256, 512);
                break;
            case RewardType.Rock :
                dataSaveLoad.data.rockValue += Random.Range(128, 256);
                break;
            case RewardType.Cuprum :
                dataSaveLoad.data.cuprumValue += Random.Range(64, 128);
                break;
            case RewardType.Gold :
                dataSaveLoad.data.goldValue += Random.Range(32, 64);
                break;
            case RewardType.Diamond :
                dataSaveLoad.data.diamondValue += Random.Range(16, 32);
                break;
            case RewardType.Ametist :
                dataSaveLoad.data.ametistValue += Random.Range(8, 16);
                break;
            case RewardType.Redit :
                dataSaveLoad.data.reditValue += Random.Range(4, 8);
                break;
            case RewardType.Izum :
                dataSaveLoad.data.izumValue += Random.Range(2, 4);
                break;
            case RewardType.Core :
                dataSaveLoad.data.coreValue += Random.Range(1, 2);
                break;
            case RewardType.Neolit :
                dataSaveLoad.data.neolitValue += 1;
                break;
        }
    }

    public void OnUnityAdsShowComplete(string placementId, UnityAdsShowCompletionState showCompletionState)
    {
        if (showCompletionState.Equals(UnityAdsShowCompletionState.COMPLETED))
        {
            switch(rewardType)
            {
                case RewardType.Wood :
                    dataSaveLoad.data.woodValue += Random.Range(256, 512);
                    break;
               case RewardType.Rock :
                    dataSaveLoad.data.rockValue += Random.Range(128, 256);
                    break;
                case RewardType.Cuprum :
                    dataSaveLoad.data.cuprumValue += Random.Range(64, 128);
                    break;
                case RewardType.Gold :
                    dataSaveLoad.data.goldValue += Random.Range(32, 64);
                    break;
                case RewardType.Diamond :
                    dataSaveLoad.data.diamondValue += Random.Range(16, 32);
                    break;
                case RewardType.Ametist :
                    dataSaveLoad.data.ametistValue += Random.Range(8, 16);
                    break;
                case RewardType.Redit :
                    dataSaveLoad.data.reditValue += Random.Range(4, 8);
                    break;
                case RewardType.Izum :
                    dataSaveLoad.data.izumValue += Random.Range(2, 4);
                    break;
                case RewardType.Core :
                    dataSaveLoad.data.coreValue += Random.Range(1, 2);
                    break;
                case RewardType.Neolit :
                    dataSaveLoad.data.neolitValue += 1;
                    break;
            }
        }
    }
}