using UnityEngine;

[CreateAssetMenu(fileName = "Skins", menuName = "Neon Imperium/Skin/New Item Skins")]
public class ItemSkinScriptableObject : ScriptableObject
{
    public string Name;
    public Sprite Icon;

    public int Price;
}
