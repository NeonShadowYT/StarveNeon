using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class StolyresManager : MonoBehaviour
{   
    [Space]
    [Header("Текущие данные")]
    private StolyresScriptableObject currentStolyres;
    private int currentComplexity;

    [Space]
    [Header("UI")]
    public Image StoletyImage;

    public TMP_Text StoletyName;
    public TMP_Text StoletyDescription;

    void Start()
    {
        ChangeStolyres(Resources.Load<StolyresScriptableObject>($"StolyresScriptable/{DataSaveLoad.instance.data.stolyres}"));
        ChangeComplexity(DataSaveLoad.instance.data.complexity);
    }

    public void EquipStolyre()
    {
        DataSaveLoad.instance.data.stolyres = currentStolyres.name;
    }

    public void EquipComplexity()
    {
        DataSaveLoad.instance.data.complexity = currentComplexity;
    }

    public void ChangeStolyres(StolyresScriptableObject _stolyres)
    {
        currentStolyres = _stolyres;

        StoletyImage.sprite = currentStolyres.image;
        StoletyName.text = currentStolyres.name;
        StoletyDescription.text = currentStolyres.Description;
    }

    public void ChangeComplexity(int _complexity)
    {
        currentComplexity = _complexity;
    }
}
