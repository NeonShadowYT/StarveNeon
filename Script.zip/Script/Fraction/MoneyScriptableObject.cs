using UnityEngine;

public enum MoneyType { GC, Ksencse, Oboroten, Texno, BioTexno, Plants, Stasy }

[CreateAssetMenu(fileName = "Fraction", menuName = "Neon Imperium/Fraction/New Fraction Money")]
public class MoneyScriptableObject : ScriptableObject
{
    public MoneyType moneyType;
    public GameObject moneyPrefab;
    public Sprite icon;
}
