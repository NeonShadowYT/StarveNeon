using UnityEngine;
using UnityEngine.AI;
using System.Collections;
using System.Collections.Generic;

[HelpURL("https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg")]
public class AIManager : MonoBehaviour
{
    public MobScriptableObject mobScriptableObject;
    public AICollider aiCollider;

    [Space]
    public List<Transform> target;

    [Space]
    [Header("Поведение")]
    public bool AgreAI;
    public bool WolfAI;
    public bool DamageForAgreAI;
    public bool PanicAI;
    public bool ShotAI;
    public bool CompanionAI;
    public bool NightAI;

    [Space]
    [Header("Боссы")]
    public bool Dezmo;

    [Space]
    [Header("Компоненты")]
    [HideInInspector] public NavMeshAgent navMeshAgent;
    [HideInInspector] public AIManager mobInteraction;
    [HideInInspector] public FractionNPS fractionNPS;
    [HideInInspector] public Collider mobCollider;
    [HideInInspector] public Transform mTransform;
    [HideInInspector] public AudioSource audios;
    [HideInInspector] public MobStats mobStats;
    [HideInInspector] public Animator animator;

    [Space]
    [Header("Прокачка")]
    public List<MobUpdate> mobUpdate;
    public MeshFilter[] mobRender;

    [Space]
    [Header("Дополнительное")]
    public List<Transform> patrolPoints;

    [HideInInspector] public float nextAttackTime;
    [HideInInspector] public float nextShotTime;
    [HideInInspector] public Vector3 circlePoint;

    [HideInInspector]public bool death;
    [HideInInspector]public bool percColdawn;
    [HideInInspector]public bool viewColdawn;

    public void Start()
    {
        navMeshAgent = GetComponent<NavMeshAgent>();
        fractionNPS = GetComponent<FractionNPS>();
        mobCollider = GetComponent<Collider>();
        audios = GetComponent<AudioSource>();
        mobStats = GetComponent<MobStats>();
        animator = GetComponent<Animator>();

        mTransform = transform;
        patrolPoints.Add(mTransform);
        navMeshAgent.speed = mobScriptableObject.movementSpeed;
        navMeshAgent.angularSpeed = mobScriptableObject.rotationSpeed;
        percColdawn = true;

        mobStats.Startap();
        aiCollider.SetupAI();
        
        if (fractionNPS != null) fractionNPS.Startnps();
    }

    //погружение
    public void MobRewEnd()
    {   
        AIWalk();

        viewColdawn = true;
        animator.SetBool("ViewTarget", false);

        InvokeRepeating(nameof(ViewColdawn), 60f, 0f);
    }
    public void ViewColdawn()
    {
        viewColdawn = false;
        
        CancelInvoke(nameof(ViewColdawn));
    }

    public void DeathAudio()
    {
        AudioRandomize();
        audios.PlayOneShot(mobScriptableObject.deathAudio[Random.Range(0, mobScriptableObject.deathAudio.Length)]);
    }
    public void RewAudio()
    {
        AudioRandomize();
        audios.PlayOneShot(mobScriptableObject.rewAudio[Random.Range(0, mobScriptableObject.rewAudio.Length)]);
    }
    public void AttackeAudio()
    {
        AudioRandomize();
        audios.PlayOneShot(mobScriptableObject.attackeAudio[Random.Range(0, mobScriptableObject.attackeAudio.Length)]);
    }
    private void AudioRandomize()
    {
        audios.volume = Random.Range(0.8f, 1.2f);
        audios.pitch = Random.Range(0.8f, 1.2f);
    }

    public void RandomAnim()
    {
        animator.SetInteger("RandomIdle", Random.Range(0, 4));
        animator.SetInteger("atackeID", Random.Range(0, 4));
    }

    public void AnimUpdate()
    {
        animator.SetFloat("Speed", navMeshAgent.velocity.magnitude / mobScriptableObject.movementSpeed);
    }

    //взаимодействия
    public void ViewTarget()
    {
        if (death || target.Count < 1)
        {
            GlobalInvoker.instance.aiLogicUpdate.Remove(this);
            return;
        }
        else
        {
            animator.SetInteger("RandomIdle", 0);
        }

        if (WolfAI && Time.time < nextAttackTime)
        {
            if (circlePoint == Vector3.zero || (circlePoint - mTransform.position).sqrMagnitude < 0.5f)
            {
                // Находим точку по окружности вокруг игрока
                circlePoint = target[0].position + Quaternion.Euler(0, Random.Range(0, 360), 0) * (Vector3.forward * 15f);
                navMeshAgent.SetDestination(circlePoint);
            }

            return;
        }

        if (Dezmo && CustomCharacterController.instance.currentSpeed <= 7 && mobStats.health >= mobScriptableObject.Health * 0.75f) 
        {
            return;
        }

        if (fractionNPS != null)
        {
            if (AgreAI)
            {
                if (ShotAI) //стрельба
                {
                    Shoots();

                    if ((mTransform.position - target[0].position).sqrMagnitude < 15f * 15f)
                    {
                        navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
                    }
                }
                else
                {
                    if (Indicators.instance.waterEffect.timeEffect >= 1)
                    {
                        navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
                    }
                    else
                    {
                        navMeshAgent.SetDestination(target[0].position); // идём к цели
                        circlePoint = Vector3.zero;
                    }
                }
            }
            else if (PanicAI)
            {
                navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
            }
        }
        else
        {
            if (AgreAI)
            {
                if (mobScriptableObject.MobType == MobType.Ground || mobScriptableObject.MobType == MobType.Air)
                {
                    if (Indicators.instance.waterEffect.timeEffect >= 1)
                    {
                        navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
                    }
                    else
                    {
                        navMeshAgent.SetDestination(target[0].position); // идём к цели
                        circlePoint = Vector3.zero;
                    }
                }
                else
                {
                    if (Indicators.instance.waterEffect.timeEffect >= 1)
                    {
                        navMeshAgent.SetDestination(target[0].position); // идём к цели
                        circlePoint = Vector3.zero;
                    }
                    else
                    {
                        navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
                        //navMeshAgent.SetDestination(target[0].position + (mTransform.position - target[0].position) * 15f); // Более оптимизированный вариант но плохо убегает
                    }
                }
            }
            else if (PanicAI)
            {
                navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
            }

            if (ShotAI) //стрельба
            {
                Shoots();
            }
        }
    }

    //основное
    public void MoveAnimal()
    {
        if (target.Count >= 1)
        {
            animator.SetBool("Sleep", false);
            return;
        }

        if ((DayTime.instance.night && !NightAI) || (!DayTime.instance.night && NightAI))
        {
            animator.SetBool("Sleep", true);
            return;
        }

        animator.SetBool("Sleep", false);
        int random = Random.Range(0, 5);

        if (random == 2)
        {
            mobInteraction = GlobalInvoker.instance.aiMoveUpdate[Random.Range(0, GlobalInvoker.instance.aiMoveUpdate.Count)];

            if (mobInteraction != this && mobInteraction.target.Count <= 0 && ((mobInteraction.AgreAI && PanicAI) || (mobInteraction.PanicAI && AgreAI)))
            {
                target.Add(mobInteraction.mTransform);
                mobInteraction.target.Add(mTransform);

                GlobalInvoker.instance.aiLogicUpdate.Add(this);
                GlobalInvoker.instance.aiLogicUpdate.Add(mobInteraction);
                return;
            }
        }
        else if (random >= 3)
        {
            RandomAnim();
            return;
        }

        animator.SetInteger("RandomIdle", 0);
        navMeshAgent.SetDestination(RandomNavSphere(Random.Range(mobScriptableObject.moveDistance * 0.75f, mobScriptableObject.moveDistance * 1.25f)));
    }

    public void AIStop()
    {
        navMeshAgent.speed = 0;
    }

    public void AIWalk()
    {
        float speed = mobScriptableObject.movementSpeed;
        navMeshAgent.speed = speed;

        if (fractionNPS != null && !AgreAI) return;

        if (percColdawn = false && Random.Range(0, 4) >= 2)
        {
            if (fractionNPS != null) 
            {
                EquipPerc(fractionNPS.mEquipStats.percValue);
            }
            else
            {
                EquipPerc(mobScriptableObject.MobPerc);
            }

            Invoke(nameof(StartPercColdawn), mobScriptableObject.percTime * Random.Range(0.75f, 1.25f));
        }
    }

    private void EquipPerc(MobPerc mobPerc)
    {
        switch (mobPerc)
        {
            case MobPerc.Run:
                navMeshAgent.speed *= Random.Range(1.75f, 2.25f);
                break;
            case MobPerc.Armor:
                animator.SetInteger("AtackeType", 1);
                mobStats.armor = true;

                AIStop();
                break;
            case MobPerc.Shoter:
                Shooter();
                Shooter();

                break;
        }
    }

    //перк
    private void StartPercColdawn()
    {
        mobStats.armor = false;
        animator.SetInteger("AtackeType", 0);

        percColdawn = true;
        Invoke((nameof(EndPercColdawn)), mobScriptableObject.percTime * Random.Range(1.5f, 2.5f));

        AIWalk();
    }

    private void EndPercColdawn() => percColdawn = false;

    Vector3 RandomNavSphere(float distance)
    {
        Vector3 randomDirection = Random.insideUnitSphere * distance;
        randomDirection += patrolPoints[Random.Range(0, patrolPoints.Count)].position;

        NavMeshHit navHit;
        NavMesh.SamplePosition(randomDirection, out navHit, distance, -1);

        return navHit.position;
    }

    //стрельба
    public void Shoots()
    {
        if (Time.time > nextShotTime)
        {
            Shooter();
        }
    }
    private void Shooter()
    {
        Vector3 direction = new Vector3(Random.Range(-2, 2), Random.Range(-3, 3), Random.Range(-3, 3));
        Vector3 targetPoint = target[0].position + new Vector3(0f, 0.5f, 0f);

        direction.Normalize();
        nextShotTime = Time.time + Random.Range(mobScriptableObject.shootTime * 0.75f, mobScriptableObject.shootTime * 1.25f);

        GlobalPool.instance.ActiveCartridge(mobScriptableObject.сartridgeName, mTransform.position + new Vector3(0f, 0.5f, 0f),
         (targetPoint += direction), Random.Range(mobScriptableObject.shootTime * 0.5f, mobScriptableObject.shootTime * 0.75f));
    }

    //улучшения
    public void UpdateLvlMob()
    {
        for (int i = 0; i < mobUpdate[0].updateMesh.Length; i++)
        {
            mobScriptableObject = mobUpdate[0].updateScriptableObject;
            mobStats.mobScriptableObject = mobScriptableObject;

            mobStats.health = mobScriptableObject.Health;
            mobRender[i].mesh = mobUpdate[0].updateMesh[i];
        }

        mobUpdate.Remove(mobUpdate[0]);
        AIWalk();
    }
}

[System.Serializable]
public class MobUpdate
{
    public MobScriptableObject updateScriptableObject;
    public int dayUpdate;

    [Space]
    public Mesh[] updateMesh;
}