using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class GameModeItem : MonoBehaviour
{
    public Image image;
    public TMP_Text text;

    public GameModeManager GameModeManager;

    public GameModeScriptableObject GameModeScriptableObject;

    public void ChangeGameMode()
    {
        GameModeManager.ChangeGameMode(GameModeScriptableObject);
    }
}