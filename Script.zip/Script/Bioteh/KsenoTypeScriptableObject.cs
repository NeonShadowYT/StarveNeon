using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "Bioteh", menuName = "Neon Imperium/Bioteh/New KsenoType")]
public class KsenoTypeScriptableObject : ScriptableObject
{
    [Space]
    [Header("Настройки ксенотипа")]
    public string NameKsenoType;
    public string Descriphen;

    [Space]
    public Sprite icon;

    public List<GenScriptableObject> GenKsenoType;
}