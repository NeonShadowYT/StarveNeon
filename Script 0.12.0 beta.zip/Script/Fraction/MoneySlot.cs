using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MoneySlot : MonoBehaviour
{
    public MoneyScriptableObject money;
    public int _amount;
    public int amount
    {
        get { return _amount; }
        set
        {
            _amount = value;
            moneyText.text = _amount.ToString();
            
            if (moneyStatsText != null) 
            {
                moneyStatsText.text = "Монет " + _amount.ToString();
            }
        }
    }
    public TMP_Text moneyText;
    public TMP_Text moneyStatsText;
}
