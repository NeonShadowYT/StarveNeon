using System;
using UnityEngine;
using System.Collections;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;

public class StarveNeonUpdateManager : MonoBehaviour
{    
    [Space]
    [Header("Ссылка")]
    public string versionUrl = "";

    [Space]
    [Header("Следующая версия")]
    private string latestVersion;

    [Space]
    [Header("Визуал")]
    public GameObject newVersionAvailable;
    public TMP_Text NewVersionText;

    public void Start()
    {
        latestVersion = "";
        
        Check();
    }

    public void Check()
    {
        StartCoroutine(LoadTxtData(versionUrl));
    }

    private IEnumerator LoadTxtData(string url)
    {
        UnityWebRequest loaded = new UnityWebRequest(url);
        loaded.downloadHandler = new DownloadHandlerBuffer();

        yield return loaded.SendWebRequest();
        latestVersion = loaded.downloadHandler.text;

        CheckVersion();
    }

    private void CheckVersion()
    {
        NewVersionText.text = latestVersion;
        
        if (latestVersion != "") 
        {
            if (Application.version != latestVersion)
            {
                newVersionAvailable.SetActive(true);
            }
        }
    }
}