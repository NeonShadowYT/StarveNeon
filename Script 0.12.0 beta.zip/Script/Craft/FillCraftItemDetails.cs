using UnityEngine;
using UnityEngine.UI;

public class FillCraftItemDetails : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Скрипты")]
    public CraftQueueManager craftQueueManager;
    public CraftManager craftManager;
    public InventoryManager inventoryManager;

    [Space]
    [Header("Текущая информация о крафте")]
    public CraftScriptableObject currentCraftItem;

    [Space]
    public Image image;
    public Sprite nullImage;

    public void FillItemDetails() //новая
    {
        if (currentCraftItem.craftType == CraftType.Buildings)
        {
            craftManager.buildingBtn.gameObject.SetActive(true);
            craftQueueManager.craftAmountInputField.text = "1";
        }
        else
        {
            craftManager.buildingBtn.gameObject.SetActive(false);
        }

        inventoryManager.craftPanel.SetActive(true);
        inventoryManager.detailsPanel.SetActive(false);
        inventoryManager.chatPanel.SetActive(false);

        craftManager.currentCraftItem = this;
        
        craftManager.craftItemName.text = currentCraftItem.finalCraft.name;
        craftManager.craftItemDescription.text = currentCraftItem.finalCraft.itemDescription + " Время крафта " + currentCraftItem.craftTime.ToString();
        craftManager.craftItemImage.sprite = currentCraftItem.finalCraft.icon;

        bool canCraft = true;

        for (int i = 0; i < craftManager.allResDetails.Count; i++)
        {
            CraftResourceDetails crd = craftManager.allResDetails[i];

            crd.itemTypeText.text = "";
            crd.totalText.text = "";

            crd.itemImage.sprite = nullImage;
            crd.compliteImage.color = crd.disableColor;
        }

        for (int i = 0; i < currentCraftItem.craftResources.Count; i++)
        {
            CraftResourceDetails crd = craftManager.allResDetails[i];

            crd.itemTypeText.text = currentCraftItem.craftResources[i].craftObject.itemName;
            crd.itemImage.sprite = currentCraftItem.craftResources[i].craftObject.icon;

            int totalAmount = currentCraftItem.craftResources[i].craftObjectAmount * int.Parse(craftQueueManager.craftAmountInputField.text);
            crd.totalText.text = totalAmount.ToString();
            
            int resourceAmount = 0;

            foreach (InventorySlot slot in inventoryManager.slots)
            {
                if (slot.item == null) continue;

                if (slot.item.itemName == currentCraftItem.craftResources[i].craftObject.itemName) resourceAmount += slot.amount;
            }

            if (resourceAmount < totalAmount) 
            {
                canCraft = false;
            }
            else
            {
                crd.compliteImage.color = crd.enebleColor;
            }
        }

        if (canCraft) 
        {
            craftManager.craftBtn.interactable = true;
            craftManager.buildingBtn.interactable = true;
        }
        else 
        {
            craftManager.craftBtn.interactable = false;
            craftManager.buildingBtn.interactable = false;
        }
        
        craftQueueManager.currentCraftItem = currentCraftItem;
    }
}
