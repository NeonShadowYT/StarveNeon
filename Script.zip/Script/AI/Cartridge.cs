using UnityEngine;

public class Cartridge : MonoBehaviour
{
    [Space]
    [Header("Характеристики")]
    public EquipEffect сartridgeEffect;
    public float damage;
    public float speed;

    [Range(0, 100)]
    public int chanceEffect = 100;
    public float crit = 77f, critModifer = 1.5f;
    public float weak = 22f, weakModifer = 0.75f;

    [Space]
    [Header("Компоненты")]
    public Transform mTransform;

    [HideInInspector] public Vector3 targetPosition;
    [HideInInspector] public float timeCartridge;

    private void Update()
    {
        timeCartridge -= Time.deltaTime;
        mTransform.position = Vector3.MoveTowards(mTransform.position, targetPosition, speed * Time.deltaTime);

        if (mTransform.position == targetPosition || timeCartridge <= 0) gameObject.SetActive(false);
    }

    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.CompareTag("Player")) 
        {
            CustomCharacterController.instance.TakeDamage(damage, сartridgeEffect, chanceEffect, crit, critModifer, weak, weakModifer);
        }

        gameObject.SetActive(false);
    }
}