﻿using UnityEngine;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;

public static class BinarySavingSystem // static - нам нужна всего одна копия этого класса //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    //Игрок
    public static void Save(SaveData data)
    {
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "/Save.starver";
        FileStream stream = new FileStream(path, FileMode.Create);
        formatter.Serialize(stream, data);
        stream.Close();
    }

    public static SaveData Load(SaveData data)
    {
        string path = Application.persistentDataPath + "/Save.starver";
        if (File.Exists(path))
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);

            if (stream.Length == 0)
            {
                stream.Close();
                return null;
            }

            data = formatter.Deserialize(stream) as SaveData;
            stream.Close();

            return data;
        }
        else
        {
            return null;
        }
    }

    public static void DeleteSave()
    {
        string path = Application.persistentDataPath + "/Save.starver";
        DirectoryInfo directory = new DirectoryInfo(path);

        directory.Delete(true);
        Directory.CreateDirectory(path);
    }
}