using System.Collections.Generic;
using UnityEngine;

public class StorageManager : MonoBehaviour
{
    public static StorageManager instance;

    public GameObject storagePanel;

    [HideInInspector]
    public Storage currentStorage;

    [Space]
    public List<InventorySlot> storageSlots;

    private void Awake() => instance = this;

    public void Function(Table _table)
    {
        currentStorage = _table.storage;

        for (int i = 0; i < storageSlots.Count; i++)
        {
            storageSlots[i].gameObject.SetActive(false);
        }

        for (int i = 0; i < currentStorage.slots.Count; i++)
        {
            InventorySlot slot = storageSlots[i];
            slot.gameObject.SetActive(true);

            if (currentStorage.slots[i].item == null)
            {
                slot.item = null;
                slot.amount = 0;
            }
            else
            {
                slot.item = currentStorage.slots[i].item;
                slot.amount = currentStorage.slots[i].amount;
            }
        }
            
        storagePanel.SetActive(true);
    }

    public void Close() => storagePanel.SetActive(false);
}
