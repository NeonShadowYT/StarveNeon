using UnityEngine;

public enum PetsFoodType { Vegetables, Berries, Meat }
public class Pets : MonoBehaviour
{
    [Space]
    [Header("Важное")]
    public AIManager aIManager;
    public PetsFoodType foodPets = PetsFoodType.Vegetables;

    [HideInInspector] public PetsFood petsFoodObj;

    [Range(0, 100), Tooltip("Шанс приручения")]
    public int ChancePets = 50;

    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.CompareTag("AnimalFood"))
        {
            petsFoodObj = col.gameObject.GetComponent<PetsFood>();

            if (petsFoodObj.foodPets == foodPets)
            {
                aIManager.target.Add(petsFoodObj.destroyObj.transform);

                GlobalInvoker.instance.aiLogicUpdate.Add(aIManager);
                aIManager.AIStop();

                aIManager.animator.SetBool("ViewTarget", true);
                aIManager.animator.SetFloat("Target", 1f);

                return;
            }
            else
            {
                petsFoodObj = null;
            }
        }
    }
}