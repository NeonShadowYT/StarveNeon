using UnityEngine;
//using Unity.Services.Core;
//using Unity.Services.Authentication;
using System.Threading.Tasks;
using UnityEngine.UI;
using TMPro;

public class AuthenticationManager : MonoBehaviour
{   
    async void Start() 
    {
        //await UnityServices.InitializeAsync();
        //DontDestroyOnLoad(gameObject);
    }

    public void GetID(TMP_InputField _text)
    {
        //_text.text = AuthenticationService.Instance.PlayerId;
    }

    public async void SignIn(string password, TMP_Text debugText) 
    {
        //if (!AuthenticationService.Instance.SessionTokenExists) 
        //{
            //await signInAnonymous(debugText);
        //}
        //else
        //{
            //await signInWithUnity(password, debugText);
        //}
    }

    async Task signInAnonymous(TMP_Text debugText) 
    {
        //try
        //{
            //await AuthenticationService.Instance.SignInAnonymouslyAsync();
            //debugText.text = "Успешный онлайн вход";
        //}
        //catch (AuthenticationException ex)
        //{
            //debugText.text = "Ошибка: " + ex;
        //}
        //catch (RequestFailedException ex)
        //{
            //debugText.text = "Ошибка: " + ex;
       // }
    }

    async Task signInWithUnity(string password, TMP_Text debugText) 
    {
        //try
        //{
            //await AuthenticationService.Instance.SignInWithUnityAsync(password);
            //debugText.text = "Успешный онлайн вход";
        //}
        //catch (AuthenticationException ex) when (ex.ErrorCode == AuthenticationErrorCodes.AccountAlreadyLinked)
        //{
            //debugText.text = "Похоже вы уже в игре";
        //}

        //catch (AuthenticationException ex)
        //{
            //debugText.text = "Ошибка: " + ex;
        //}
        //catch (RequestFailedException ex)
        //{
            //debugText.text = "Ошибка: " + ex;
        //}
    }
}