using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;

public class Score : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    [Space]
    public int GameJoltScoreID;
    public string extraData;

    [Space]
    public TMP_Text scoreText;

    void Start()
    {
        scoreText.text = "Опыт " + dataSaveLoad.data.playerScore.ToString();
    }

    public void ScoreAdd(int scoreAdd)
    {
        dataSaveLoad.data.playerScore += scoreAdd;
        scoreText.text = "Опыт " + dataSaveLoad.data.playerScore.ToString();

        //if(registrProgress.regGJ == true)
        //{
            //GameJolt.API.Scores.Add(scoreAdd, scoreText.text, GameJoltScoreID, extraData, (bool success) =>
            //{
                //Debug.Log(success ? "Очки получены" : "Не удалось получить очки");
            //});
        //}
    }
}

[System.Serializable]
public class Lvl
{
    public Sprite icon;
    public int xp;
}