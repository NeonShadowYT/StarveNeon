using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameSettingsItem : MonoBehaviour
{
    public bool Preview;

    public GameModeManager GameModeManager;

    public GameObject DeleteButton;

    public TMP_InputField inputField;
    public TMP_Text text;

    public Image icon;

    public GameSettingsScriptableObject gameSettingsScriptableObject;

    public void AddSettings()
    {
        GameModeManager.AddSettings(gameSettingsScriptableObject);
        DeleteSettings();
    }

    public void DeleteSettings()
    {
        if (Preview == false)
        {
            GameModeManager.RemoveSettings(gameSettingsScriptableObject);
        }

        Destroy(gameObject);
    }
}