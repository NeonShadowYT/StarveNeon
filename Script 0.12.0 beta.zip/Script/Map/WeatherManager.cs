using UnityEngine;
using System.Collections;

public enum WeatherType { Default, Rain, Fire, Cold, Toxin, Ad }

public class WeatherManager : MonoBehaviour
{
    public WeatherPlayer weatherPlayer;

    [Space]
    [Header("Погода")]
    public FogMode fogMode;
    public Color fogColor;
    public float fogDensity;
    public bool fogEnabled;

    [Space]
    [Header("Характеристика")]
    public int WeatherArmor;
    public int ColdChang;
    
    void Start()
    {
        weatherPlayer = FindObjectOfType<WeatherPlayer>();
    }

    [ContextMenu(nameof(ChangSettings))]
    public void ChangSettings()
    {
        RenderSettings.fog = fogEnabled; // Включение тумана
        RenderSettings.fogColor = fogColor; // Цвет тумана
        RenderSettings.fogMode = fogMode; // Режим тумана

        StartCoroutine(FadeDensity());
    }

    IEnumerator FadeDensity()
    {
        if (RenderSettings.fogDensity < fogDensity)
        {
            while (RenderSettings.fogDensity < fogDensity * 0.99f)
            {
                RenderSettings.fogDensity = Mathf.Lerp(RenderSettings.fogDensity, fogDensity, Time.deltaTime); // Дальность тумана
                yield return null;
            }
        }
        else
        {
            while (RenderSettings.fogDensity > fogDensity * 1.01f)
            {
                RenderSettings.fogDensity = Mathf.Lerp(RenderSettings.fogDensity, fogDensity, Time.deltaTime); // Дальность тумана
                yield return null;
            }
        }

        StopCoroutine(FadeDensity());
    }
}
