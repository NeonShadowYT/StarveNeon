using System.Collections.Generic;
using UnityEngine;

public enum FractionProfesion { Defender, Villager, Traider }
public class FractionNPS : MonoBehaviour
{
    [Space]
    [Header("Важно")]
    public Fraction myFraction;
    public FractionScriptableObject NPSFraction;

    public MobStats mobStats;
    public AIManager aIManager;

    public FractionProfesion mProfesion;
    private bool lowRep;

    [Space]
    [Header("Экиперовка")]
    public List<FractionEquipStats> villagerEquipStats;
    public List<FractionEquipStats> defenderEquipStats;
    public List<FractionEquipStats> traiderEquipStats;

    [Space]
    public FractionEquipStats mEquipStats;

    public void Startnps()
    {
        if (mEquipStats.name != "") return;

        int randomNum = Random.Range(0, 4);

        if (randomNum == 1)
        {
            mProfesion = FractionProfesion.Villager;

            randomNum = Random.Range(0, villagerEquipStats.Count);
            mEquipStats = villagerEquipStats[randomNum];
        }
        else if (randomNum >= 2)
        {
            mProfesion = FractionProfesion.Defender;

            randomNum = Random.Range(0, defenderEquipStats.Count);
            mEquipStats = defenderEquipStats[randomNum];
        }
        else if (randomNum <= 0)
        {
            mProfesion = FractionProfesion.Traider;

            randomNum = Random.Range(0, traiderEquipStats.Count);
            mEquipStats = traiderEquipStats[randomNum];
        }

        for (int i = 0; i < mEquipStats.obj.Length; i++)
        {
            mEquipStats.obj[i].SetActive(true);
        }

        mobStats.health += mEquipStats.healthValue;
        mobStats.damage += mEquipStats.damageValue;
        mobStats.attackeSphere.radius += mEquipStats.distanceValue;

        aIManager.mPerc = mEquipStats.percValue;

        CheckRep();
    }

    public void CheckRep()
    {
        if (myFraction == null) return;

        lowRep = false;

        switch (NPSFraction.fractionRace)
        {
            case FractionRace.Ksencse:
                if (myFraction.fractionManager.ksenoRepAmount < 0) 
                {
                    lowRep = true;
                }
                break;
            case FractionRace.GC:
                if (myFraction.fractionManager.goldenRepAmount < 0) 
                {
                    lowRep = true;
                }
                break;
            case FractionRace.Oboroten:
                if (myFraction.fractionManager.oborotRepAmount < 0) 
                {
                    lowRep = true;
                }
                break;
            case FractionRace.Stasy:
                if (myFraction.fractionManager.stasyRepAmount < 0) 
                {
                    lowRep = true;
                }
                break;
        }

        if (lowRep == true)
        {
            if (mEquipStats.lowRepPanic == true)
            {
                aIManager.PanicAI = true;
            }
            else
            {
                aIManager.AgreAI = true;
            }
        }
        else
        {
            aIManager.AgreAI = false;
            aIManager.PanicAI = false;
        }
    }
}

[System.Serializable]
public class FractionEquipStats
{
    [Space]
    [Header("Визуал")]
    public string name;
    public GameObject[] obj;

    [Space]
    [Header("Статы")]
    public float healthValue;

    public float damageValue;
    public float distanceValue;

    [Space]
    public MobPerc percValue = MobPerc.Common;
    public bool lowRepPanic;
}