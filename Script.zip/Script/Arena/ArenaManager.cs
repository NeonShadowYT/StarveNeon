using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ArenaManager : MonoBehaviour
{
    public static ArenaManager instance;

    public List<Wave> wave;

    [Space]
    public Sprite startIcon;
    public string startMessage;

    [Space]
    public Sprite endIcon;
    public string endMessage;

    [Space]
    public RewardType valueRewardType;
    public int valueReward;
    public string skinReward;

    [Space]
    public MoneyType fractionRewardType;
    public int fractionReward;
    public int reputationReward;

    private void Awake() => instance = this;

    private void Start()
    {
        for (int i = 0; i < wave.Count; i++)
        {
            for (int ii = 0; ii < wave[i].enemy.Count; ii++)
            {
                wave[i].enemy[ii].gameObject.SetActive(false);
            }
        }

        WaitWave();
    }

    public void ChangWave()
    {
        if (wave.Count != 0)
        {
            IventViewer.instance.IventView(wave[0].waveIcon, wave[0].waveMessage);

            for (int i = 0; i < wave[0].enemy.Count; i++)
            {
                wave[0].enemy[i].gameObject.SetActive(true);
            }

            return;
        }

        IventViewer.instance.IventView(endIcon, endMessage);
        Invoke(nameof(CompliteArena), 10f);
    }

    public void WaitWave()
    {
        IventViewer.instance.IventView(startIcon, startMessage);
        Invoke(nameof(ChangWave), 10f);
    }

    private void CompliteArena()
    {
        switch (valueRewardType)
        {
            case RewardType.Wood :
                DataSaveLoad.instance.data.woodValue += valueReward;
                break;
            case RewardType.Rock :
                DataSaveLoad.instance.data.rockValue += valueReward;
                break;
            case RewardType.Cuprum :
                DataSaveLoad.instance.data.cuprumValue += valueReward;
                break;
            case RewardType.Gold :
                DataSaveLoad.instance.data.goldValue += valueReward;
                break;
            case RewardType.Diamond :
                DataSaveLoad.instance.data.diamondValue += valueReward;
                break;
            case RewardType.Ametist :
                DataSaveLoad.instance.data.ametistValue += valueReward;
                break;
            case RewardType.Redit :
                DataSaveLoad.instance.data.reditValue += valueReward;
                break;
            case RewardType.Izum :
                DataSaveLoad.instance.data.izumValue += valueReward;
                break;
            case RewardType.Core :
                DataSaveLoad.instance.data.coreValue += valueReward;
                break;
            case RewardType.Neolit :
                DataSaveLoad.instance.data.neolitValue += valueReward;
                break;
            case RewardType.CharacterSkin :
                DataSaveLoad.instance.data.inventorySkin[DataSaveLoad.instance.data.inventorySkin.Length + 1] = skinReward;
                break;
            case RewardType.ItemSkin :
                DataSaveLoad.instance.data.inventorySkin[DataSaveLoad.instance.data.inventorySkin.Length + 1] = skinReward;
                break;
        }

        switch (fractionRewardType)
        {
            case MoneyType.GC :
                DataSaveLoad.instance.data.goldenAmount += fractionReward;
                DataSaveLoad.instance.data.goldenRepAmount += reputationReward;
                break;
            case MoneyType.Ksencse :
                DataSaveLoad.instance.data.ksenoAmount += fractionReward;
                DataSaveLoad.instance.data.ksenoRepAmount += reputationReward;
                break;
            case MoneyType.Oboroten :
                DataSaveLoad.instance.data.oborotAmount += fractionReward;
                DataSaveLoad.instance.data.oborotRepAmount += reputationReward;
                break;
            case MoneyType.Texno :
                DataSaveLoad.instance.data.texnoAmount += fractionReward;
                break;
            case MoneyType.BioTexno :
                DataSaveLoad.instance.data.bioAmount += fractionReward;
                break;
            case MoneyType.Plants :
                //DataSaveLoad.instance.data.plantsAmount += fractionReward;
                break;
            case MoneyType.Stasy :
                DataSaveLoad.instance.data.stasyAmount += fractionReward;
                DataSaveLoad.instance.data.stasyRepAmount += reputationReward;
                break;
        }

        ArenaManager.instance = null;
        DataSaveLoad.instance.Live();
    }
}

[System.Serializable]
public class Wave
{
    public List<AIManager> enemy;

    [Space]
    public Sprite waveIcon;
    public string waveMessage;
}
