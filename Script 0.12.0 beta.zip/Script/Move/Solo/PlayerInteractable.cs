using UnityEngine;

public class PlayerInteractable : MonoBehaviour
{
    public InventoryManager inventoryManager;

    public void OnTriggerEnter(Collider col)
    {
        if (col.CompareTag("Item") || col.CompareTag("FractionMoney") || col.CompareTag("FractionNps") || col.CompareTag("Storage") || col.CompareTag("Door") || col.CompareTag("Verstac") || col.CompareTag("Verstac2") || col.CompareTag("Verstac3") || col.CompareTag("Verstac4") || col.CompareTag("BioTex"))
        {
            inventoryManager.itemObject.Add(col.gameObject);
        }
    }

    public void OnTriggerExit(Collider col)
    {
        if (col.CompareTag("Item") || col.CompareTag("FractionMoney") || col.CompareTag("FractionNps") || col.CompareTag("Storage") || col.CompareTag("Door") || col.CompareTag("Verstac") || col.CompareTag("Verstac2") || col.CompareTag("Verstac3") || col.CompareTag("Verstac4") || col.CompareTag("BioTex"))
        {
            inventoryManager.itemObject.Remove(col.gameObject);
        }
    }
}
