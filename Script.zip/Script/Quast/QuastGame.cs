using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuastGame : MonoBehaviour
{
    public static QuastGame instance;

    [Space]
    [Header("Листы")]
    public List<QuastScriptableObject> allQuastList;
    public List<PassGameItem> quastItemList;

    [Space]
    [Header("Статистика")]
    public GameObject quastPrefab;
    public Transform content;

    private void Awake() => instance = this;

    private void Start()
    {
        for (int i = 0; i < 5; i++)
        {
            QuastScriptableObject quastScriptableObject = allQuastList[Random.Range(0, allQuastList.Count)];
            PassGameItem passGameItem = Instantiate(quastPrefab, content).GetComponent<PassGameItem>();

            quastItemList.Add(passGameItem);
            passGameItem.quastScriptableObject = quastScriptableObject;

            passGameItem.PassNameItems.text = quastScriptableObject.QuastText;
            passGameItem.PassItemReward.text = quastScriptableObject.PassMoneyReward.ToString();
            passGameItem.PassItemImage.sprite = quastScriptableObject.QuastImage;

            passGameItem.PassItemProgress.maxValue = quastScriptableObject.Amount;
            passGameItem.PassItemProgress.value = 0;

            passGameItem.claimProgress = false;
            allQuastList.Remove(quastScriptableObject);
        }
    }

    public void AddQuastReward(int i)
    {
        DataSaveLoad.instance.data.rockValue += quastItemList[i].quastScriptableObject.PassMoneyReward;
        quastItemList[i].claimProgress = true;
        
        IventViewer.instance.IventView(quastItemList[i].quastScriptableObject.QuastImage, "Выполнено: " + quastItemList[i].quastScriptableObject.QuastText);
        quastItemList.Remove(quastItemList[i]);
    }
}