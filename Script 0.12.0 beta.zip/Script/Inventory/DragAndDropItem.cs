﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

/// IPointerDownHandler - Следит за нажатиями мышки по объекту на котором висит этот скрипт
/// IPointerUpHandler - Следит за отпусканием мышки по объекту на котором висит этот скрипт
/// IDragHandler - Следит за тем не водим ли мы нажатую мышку по объекту
public class DragAndDropItem : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    private QuickslotInventory quickslotInventory; // added this++
    private CraftManager craftManager;
    private InventoryManager inventory;

    private Transform player, mTransform;
    private RectTransform mRectTransform;

    [Space]
    [Header("Старый слот")]
    public InventorySlot oldSlot;
    private Transform oldSlotTransform;

    [Space]
    [Header("Одежда")]
    public List<ClothAdder> clothAdders;

    private Image slotImage;

    private void Start()
    {
        quickslotInventory = FindObjectOfType<QuickslotInventory>();
        craftManager = FindObjectOfType<CraftManager>();
        player = GameObject.FindObjectOfType<CustomCharacterController>().transform; //ПОСТАВЬТЕ ТЭГ "PLAYER" НА ОБЪЕКТЕ ПЕРСОНАЖА!

        mRectTransform = GetComponent<RectTransform>();
        
        inventory = craftManager.inventoryManager;
        oldSlotTransform = oldSlot.transform;
        mTransform = transform;

        slotImage = oldSlot.iconGO;
        
        if (oldSlot.clothType != ClothType.None)
        {
            clothAdders = new List<ClothAdder>();
            clothAdders.AddRange(FindObjectsOfType<ClothAdder>());
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (oldSlot.item == null) return; // Если слот пустой, то мы не выполняем то что ниже return;

        mRectTransform.position += new Vector3(eventData.delta.x, eventData.delta.y);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (oldSlot.item == null) return; // Если слот пустой, то мы не выполняем то что ниже return;

        slotImage.color = new Color(1, 1, 1, 0.75f); //Делаем картинку прозрачнее
        slotImage.raycastTarget = false; // Делаем так чтобы нажатия мышкой не игнорировал картинку

        mTransform.SetParent(mTransform.parent.parent.parent); // Делаем наш DraggableObject ребенком InventoryPanel чтобы DraggableObject был над другими слотами инвенторя

        inventory.audioSource.volume = Random.Range(0.2f, 0.4f);
        inventory.audioSource.pitch = Random.Range(0.8f, 1.2f);

        inventory.audioSource.PlayOneShot(oldSlot.item.itemAudio);

        quickslotInventory.MobailDragSlot(oldSlot.gameObject);

        inventory.DetailsItemView(oldSlot.item, oldSlot.amount, this);
    }

    public void ReturnBackToSlot()
    {
        if (oldSlot.item == null) return; // Если слот пустой, то мы не выполняем то что ниже return;

        slotImage.color = new Color(1, 1, 1, 1f); // Делаем картинку опять не прозрачной
        slotImage.raycastTarget = true; // И чтобы мышка опять могла ее засечь

        mTransform.SetParent(oldSlotTransform); //Поставить DraggableObject обратно в свой старый слот
        mTransform.position = oldSlotTransform.position;

        inventory.audioSource.volume = Random.Range(0.2f, 0.4f);
        inventory.audioSource.pitch = Random.Range(0.8f, 1.2f);

        inventory.audioSource.PlayOneShot(oldSlot.item.itemAudio);

        inventory.detailsPanel.SetActive(false);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (oldSlot.item == null)
        {
            return; // Если слот пустой, то мы не выполняем то что ниже return;
        }

        slotImage.color = new Color(1, 1, 1, 1f); // Делаем картинку опять не прозрачной
        slotImage.raycastTarget = true; // И чтобы мышка опять могла ее засечь

        mTransform.SetParent(oldSlotTransform); //Поставить DraggableObject обратно в свой старый слот
        mTransform.position = oldSlotTransform.position; //Если мышка отпущена над объектом по имени UIPanel, то...

        inventory.audioSource.volume = Random.Range(0.2f, 0.4f);
        inventory.audioSource.pitch = Random.Range(0.8f, 1.2f);

        inventory.audioSource.PlayOneShot(oldSlot.item.itemAudio);

        if (eventData.pointerCurrentRaycast.gameObject == false) // renamed to UIBG
        {
            DropItems();
            return;
        }

        InventorySlot inventorySlot = eventData.pointerCurrentRaycast.gameObject.transform.parent.parent.GetComponent<InventorySlot>();

        if (inventorySlot != null)
        {
            if (inventorySlot.clothType != ClothType.None) //Перемещаем данные из одного слота в другой
            {
                if (inventorySlot.clothType == oldSlot.item.clothType)
                {
                    ExchangeSlotData(inventorySlot);
                    foreach (ClothAdder clothAdder in inventorySlot.GetComponentInChildren<DragAndDropItem>().clothAdders) clothAdder.UpdateClothes();
                }
                else return;
            }
            else
            {
                ExchangeSlotData(inventorySlot);
                quickslotInventory.CheckItemInHand();

                if (oldSlot.clothType != ClothType.None) foreach (ClothAdder clothAdder in clothAdders) clothAdder.UpdateClothes();
            }

            if (oldSlot.amount <= 0) 
            {
                inventory.detailsPanel.SetActive(false);

                NullifySlotData();
                StorageDropUpdate();

                if (oldSlot.clothType != ClothType.None) foreach (ClothAdder clothAdder in clothAdders) clothAdder.UpdateClothes();
            }
        }
    }

    public void DropItems()
    {
        inventory.detailsPanel.SetActive(false);
        inventory.craftPanel.SetActive(false);
        inventory.chatPanel.SetActive(true);

        Item dropItem = Instantiate(oldSlot.item.itemPrefab, player.position + Vector3.up + player.forward, Quaternion.identity).GetComponent<Item>(); // Выброс объектов из инвентаря - Спавним префаб обекта перед персонажем

        dropItem.durability = oldSlot.itemDurability;
        dropItem.destroy = oldSlot.destroyBar.fillAmount;
        
        if (Input.GetKey(KeyCode.LeftShift))
        {        
            dropItem.amount = Mathf.CeilToInt((float)oldSlot.amount / 2);

            oldSlot.amount -= Mathf.CeilToInt((float)oldSlot.amount / 2);
            oldSlot.itemAmountText.text = oldSlot.amount.ToString();
        }
        else if (Input.GetKey(KeyCode.LeftControl))
        {
            dropItem.amount = 1;

            oldSlot.amount--;
            oldSlot.itemAmountText.text = oldSlot.amount.ToString();
        }
        else
        {
            dropItem.amount = oldSlot.amount;

            NullifySlotData(); // убираем значения InventorySlot
        }

        quickslotInventory.CheckItemInHand();

        StorageDropUpdate();
        if (oldSlot.clothType != ClothType.None) foreach (ClothAdder clothAdder in clothAdders) clothAdder.UpdateClothes();
    }

    public void NullifySlotData() // made public 
    {
        oldSlot.item = null; // убираем значения InventorySlot
        oldSlot.amount = 0;
        oldSlot.itemDurability = 0f;
        oldSlot.durabilityBar.fillAmount = 0f;
        oldSlot.destroyBar.fillAmount = 0f;
        oldSlot.iconGO.color = new Color(1, 1, 1, 0);
        oldSlot.iconGO.sprite = null;
        oldSlot.itemAmountText.text = "";
    }

    void ExchangeSlotData(InventorySlot newSlot)
    {
        if (newSlot == oldSlot)
        {
            ReturnBackToSlot();
            return;
        }

        inventory.detailsPanel.SetActive(false);

        ItemScriptableObject item = newSlot.item; // Временно храним данные newSlot в отдельных переменных

        int amount = newSlot.amount;
        float itemDurability = newSlot.itemDurability;
        float itemDestroy = newSlot.destroyBar.fillAmount;

        Image iconGO = newSlot.iconGO;
        TMP_Text itemAmountText = newSlot.itemAmountText;
        
        if (item == null)
        {
            if (oldSlot.item.maximumAmount > 1 && oldSlot.amount > 1)
            {
                if (Input.GetKey(KeyCode.LeftShift))
                {
                    newSlot.item = oldSlot.item;
                    newSlot.amount = Mathf.CeilToInt((float)oldSlot.amount / 2);
                    newSlot.SetIcon(oldSlot.iconGO.sprite);
                    newSlot.itemAmountText.text = newSlot.amount.ToString();

                    oldSlot.amount = Mathf.FloorToInt((float)oldSlot.amount / 2);
                    oldSlot.itemAmountText.text = oldSlot.amount.ToString();

                    StorageUpdate(newSlot);
                    return;
                }
                else if (Input.GetKey(KeyCode.LeftControl))
                {
                    newSlot.item = oldSlot.item;
                    newSlot.amount = 1;
                    newSlot.SetIcon(oldSlot.iconGO.sprite);
                    newSlot.itemAmountText.text = newSlot.amount.ToString();

                    oldSlot.amount--;
                    oldSlot.itemAmountText.text = oldSlot.amount.ToString();

                    StorageUpdate(newSlot);
                    return;
                }
            }
        }

        if (item != null)
        {
            if (oldSlot.clothType != ClothType.None && item.clothType == ClothType.None)
            {
                ReturnBackToSlot();
                return;
            }

            if (oldSlot.item == newSlot.item)
            {
                if (Input.GetKey(KeyCode.LeftShift) && oldSlot.amount > 1)
                {
                    if (Mathf.CeilToInt((float)oldSlot.amount / 2) < newSlot.item.maximumAmount - newSlot.amount)
                    {
                        newSlot.amount += Mathf.CeilToInt((float)oldSlot.amount / 2);
                        newSlot.itemAmountText.text = newSlot.amount.ToString();

                        oldSlot.amount -= Mathf.CeilToInt((float)oldSlot.amount / 2);
                        oldSlot.itemAmountText.text = oldSlot.amount.ToString();

                        StorageUpdate(newSlot);
                    }
                    else
                    {
                        int difference = newSlot.item.maximumAmount - newSlot.amount;
                        newSlot.amount = newSlot.item.maximumAmount;
                        newSlot.itemAmountText.text = newSlot.amount.ToString();

                        oldSlot.amount -= difference;
                        oldSlot.itemAmountText.text = oldSlot.amount.ToString();

                        StorageUpdate(newSlot);
                    }
                    return;
                }
                else if (Input.GetKey(KeyCode.LeftControl) && oldSlot.amount > 1)
                {
                    if (newSlot.item.maximumAmount != newSlot.amount)
                    {
                        newSlot.amount++;
                        newSlot.itemAmountText.text = newSlot.amount.ToString();

                        oldSlot.amount--;
                        oldSlot.itemAmountText.text = oldSlot.amount.ToString();

                        StorageUpdate(newSlot);
                    }
                    return;
                }
                else
                {
                    if (newSlot.amount + oldSlot.amount >= newSlot.item.maximumAmount)
                    {
                        int difference = newSlot.item.maximumAmount - newSlot.amount;
                        newSlot.amount = newSlot.item.maximumAmount;
                        newSlot.itemAmountText.text = newSlot.amount.ToString();

                        oldSlot.amount -= difference;
                        oldSlot.itemAmountText.text = oldSlot.amount.ToString();

                        StorageUpdate(newSlot);
                    }
                    else
                    {
                        newSlot.amount += oldSlot.amount;
                        newSlot.itemAmountText.text = newSlot.amount.ToString();

                        NullifySlotData();

                        StorageUpdate(newSlot);
                    }
                    return;
                }
            }
        }

        newSlot.item = oldSlot.item; // Заменяем значения newSlot на значения oldSlot
        newSlot.amount = oldSlot.amount;
        newSlot.itemDurability = oldSlot.itemDurability;
        newSlot.destroyBar.fillAmount = oldSlot.destroyBar.fillAmount;

        if (oldSlot.item != null)
        {
            newSlot.SetIcon(oldSlot.iconGO.sprite);
            if (oldSlot.item.maximumAmount != 1) newSlot.itemAmountText.text = oldSlot.amount.ToString(); else newSlot.itemAmountText.text = ""; // added this if statement for single items
        }
        else
        {
            newSlot.iconGO.color = new Color(1, 1, 1, 0);
            newSlot.iconGO.sprite = null;
            newSlot.itemAmountText.text = "";
        }

        oldSlot.item = item; // Заменяем значения oldSlot на значения newSlot сохраненные в переменных
        oldSlot.amount = amount;
        oldSlot.itemDurability = itemDurability;
        oldSlot.destroyBar.fillAmount = itemDestroy;

        if (item != null)
        {
            oldSlot.SetIcon(item.icon);
            if (item.maximumAmount != 1) oldSlot.itemAmountText.text = amount.ToString(); else oldSlot.itemAmountText.text = "";// added this if statement for single items
        }
        else
        {
            oldSlot.iconGO.color = new Color(1, 1, 1, 0);
            oldSlot.iconGO.sprite = null;
            oldSlot.itemAmountText.text = "";
        }

        StorageUpdate(newSlot);
    }

    public void StorageDropUpdate()
    {
        if (oldSlot.slotType == SlotType.Storage)
        {
            for (int i = 0; i < inventory.currentStorage.slots.Count; i++)
            {
                if (inventory.storageSlots[i] == oldSlot || inventory.slots[i] == oldSlot)
                {
                    if (oldSlot.amount <= 0)
                    {
                        inventory.currentStorage.slots[i].item = null;
                        inventory.currentStorage.slots[i].amount = 0;
                    }
                    else
                    {
                        inventory.currentStorage.slots[i].item = oldSlot.item;
                        inventory.currentStorage.slots[i].amount = oldSlot.amount;
                    }
                    break;
                }
            }
        }
    }

    public void StorageUpdate(InventorySlot newSlot)
    {
        if (newSlot.slotType == SlotType.Storage)
        {
            for (int i = 0; i < inventory.currentStorage.slots.Count; i++)
            {
                if (inventory.storageSlots[i] == newSlot || inventory.slots[i] == newSlot)
                {
                    inventory.currentStorage.slots[i].item = newSlot.item;
                    inventory.currentStorage.slots[i].amount = newSlot.amount;
                    break;
                }
            }
        }

        if (oldSlot.slotType == SlotType.Storage)
        {
            for (int i = 0; i < inventory.currentStorage.slots.Count; i++)
            {
                if (inventory.storageSlots[i] == oldSlot || inventory.slots[i] == oldSlot)
                {
                    inventory.currentStorage.slots[i].item = oldSlot.item;
                    inventory.currentStorage.slots[i].amount = oldSlot.amount;
                    break;
                }
            }
        }
    }
}