using UnityEngine;
using System.Threading.Tasks;

public class MemoryOptimizer : MonoBehaviour
{
    [Header("Интервал"), Tooltip("В секундах"), SerializeField]
    private float cleanInterval = 60f;

    async void OnClean()
    {
        // Начинаем повторяющиеся вызовы очистки памяти
        InvokeRepeating(nameof(CleanMemory), cleanInterval, cleanInterval);
    }

    async void OffClean()
    {
        // Заканчиваем повторяющиеся вызовы очистки памяти
        CancelInvoke(nameof(CleanMemory));
    }

    async void CleanMemory()
    {
        // Асинхронно вызываем сборку мусора
        await Task.Run(() => System.GC.Collect());

        // Выгружаем неиспользуемые ресурсы
        Resources.UnloadUnusedAssets();
    }
}