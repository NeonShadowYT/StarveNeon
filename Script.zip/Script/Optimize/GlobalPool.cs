using System.Collections.Generic;
using UnityEngine;

public class GlobalPool : MonoBehaviour
{
    public static GlobalPool instance;

    public List<GameObject> effectPool;
    public List<Cartridge> cartridgePool;

    private void Awake() => instance = this;

    public void ActiveEffect(string effectName, Vector3 hitPoint)
    {
        foreach (GameObject effect in effectPool)
        {
            if (effect.name == effectName && effect.activeSelf == false)
            {
                effect.transform.position = hitPoint;
                effect.SetActive(true);
                break;
            }
        }
    }

    public void ActiveCartridge(string cartridgeName, Vector3 startPoint, Vector3 targetPoint, float timeCartridge)
    {
        foreach (Cartridge cartridge in cartridgePool)
        {
            if (cartridge.gameObject.name == cartridgeName && cartridge.gameObject.activeSelf == false)
            {
                cartridge.targetPosition = targetPoint;
                cartridge.timeCartridge = timeCartridge;

                cartridge.mTransform.position = startPoint;
                cartridge.gameObject.SetActive(true);
                break;
            }
        }
    }
}