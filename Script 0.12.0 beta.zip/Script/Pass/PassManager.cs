using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PassManager : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    [Space]
    [Header("Текст")]
    public TMP_Text PassNameText;
    public TMP_Text PassMoneyText;
    public TMP_Text PassLvlText;

    public TMP_Text PassUpdatePriceText;

    [Space]
    [Header("Награда")]
    private GameObject NextRewardObj;
    private PassItemList NextPassItem;

    [Space]
    [Header("Важное")]
    public MagazinManager magazinManager;
    public SelectedCharacters skindata;

    public GameObject PassItemPrefab;

    [Space]
    public Transform PassContent;

    [Space]
    [Header("Лист")]
    public List<PassList> Pass;

    public void Start()
    {
        ChangPass();
    }

    public void ChangPass()
    {
        for (int i = 0; i < PassContent.childCount; i++) Destroy(PassContent.GetChild(i).gameObject);

        foreach (PassList pass in Pass)
        {
            if (pass.PassName == dataSaveLoad.data.passName)
            {
                PassNameText.text = pass.PassName;

                foreach (PassItemList passItemList in pass.PassItemList)
                {
                    if (passItemList.ItemLvl > dataSaveLoad.data.passLvl)
                    {
                        PassItemSpawner(passItemList);
                    }
                }

                break;
            }
        }
    }

    public void PassItemSpawner(PassItemList passItemList)
    {
        PassItem passItem = Instantiate(PassItemPrefab, PassContent).GetComponent<PassItem>();

        if (passItemList.ItemLvl == dataSaveLoad.data.passLvl + 1)
        {
            NextPassItem = passItemList;
            NextRewardObj = passItem.gameObject;

            PassUpdatePriceText.text = NextPassItem.Price.ToString();
        }

        passItem.PassItemImage.sprite = passItemList.ItemImage;

        passItem.PassNameItems.text = passItemList.ItemName;
        passItem.PassItemLvl.text = passItemList.ItemLvl.ToString();
    }

    public void UpdatePass()
    {
        if (NextPassItem == null) 
        {
            PassUpdatePriceText.text = "";
            return;
        }

        if(dataSaveLoad.data.rockValue >= NextPassItem.Price)
        {
            dataSaveLoad.data.rockValue -= NextPassItem.Price;
            dataSaveLoad.data.passLvl = NextPassItem.ItemLvl;

            PassMoneyText.text = dataSaveLoad.data.rockValue.ToString();
            PassLvlText.text = dataSaveLoad.data.passLvl.ToString();

            ClaimReward();
        }
    }

    public void ClaimReward()
    {
        switch(NextPassItem.BonusTypePass)
        {
            case RewardType.Wood :
                break;
            case RewardType.Rock :
                break;
            case RewardType.Gold :
                skindata.AddMoney(Random.Range(100, 500));
                break;
            case RewardType.Diamond :
                magazinManager.AddDiamond(Random.Range(1, 10));
                break;
            case RewardType.Ametist :
                break;
            case RewardType.Redit :
                break;
            case RewardType.Izum :
                break;
            case RewardType.Neolit :
                break;
            case RewardType.CharacterSkin :
                skindata.AddCharacter(NextPassItem.ItemName);
                break;
            case RewardType.ItemSkin :
                break;
        }
    }

    public void NewPassSetter()
    {
        dataSaveLoad.data.passLvl = 0;
        PassLvlText.text = "0";

        //dataSaveLoad.data.passName = latestPass;
    }
}

[System.Serializable]
public class PassList
{
    [Space]
    [Header("Данные")]
    public string PassName;
    public bool PassComplite;
    public List<PassItemList> PassItemList;
}

[System.Serializable]
public class PassItemList
{
    [Space]
    [Header("Визуал")]
    public Sprite ItemImage;
    public int Price;

    [Space]
    [Header("Тип награды")]
    public RewardType BonusTypePass;

    [Space]
    public string ItemName;

    public int ItemLvl;
}