using UnityEngine;

public class ArmorManager : MonoBehaviour
{
    [Space, Header("Важное"), Tooltip("Назначается в ClothAdder, во время одевания"), HideInInspector]
    public Indicators indicators;

    [Space]
    [Header("Характеристики")]
    [Range(1, 12), Tooltip("Защита от урона")] public int ArmorPoints;
    [Range(0, 4), Tooltip("Защита от холода")] public int ColdArmorPoints;
    [Range(0, 1), Tooltip("Скорость в воде")] public int WaterPoints;
    [Range(-1, 1), Tooltip("Скорость вне воды")] public int SpeedPoints;
    [Range(0, 1), Tooltip("Защита от заражения")] public int InfectedPoints;
    [Range(0, 1), Tooltip("Сила прыжка")] public int JumpPowerPoints;
    [Range(0, 6), Tooltip("Защита от погоды")] public int StormArmor;

    public void EquipArmor()
    {
        indicators.Armor += ArmorPoints;
        indicators.ColdArmor += ColdArmorPoints;
        indicators.Water += WaterPoints;
        indicators.customCharacterController.walkingSpeed += SpeedPoints;
        indicators.customCharacterController.runningSpeed += SpeedPoints;
        indicators.StormArmor += StormArmor;
        indicators.Infected += InfectedPoints;
        indicators.JumpPower += JumpPowerPoints;

        gameObject.SetActive(true);
    }
}
