using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class AchievementItem : MonoBehaviour
{
    [Space]
    [Header("Основная инфа")]
    public AchievementScriptableObject achievementScriptableObject;

    [HideInInspector]
    public AchievementManager achievementManager;

    [Space]
    public Button buttonAchievement;
    public Image achievementIcon;
    public TMP_Text achievementText;

    [Space]
    [Header("Награда")]
    public TMP_Text rewardText;
    public Image rewardIcon;

    [Space]
    [Header("Прогресс")]
    public Slider sliderProgress;
    public bool claimProgress;

    public void Unloke()
    {
        if (claimProgress == false)
        {
            claimProgress = true;

            switch (achievementScriptableObject.rewardType)
            {
                case RewardType.Wood :
                    achievementManager.dataSaveLoad.data.woodValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Rock :
                    achievementManager.dataSaveLoad.data.rockValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Cuprum :
                    achievementManager.dataSaveLoad.data.cuprumValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Gold :
                    achievementManager.dataSaveLoad.data.goldValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Diamond :
                    achievementManager.dataSaveLoad.data.diamondValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Ametist :
                    achievementManager.dataSaveLoad.data.reditValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Redit :
                    achievementManager.dataSaveLoad.data.reditValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Izum :
                    achievementManager.dataSaveLoad.data.izumValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Core :
                    achievementManager.dataSaveLoad.data.coreValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Neolit :
                    achievementManager.dataSaveLoad.data.neolitValue += achievementScriptableObject.rewardAmount;
                    break;
            }
        }

        if (achievementManager.registrProgress != null && achievementManager.registrProgress.regGJ == true)
        {
            GameJolt.API.Trophies.Unlock(achievementScriptableObject.IdGJ, (bool success) =>
             { 
                if(success)
                {
                    Debug.Log("Зарегестрировано достяжение: " + achievementScriptableObject.name);
                }
                else
                {
                    Debug.Log("Не удалось зарегестрировать достяжение: " + achievementScriptableObject.name);
                }
             });
        }
    }
}
