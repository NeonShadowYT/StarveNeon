using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class VerstacManager : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public static VerstacManager instance;

    [Space]
    [Header("Скрипты")]
    public VerstCraftHelper verstCraftHelper;
    public MoneySlot texnoSlot;

    [Space]
    [Header("Данные")]
    public GameObject verstacPanel;
    public Transform verstacContent;

    public GameObject verstacPrefab;
    public List<VerstAnLoker> verstList;

    [Space]
    public Image craftIcon;
    public GameObject craftAnLockButton;
    public TMP_Text craftName, craftDiscriphen, craftScoreTreb;

    private void Awake() => instance = this;

    public void AddCraft(CraftScriptableObject craftScriptableObject)
    {
        VerstAnLoker verstAnLoker = Instantiate(verstacPrefab, verstacContent).GetComponent<VerstAnLoker>();

        verstList.Add(verstAnLoker);
        verstAnLoker.verstCraftHelper = verstCraftHelper;
        verstAnLoker.craftAnLock = craftScriptableObject;
        verstAnLoker.IconImag.sprite = craftScriptableObject.finalCraft.icon;
        verstAnLoker.TextTreb.text = craftScriptableObject.verstScore.ToString();
    }

    public void UpdateCraftAnLock(ItemScriptableObject craftAnLock, int anlockScore)
    {
        craftIcon.sprite = craftAnLock.icon;
        craftName.text = craftAnLock.itemName;
        craftDiscriphen.text = craftAnLock.itemDescription;
        craftScoreTreb.text = anlockScore.ToString();

        craftScoreTreb.gameObject.SetActive(true);
        craftDiscriphen.gameObject.SetActive(true);
        craftName.gameObject.SetActive(true);
        craftIcon.gameObject.SetActive(true);
        craftAnLockButton.SetActive(true);

        verstCraftHelper.currentVerstAnLock = 0;
    }

    public void AnLock(int anlockScore, CraftScriptableObject craftAnLock)
    {
        craftScoreTreb.gameObject.SetActive(false);
        craftDiscriphen.gameObject.SetActive(false);
        craftName.gameObject.SetActive(false);
        craftIcon.gameObject.SetActive(false);
        craftAnLockButton.SetActive(false);

        int chekAnlok = 0;

        foreach (FillCraftItemDetails cso in CraftManager.instance.allCraftItemDetails)
        {
            if (cso.currentCraftItem == craftAnLock)
            {
                verstCraftHelper.currentVerstAnLock = 1;
                chekAnlok = 1;
                break;
            }
        }

        if (texnoSlot.amount >= anlockScore && chekAnlok == 0)
        {
            texnoSlot.amount -= anlockScore;
            CraftManager.instance.ChangCraftList(craftAnLock);

            verstCraftHelper.currentVerstAnLock = 1;
        }
    }

    public void Function(Table _table)
    {
        InventoryManager.instance.craftPanel.SetActive(false);
        verstacPanel.SetActive(true);

        for (int i = 0; i < verstList.Count; i++) 
        {
            if (verstList[i].craftAnLock.verstLevel > _table.tableLvl)
            {
                verstList[i].gameObject.SetActive(false);
            }
            else
            {
                verstList[i].gameObject.SetActive(true);
            }
        }

        craftScoreTreb.gameObject.SetActive(false);
        craftDiscriphen.gameObject.SetActive(false);
        craftName.gameObject.SetActive(false);
        craftIcon.gameObject.SetActive(false);
        craftAnLockButton.SetActive(false);
    }

    public void Close() => verstacPanel.SetActive(false);
}
