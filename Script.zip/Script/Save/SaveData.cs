using UnityEngine;

[System.Serializable] // дает возможность сохранить этот класс в файл
public class SaveData
{
    //сохранение
    public string saveVersion;

    //данные игрока
    public string playerId;
    public string playerNick;
    public string playerPassword;

    public int playerLvl;
    public int playerStoryLvl;
    public int playerScore;

    public string friends;
    public int playerRep;

    //индикаторы
    public float health;
    public float food;
    public float water;
    public float cold;

    //гены
    public string[] genNames;

    //крафты
    public string[] allCrafts;

    //настройки вылазки
    public string biom;
    public string stolyres;
    public int complexity;
    public bool[] modiferValue;

    //предметы
    public string[] itemNames;
    public int[] itemAmounts;

    public float[] itemDurability;
    public float[] itemDestroy;

    public string[] itemModifer;
    public int[] itemPosition; //0 база, 1 игрок, 2 хранилище, 3 мир 

    //скины
    public string[] currentSkin;
    public string[] inventorySkin;

    //игровые данные
    public int texnoAmount;
    public int bioAmount;

    public int dayInt;

    //фракции
    public int ksenoAmount;
    public int goldenAmount;
    public int oborotAmount;
    public int stasyAmount;

    public int ksenoRepAmount;
    public int goldenRepAmount;
    public int oborotRepAmount;
    public int stasyRepAmount;

    //валюта
    public int woodValue;
    public int rockValue;
    public int cuprumValue;
    public int goldValue;
    public int diamondValue;
    public int ametistValue;
    public int reditValue;
    public int izumValue;
    public int coreValue;
    public int neolitValue;

    //промокоды
    public string[] activePromo;

    //пасс
    public int passLvl;
    public int passPower;
    public string passName;
    public bool[] passComplite;

    //достижения
    public string[] nameAchievement;
    public float[] progressAchievement;
    public bool[] rewardAchievement;

    public SaveData(SaveData _data)
    {
        //сохранение
        saveVersion = _data.saveVersion;

        //прогресс игрока
        playerLvl = _data.playerLvl;
        playerStoryLvl = _data.playerStoryLvl;
        playerScore = _data.playerScore;

        //данные игрока
        playerId = _data.playerId;
        playerNick = _data.playerNick;
        playerPassword = _data.playerPassword;

        friends = _data.friends;

        //индикаторы игрока
        health = _data.health;
        food = _data.food;
        water = _data.water;
        cold = _data.cold;

        //гены игрока
        genNames = _data.genNames;

        //крафты игрока
        allCrafts = _data.allCrafts;

        //настройки вылазки
        biom = _data.biom;
        stolyres = _data.stolyres;
        complexity = _data.complexity;
        modiferValue = _data.modiferValue;
        
        //предметы игрока
        itemNames = _data.itemNames;
        itemAmounts = _data.itemAmounts;
        itemDurability = _data.itemDurability;
        itemDestroy = _data.itemDestroy;
        itemModifer = _data.itemModifer;
        itemPosition = _data.itemPosition;

        //скины игрока
        currentSkin  = _data.currentSkin;
        inventorySkin = _data.inventorySkin;

        //игровые данные
        texnoAmount = _data.texnoAmount;
        bioAmount = _data.bioAmount;

        dayInt = _data.dayInt;

        //фракции
        ksenoAmount = _data.ksenoAmount;
        goldenAmount = _data.goldenAmount;
        oborotAmount = _data.oborotAmount;
        stasyAmount = _data.stasyAmount;

        ksenoRepAmount = _data.ksenoRepAmount;
        goldenRepAmount = _data.goldenRepAmount;
        oborotRepAmount = _data.oborotRepAmount;
        stasyRepAmount = _data.stasyRepAmount;

        //валюта
        woodValue = _data.woodValue;
        rockValue = _data.rockValue;
        cuprumValue = _data.cuprumValue;
        goldValue = _data.goldValue;
        diamondValue = _data.diamondValue;
        ametistValue = _data.ametistValue;
        reditValue = _data.reditValue;
        izumValue = _data.izumValue;
        coreValue = _data.coreValue;
        neolitValue = _data.neolitValue;

        //промокоды
        activePromo = _data.activePromo;

        //пасс
        passLvl = _data.passLvl;
        passPower = _data.passPower;
        passName = _data.passName;
        passComplite = _data.passComplite;

        //достижения
        nameAchievement = _data.nameAchievement;
        progressAchievement = _data.progressAchievement;
        rewardAchievement = _data.rewardAchievement;
    }
}
