﻿using Cinemachine;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using TMPro;
using System;

public class InventoryManager : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public static InventoryManager instance;

    [Space]
    [Header("Камера")]
    public CinemachineVirtualCamera CVC;
    private CinemachinePOV pov;

    [HideInInspector] public float sensitivity;
    [HideInInspector] public DragAndDropItem dropScript;

    [Space]
    [Header("Компоненты")]
    public Animator anim;
    public Transform player;
    public AudioSource audioSource;

    [Space]
    [Header("Объекты")]
    public TMP_Text nameText;
    public GameObject viewCamera;
    public GameObject globalCanvas;
    public GameObject inventoryPanel;
    public GameObject craftPanel;
    public GameObject chatPanel;
    public GameObject craftView;

    public GameObject[] morePanel;

    [Space]
    [Header("Детальная информация предмета")]
    public GameObject detailsPanel;
    public TMP_Text detailsDescriphen;
    public TMP_Text detailsName;
    public Image detailsIcon;

    [Space]
    [Header("Буллы")]
    [HideInInspector] public bool isOpened;
    [HideInInspector] public bool isInput;

    private bool destroyItem;
    [HideInInspector] public int backpackSlot;

    [Space]
    [Header("Листы")]
    public List<InventorySlot> slots;
    public List<GameObject> itemObject;

    private void Awake() => instance = this;

    private void Start()
    {
        pov = CVC.GetCinemachineComponent<CinemachinePOV>();
        nameText.text = DataSaveLoad.instance.data.playerNick;

        for (int i = 0; i < slots.Count; i++)
        {
            if (slots[i].slotType == SlotType.Backpack)
            {
                backpackSlot = i;
                break;
            }
        }

        for (int i = 0; i < DataSaveLoad.instance.data.itemNames.Length; i++)
        {
            RemoveItemFromSlot(i);
            AddItemToSlot(Resources.Load<ItemScriptableObject>($"ScriptableObjects/{DataSaveLoad.instance.data.itemNames[i]}"), DataSaveLoad.instance.data.itemAmounts[i], DataSaveLoad.instance.data.itemDurability[i], DataSaveLoad.instance.data.itemDestroy[i], i);
        }

        Invoke(nameof(EditCurcorOff), 0.01f);
    }

    public void ToInventory(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            isOpened = !isOpened;

            if (isOpened)
            {
                EditCurcorOn();
            }
            else
            {
                EditCurcorOff();
            }
        }
    }

    public void InputE(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            if (isInput == false) return;

            EditCurcorOff();
            Interactable();
        }
    }

    public void Interactable()
    {
        for (int i = 0; i < itemObject.Count; i++)
        {
            switch (itemObject[i].tag)
            {
                case "Item":
                    Item itemscript = itemObject[i].GetComponent<Item>();

                    anim.SetBool("addItem", true);
                    destroyItem = true;

                    AddItem(itemscript, itemscript.item, itemscript.amount, itemscript.durability, itemscript.destroy);
                    QuickslotInventory.instance.CheckItemInHand();

                    audioSource.volume = UnityEngine.Random.Range(0.2f, 0.4f);
                    audioSource.pitch = UnityEngine.Random.Range(0.8f, 1.2f);

                    audioSource.PlayOneShot(itemscript.item.itemAudio);

                    if (destroyItem == true)
                    {
                        if (itemscript.optimize == false)
                        {
                            Destroy(itemObject[i]);
                            itemObject.Remove(itemObject[i]);
                        }
                        else
                        {
                            itemObject[i].SetActive(false); //для кустов
                            itemObject.Remove(itemObject[i]);
                        }
                    }
                    else
                    {
                        if (itemscript.optimize == false) 
                        {
                            itemObject[i].transform.position = player.position + Vector3.up + player.forward;
                        }
                    }

                    break;
                case "Door":
                    anim.SetBool("addItem", true);
                    Door door = itemObject[i].GetComponent<Door>();

                    door.InvertDoorState();

                    audioSource.volume = UnityEngine.Random.Range(0.2f, 0.4f);
                    audioSource.pitch = UnityEngine.Random.Range(0.8f, 1.2f);

                    audioSource.PlayOneShot(door.doorAudio);
                    
                    break;
                case "Table":
                    anim.SetBool("addItem", true);
                    TableManager.instance.TableFunction(itemObject[i].GetComponent<Table>());
                    break;
            }
        }
    }

    public void OffInput() => isInput = false;
    public void OnInput() => isInput = true;

    public void DetailsItemView(ItemScriptableObject _item, int _amount, DragAndDropItem _dropScript)
    {
        detailsName.text = _item.itemName + " " + _amount.ToString() + "/" + _item.maximumAmount;
        detailsIcon.sprite = _item.icon;
        detailsDescriphen.text = _item.itemDescription;

        dropScript = _dropScript;
        detailsPanel.SetActive(true);
        chatPanel.SetActive(false);
        craftView.SetActive(false);
    }

    public void DropDetailsItem()
    {
        dropScript.DropItems();
    }

    public void FixDetailsItem()
    {
        if (dropScript.oldSlot.durability >= dropScript.oldSlot.item.maximumDurability || dropScript.oldSlot.destroyBar.fillAmount >= 0.95f ) return;

        CraftScriptableObject craftScriptable = null;

        for (int i = 0; i < CraftManager.instance.allCraftItemDetails.Count; i++) // ищем нужный крафт
        {
            if (dropScript.oldSlot.item == CraftManager.instance.allCraftItemDetails[i].currentCraftItem.finalCraft)
            {
                craftScriptable = CraftManager.instance.allCraftItemDetails[i].currentCraftItem;
            }
        }

        if (craftScriptable == null) return; //если у игрока нет изучения этого предмета то ничего не будет фиксится

        bool canFix = true;
        int amountToRemove = 0;
        
        for (int i = 0; i < craftScriptable.craftResources.Count; i++) //есть ли у нас эти ресурсы
        {
            amountToRemove = (int)(craftScriptable.craftResources[i].craftObjectAmount * (1f - dropScript.oldSlot.destroyBar.fillAmount / 100f));
            int resourceAmount = 0;

            foreach (InventorySlot slot in slots)
            {
                if (slot.item == null) continue;

                if (slot.item.itemName == craftScriptable.craftResources[i].craftObject.itemName) resourceAmount += slot.amount;
            }

            if (resourceAmount < amountToRemove) 
            {
                canFix = false;
                break;
            }
        }

        if (canFix == true) // если есть то отнимаем их и фиксим предмет
        {
            for (int i = 0; i < craftScriptable.craftResources.Count; i++)
            {
                amountToRemove = (int)(craftScriptable.craftResources[i].craftObjectAmount * (1f - dropScript.oldSlot.destroyBar.fillAmount / 100f));

                for (int iii = 0; iii < slots.Count; iii++)
                {
                    if (amountToRemove <= 0) 
                    {
                        break;
                    }

                    if (slots[iii].item == craftScriptable.craftResources[i].craftObject)
                    {
                        if(amountToRemove > slots[iii].amount)
                        {
                            amountToRemove -= slots[iii].amount;
                            slots[iii].dragAndDropItem.NullifySlotData();
                        }
                        else
                        {
                            slots[iii].amount -= amountToRemove;
                            amountToRemove = 0;

                            if(slots[iii].amount <= 0) slots[iii].dragAndDropItem.NullifySlotData();
                        }
                    }
                }
            }

            dropScript.oldSlot.destroyBar.fillAmount += UnityEngine.Random.Range(0.1f, 0.2f); //повреждаем предмет чтобы игрок не мог его всегда чинить
            dropScript.oldSlot.durability = dropScript.oldSlot.item.maximumDurability * (1f - dropScript.oldSlot.destroyBar.fillAmount); //чиним
        }

        detailsPanel.SetActive(false);
        ClothAdder.instance.UpdateClothes();
    }

    public void RemoveItemFromSlot(int slotId)
    {
        InventorySlot slot = slots[slotId];
        if (slot.clothType != ClothType.None && slot.item != null) ClothAdder.instance.UpdateClothes();
        
        slot.item = null;
        slot.amount = 0;
        slot.durability = 0f;
        slot.durabilityBar.fillAmount = 0f;
        slot.destroyBar.fillAmount = 0f;
    }

    public void AddItemToSlot(ItemScriptableObject _item, int _amount, float _durability, float _destroy, int slotId)
    {
        if (_item == null) return;

        InventorySlot slot = slots[slotId];
        slot.item = _item;
        slot.durability = _durability;
        slot.destroyBar.fillAmount = _destroy;
        
        if (_amount <= _item.maximumAmount)
        {
            slot.amount = _amount;
        }
        else
        {
            slot.amount = _item.maximumAmount;
            _amount -= _item.maximumAmount;
        }

        if (slot.clothType != ClothType.None) ClothAdder.instance.UpdateClothes();
    }

    public void AddItem(Item _itemScript, ItemScriptableObject _item, int _amount, float _durability, float _destroy)
    {      
        foreach (InventorySlot slot in slots)
        {
            if (slot.item == _item) // Стакаем предметы вместе // В слоте уже имеется этот предмет
            {
                if (slot.amount + _amount <= _item.maximumAmount)
                {
                    slot.amount += _amount;
                    return;
                }
                else
                {
                    _amount -= _item.maximumAmount - slot.amount;
                    slot.amount = _item.maximumAmount;
                }
                continue;
            }
        }

        bool allFull = true;
        foreach (InventorySlot inventorySlot in slots)
        {
            if (inventorySlot.item == null && inventorySlot.clothType == ClothType.None && inventorySlot.gameObject.activeSelf)
            {
                allFull = false;
                break;
            }
        }

        if (allFull) 
        {
            destroyItem = false;

            if (_itemScript == null)
            {
                Item itemScript = Instantiate(_item.itemPrefab, player.position + Vector3.up + player.forward, Quaternion.identity).GetComponent<Item>();

                itemScript.amount = _amount;
                itemScript.durability = _durability;
                itemScript.destroy = _destroy;
            }
            else
            {
                _itemScript.amount = _amount;
                _itemScript.durability = _durability;
                _itemScript.destroy = _destroy;
            }

            QuickslotInventory.instance.CheckItemInHand();
            return;
        }

        foreach (InventorySlot slot in slots)
        {
            if (_amount <= 0) return;

            if (slot.item == null && slot.clothType == ClothType.None && slot.gameObject.activeSelf) // добавляем предметы в свободные ячейки
            {
                slot.item = _item; //slot.amount = amount;
                slot.durability = _durability;
                slot.destroyBar.fillAmount = _destroy;

                if (_amount <= _item.maximumAmount)
                {
                    slot.amount = _amount;
                    break;
                }
                else
                {
                    slot.amount = _item.maximumAmount;
                    _amount -= _item.maximumAmount;
                }

                allFull = true;
                foreach (InventorySlot inventorySlot in slots)
                {
                    if (inventorySlot.item == null && inventorySlot.clothType == ClothType.None  && inventorySlot.gameObject.activeSelf)
                    {
                        allFull = false;
                        break;
                    }
                }
                
                if (allFull)
                {
                    destroyItem = false;

                    if (_itemScript == null)
                    {
                        Item itemScript = Instantiate(_item.itemPrefab, player.position + Vector3.up + player.forward, Quaternion.identity).GetComponent<Item>();

                        itemScript.amount = _amount;
                        itemScript.durability = _durability;
                        itemScript.destroy = _destroy;
                    }
                    else
                    {
                        _itemScript.amount = _amount;
                        _itemScript.durability = _durability;
                        _itemScript.destroy = _destroy;
                    }

                    break;
                } //continue;
            }
        }

        QuickslotInventory.instance.CheckItemInHand();
    }

    public void EditCurcorOn()
    {
        isOpened = true;

        viewCamera.SetActive(true);
        chatPanel.SetActive(true);

        globalCanvas.SetActive(true);

        Cursor.lockState = CursorLockMode.None; // Прекрепляем курсор к середине экрана
        Cursor.visible = true; // и делаем его невидимым

        anim.SetBool("Hit", false);
        QuickslotInventory.instance.attacke = false;

        pov.m_HorizontalAxis.m_InputAxisName = "";
        pov.m_VerticalAxis.m_InputAxisName = "";
        pov.m_HorizontalAxis.m_InputAxisValue = 0;
        pov.m_VerticalAxis.m_InputAxisValue = 0;
    }

    public void EditCurcorOff()
    {
        OnInput();
        isOpened = false;
        
        TableManager.instance.TableClose();
        
        detailsPanel.SetActive(false);
        viewCamera.SetActive(false);
        craftView.SetActive(false);
        chatPanel.SetActive(false);

        for (int i = 0; i < morePanel.Length; i++)
        {
            morePanel[i].SetActive(false);
        }
        
        globalCanvas.SetActive(false);
        inventoryPanel.SetActive(true);
        craftPanel.SetActive(true);

        anim.SetBool("Hit", false);
        QuickslotInventory.instance.attacke = false;
        
        Cursor.lockState = CursorLockMode.Locked; // Прекрепляем курсор к середине экрана
        Cursor.visible = false; // и делаем его невидимым

        pov.m_HorizontalAxis.m_InputAxisName = "Mouse X";
        pov.m_VerticalAxis.m_InputAxisName = "Mouse Y";
    }
}