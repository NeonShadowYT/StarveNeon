using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "Bioteh", menuName = "Neon Imperium/Bioteh/New Gen")]
public class GenScriptableObject : ScriptableObject
{
    [Space]
    [Header("Настройки гена")]
    public string NameGen;
    public string Descriphen;

    [Space]
    public Sprite icon;

    [Space]
    public int NaturalColdArmor = 0;

    public float RegenPlus = 1f, FoodPlus = 1f, WaterPlus = 1f, ColdPlus = 1f, HealthPlus = 1f, RazbrosPlus = 1f, DamagePlus = 1f, AdColdPlus = 1f, SnowColdPlus = 1f, NightSpeed = 1f, DaySpeed = 1f, NoArmorSpeed = 1f, ArmorSpeed = 1f, MyPlants = 1f, PetsPlus = 1f, TimeWeb = 1f, DamageBlood = 1f, CritPlus = 1f, CritDamage = 1f;

    [Space]
    public int Complexity = 1;
    public int Metabalizm;
}
