using System.Collections.Generic;
using UnityEngine;
//using System.Threading.Tasks;
//Parallel.ForEach(aiAnimUpdate, ai => ai.AnimUpdate());
public class GlobalInvoker : MonoBehaviour
{
    public CustomCharacterController customCharacterController;
    public DataSaveLoad dataSaveLoad;
    public bool sleepAI;

    [Space]
    public List<AIManager> aiAnimUpdate;
    public List<AIManager> aiViewTarget;
    public List<AIManager> aiMoveAnimal;

    [Space]
    public List<TimeForSpawnAndDespawn> spawnAndDespawn;

    void Start()
    {
        Daytime daytime = FindObjectOfType<Daytime>();
        
        if (daytime != null) daytime.globalInvoker = this; else Debug.Log("Null DayTime");
        
        InvokeRepeating(nameof(AnimUpdate), 0.1f, 0.1f);
        InvokeRepeating(nameof(ViewTarget), 0.1f, 0.1f);
        InvokeRepeating(nameof(MoveAnimal), Random.Range(7.5f, 10f), Random.Range(7.5f, 10f));

        InvokeRepeating(nameof(SpawnAndDespawn), 10f, 10f);
    }

    void AnimUpdate()
    {
        for (int i = 0; i < aiAnimUpdate.Count; i++)
        {
            aiAnimUpdate[i].AnimUpdate();
        }
    }

    void ViewTarget()
    {
        for (int i = 0; i < aiViewTarget.Count; i++)
        {
            aiViewTarget[i].ViewTarget();
        }
    }

    void MoveAnimal()
    {
        for (int i = 0; i < aiMoveAnimal.Count; i++)
        {
            aiMoveAnimal[i].MoveAnimal();
        }
    }

    void SpawnAndDespawn()
    {
        for (int i = 0; i < spawnAndDespawn.Count; i++)
        {
            spawnAndDespawn[i].ChangSpawn();
        }
    }
}
