using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DecorManager : MonoBehaviour
{
    [Space]
    [Header("Декор")]
    public List<DecorList> decorList;

    void Start()
    {
        foreach (DecorList _decor in decorList) _decor.Decor.SetActive(false);

        int idDecor = 1;

        idDecor = PlayerPrefs.GetInt("Decoration");
            
        if (idDecor != 0)
        {
            for (int i = 0; i < decorList.Count; i++)
            {
                if (i <= idDecor)
                {
                    decorList[i].Decor.SetActive(true);
                }
                else
                {
                    Destroy(decorList[i].Decor);
                }

            }
        }
        else
        {
            for (int i = 0; i < decorList.Count; i++)
            {
                Destroy(decorList[i].Decor);
            }
        }
    }
}
