using System.Collections.Generic;
using Cinemachine;
using TMPro;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class OptionManager : MonoBehaviour
{
    [Space]
    [Header("Данные")]
    [SerializeField] private MemoryOptimizer memoryOptimizer;
    [SerializeField] private VariableJoystick joystick;
    [SerializeField] private WeatherManager weather;

    [SerializeField] private CinemachineVirtualCamera CVC;
    [SerializeField] private UniversalAdditionalCameraData cameraData;

    private CinemachinePOV pov;
    private Cinemachine3rdPersonFollow fol;

    [Space]
    [Header("Настройки")]
    [Header("Графика")]
    [SerializeField] private TMP_Dropdown quality;
    [SerializeField] private TMP_Text qualityText;

    [Space]
    [SerializeField] private TMP_Dropdown resolution;
    [SerializeField] private TMP_Text resolutionText;

    [Space]
    [SerializeField] private Slider scaling;
    [SerializeField] private TMP_Text scalingText;

    [Space]
    [SerializeField] private TMP_Dropdown window;
    [SerializeField] private TMP_Text windowText;

    [Space]
    [SerializeField] private TMP_Dropdown fogMode;
    [SerializeField] private TMP_Text fogModeText;

    [Space]
    [SerializeField] private TMP_Dropdown details;
    [SerializeField] private TMP_Text detailsText;

    [Space]
    [SerializeField] private TMP_Dropdown decoration;
    [SerializeField] private TMP_Text decorationText;

    [Space]
    [SerializeField] private TMP_Dropdown aliasingMode;
    [SerializeField] private TMP_Text aliasingModeText;

    [Space]
    [SerializeField] private TMP_Dropdown aliasingQuality;
    [SerializeField] private TMP_Text aliasingQualityText;

    [Space]
    [SerializeField] private TMP_Dropdown aliasingPower;
    [SerializeField] private TMP_Text aliasingPowerText;

    [Space]
    [SerializeField] private TMP_Dropdown vsync;
    [SerializeField] private TMP_Text vsyncText;

    [Space]
    [SerializeField] private TMP_Dropdown fpcLock;
    [SerializeField] private TMP_Text fpcLockText;

    [Space]
    [SerializeField] private Slider viewDisance;
    [SerializeField] private TMP_Text viewDisanceText;

    [Space]
    [SerializeField] private Slider drawDistance;
    [SerializeField] private TMP_Text drawDistanceText;

    [Space]
    [SerializeField] private Slider shadowDistance;
    [SerializeField] private TMP_Text shadowDistanceText;

    [Space]
    [SerializeField] private Slider additionalLights;
    [SerializeField] private TMP_Text additionalLightsText;

    [Space]
    [SerializeField] private TMP_Dropdown hdr;
    [SerializeField] private TMP_Text hdrText;

    [Header("Обработка")]
    [SerializeField] private VolumeProfile volumeProfile;
    private ColorAdjustments colorAdjustments;
    private MotionBlur motionBlur;
    private DepthOfField depthOfField;

    [Space]
    [SerializeField] private TMP_Dropdown postProcessing;
    [SerializeField] private TMP_Text postProcessingText;

    [Space]
    [SerializeField] private TMP_Dropdown adjustment;
    [SerializeField] private TMP_Text gradientText;

    [Space]
    [SerializeField] private Slider brightness;
    [SerializeField] private TMP_Text brightnessText;

    [Space]
    [SerializeField] private Slider contrast;
    [SerializeField] private TMP_Text contrastText;

    [Space]
    [SerializeField] private Slider saturation;
    [SerializeField] private TMP_Text saturationText;

    [Space]
    [SerializeField] private TMP_Dropdown motionBlurEnable;
    [SerializeField] private TMP_Text motionBlurEnableText;

    [Space]
    [SerializeField] private Slider motionBlurPower;
    [SerializeField] private TMP_Text motionBlurPowerText;

    [Space]
    [SerializeField] private TMP_Dropdown depthOfFieldEnable;
    [SerializeField] private TMP_Text depthOfFieldEnableText;

    [Space]
    [SerializeField] private Slider depthOfFieldRange;
    [SerializeField] private TMP_Text depthOfFieldRangeText;

    [Header("НеоТикс")]
    [SerializeField] private Material material;
    [SerializeField] private Shader stadartShader;
    [SerializeField] private Shader neotxShader;
    [SerializeField] private Shader potatoShader;

    [Space]
    [SerializeField] private TMP_Dropdown neotx;
    [SerializeField] private TMP_Text neotxText;

    [Space]
    [SerializeField] private Slider neotxPower;
    [SerializeField] private TMP_Text neotxPowerText;

    [Space]
    [SerializeField] private Slider neotxMetal;
    [SerializeField] private TMP_Text neotxMetalText;

    [Header("Управление")]
    [SerializeField] private InputActionReference actionReferenceEsc;
    [SerializeField] private InputActionReference actionReferenceLut;

    [SerializeField] private TMP_Dropdown joystic;
    [SerializeField] private TMP_Text joysticText;

    [Space]
    [SerializeField] private TMP_Dropdown viewMode;
    [SerializeField] private TMP_Text viewModeText;

    [Space]
    [SerializeField] private Slider sensitivity;
    [SerializeField] private TMP_Text sensitivityText;

    [Space]
    [SerializeField] private Slider fovDisance;
    [SerializeField] private TMP_Text fovDisanceText;

    [SerializeField] private TMP_InputField escInput;
    [SerializeField] private TMP_InputField lutInput;

    [Header("Звуки")]
    [SerializeField] private AudioMixer audioMixer;
    [SerializeField] private AudioMixer chatMixer;

    [Space]
    [SerializeField] private Slider volume;
    [SerializeField] private TMP_Text volumeText;

    [Space]
    [SerializeField] private Slider chatVolume;
    [SerializeField] private TMP_Text chatVolumeText;

    [Header("Особое")]
    [SerializeField] private TMP_Dropdown adsMode;
    [SerializeField] private TMP_Text adsModeText;

    [Space]
    [SerializeField] private Slider physics;
    [SerializeField] private TMP_Text physicsText;

    [Space]
    [Header("Другое")]
    public List<CameraViewMode> camViewMode;

    private Resolution[] resolutions;
    private int currentResolutionIndex;

    private FullScreenMode fullScreenMode;
    private UniversalRenderPipelineAsset universalRenderPipeline;

    private void Awake()
    {
        pov = CVC.GetCinemachineComponent<CinemachinePOV>();
        fol = CVC.GetCinemachineComponent<Cinemachine3rdPersonFollow>();

        weather = FindObjectOfType<WeatherManager>();
        universalRenderPipeline = GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset;

        if (volumeProfile.TryGet(out colorAdjustments))
        if (volumeProfile.TryGet(out motionBlur))
        if (volumeProfile.TryGet(out depthOfField))

        PopulateResolutionDropdown();
        PreloadSettings();

        Invoke(nameof(SetVolume), 0.01f);
    }

    public void PreloadSettings() => LoadSettings(currentResolutionIndex);

    #region Settings Funcs
    private void PopulateResolutionDropdown()
    {
        resolution.ClearOptions();

        List<string> options = new List<string>();
            
        resolutions = Screen.resolutions;
        currentResolutionIndex = 0;

        for (int i = 0; i < resolutions.Length; i++)
        {
            string option = resolutions[i].width + "x" + resolutions[i].height + " " + resolutions[i].refreshRateRatio.value + "Гц";
            options.Add(option);

            if (resolutions[i].width == Screen.currentResolution.width && resolutions[i].height == Screen.currentResolution.height && resolutions[i].refreshRateRatio.value == Screen.currentResolution.refreshRateRatio.value)
            currentResolutionIndex = i;
        }

        resolution.AddOptions(options);
        resolution.RefreshShownValue();
    }

    public void SetQuality() 
    {
        QualitySettings.SetQualityLevel(quality.value);
        universalRenderPipeline = GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset;

        SetDrawDistanceSettings();
        SetShadowDistanceSettings();
        SetAdditionalLights();

        SetScaling();
        SetAliasing();

        qualityText.text = quality.value.ToString();
    }
    
    public void SetResolution()
    {
        Resolution resolution = resolutions[this.resolution.value];

        switch (Application.platform)
        {
            case RuntimePlatform.WindowsEditor :
                Screen.SetResolution(resolution.width, resolution.height, fullScreenMode, resolution.refreshRateRatio);
                break;
            case RuntimePlatform.WindowsPlayer :
                Screen.SetResolution(resolution.width, resolution.height, fullScreenMode, resolution.refreshRateRatio);
                break;
        }

        resolutionText.text = this.resolution.value.ToString();
    }

    public void SetScaling() 
    {
        universalRenderPipeline.renderScale = scaling.value;
        scalingText.text = scaling.value.ToString();
    }

    public void SetFullscreen() 
    {
        switch (window.value)
        {
            case 0:
                fullScreenMode = FullScreenMode.FullScreenWindow;
                break;
            case 1:
                fullScreenMode = FullScreenMode.ExclusiveFullScreen;
                break;
            case 2:
                fullScreenMode = FullScreenMode.Windowed;
                break;
            case 3:
                fullScreenMode = FullScreenMode.MaximizedWindow;
                break;
        }

        Screen.fullScreenMode = fullScreenMode;
        windowText.text = window.value.ToString();

        SetResolution();
    }

    public void SetPostProcessing()
    {
        switch (postProcessing.value)
        {
            case 0:
                cameraData.renderPostProcessing = false;
                
                adjustment.interactable = false;
                motionBlurEnable.interactable = false;
                depthOfFieldEnable.interactable = false;
                break;
            case 1:
                cameraData.renderPostProcessing = true;

                adjustment.interactable = true;
                motionBlurEnable.interactable = true;
                depthOfFieldEnable.interactable = true;
                break;
        }

        postProcessingText.text = postProcessing.value.ToString();
    }

    public void SetGradientEnabled()
    {
        if (adjustment.value == 0)
        {
            colorAdjustments.active = false;

            brightness.interactable = false;
            contrast.interactable = false;
            saturation.interactable = false;
        }
        else
        {
            colorAdjustments.active = true;

            brightness.interactable = true;
            contrast.interactable = true;
            saturation.interactable = true;
        }

        colorAdjustments.postExposure.Override(brightness.value);
        colorAdjustments.contrast.Override(contrast.value);
        colorAdjustments.saturation.Override(saturation.value);

        gradientText.text = adjustment.value.ToString();
        brightnessText.text = brightness.value.ToString();
        contrastText.text = contrast.value.ToString();
        saturationText.text = saturation.value.ToString();
    }

    public void SetMotionBlur()
    {
        if (motionBlurEnable.value == 0)
        {
            motionBlur.active = false;
            motionBlurPower.interactable = false;
        }
        else
        {
            motionBlur.active = true;
            motionBlurPower.interactable = true;
        }
        
        motionBlur.intensity.Override(motionBlurPower.value);

        motionBlurEnableText.text = motionBlurEnable.value.ToString();
        motionBlurPowerText.text = motionBlurPower.value.ToString();
    }

    public void SetDepthOfField()
    {
        if (depthOfFieldEnable.value == 0)
        {
            depthOfField.active = false;
            depthOfFieldRange.interactable = false;
        }
        else
        {
            depthOfField.active = true;
            depthOfFieldRange.interactable = true;
        }

        depthOfField.focusDistance.Override(depthOfFieldRange.value);

        depthOfFieldEnableText.text = depthOfFieldEnable.value.ToString();
        depthOfFieldRangeText.text = depthOfFieldRange.value.ToString();
    }

    public void SetFogSettings()
    {
        if (weather == null) return;

        switch (fogMode.value)
        {
            case 0 :
                weather.fogEnabled = false;
                break;
            case 1 :
                weather.fogEnabled = true;
                weather.fogMode = FogMode.Linear;
                break;
            case 2 :
                weather.fogEnabled = true;
                weather.fogMode = FogMode.Exponential;
                break;
            case 3 :
                weather.fogEnabled = true;
                weather.fogMode = FogMode.ExponentialSquared;
                break;
        }

        fogModeText.text = fogMode.value.ToString();
        weather.ChangSettings();
    }

    public void SetDetails() 
    {
        detailsText.text = details.value.ToString();
    }

    public void SetDecore() 
    {
        decorationText.text = decoration.value.ToString();
    }

    public void SetAliasing() 
    {
        switch (aliasingMode.value)
        {
            case 0:
                cameraData.antialiasing = AntialiasingMode.None;
                universalRenderPipeline.msaaSampleCount = 1;
                aliasingQuality.interactable = false;
                aliasingPower.interactable = false;
                break;
            case 1:
                cameraData.antialiasing = AntialiasingMode.None;
                aliasingQuality.interactable = false;
                aliasingPower.interactable = true;
                break;
            case 2:
                cameraData.antialiasing = AntialiasingMode.FastApproximateAntialiasing;
                aliasingQuality.interactable = false;
                aliasingPower.interactable = false;
                break;
            case 3:
                cameraData.antialiasing = AntialiasingMode.SubpixelMorphologicalAntiAliasing;
                aliasingQuality.interactable = true;
                aliasingPower.interactable = false;
                break;
            case 4:
                cameraData.antialiasing = AntialiasingMode.TemporalAntiAliasing;
                aliasingQuality.interactable = true;
                aliasingPower.interactable = false;
                break;
        }

        switch (aliasingQuality.value)
        {
            case 0:
                cameraData.antialiasingQuality = AntialiasingQuality.Low;
                break;
            case 1:
                cameraData.antialiasingQuality = AntialiasingQuality.Medium;
                break;
            case 2:
                cameraData.antialiasingQuality = AntialiasingQuality.High;
                break;
        }

        switch (aliasingPower.value)
        {
            case 0:
                universalRenderPipeline.msaaSampleCount = 2;
                break;
            case 1:
                universalRenderPipeline.msaaSampleCount = 4;
                break;
            case 2:
                universalRenderPipeline.msaaSampleCount = 8;
                break;
        }

        aliasingModeText.text = aliasingMode.value.ToString();
        aliasingQualityText.text = aliasingQuality.value.ToString();
        aliasingPowerText.text = aliasingPower.value.ToString();
    }

    public void SetVSync() 
    {
        if (vsync.value == 0)
        {
            fpcLock.interactable = true;
        }
        else
        {
            fpcLock.interactable = false;
        }

        QualitySettings.vSyncCount = vsync.value;
        vsyncText.text = vsync.value.ToString();
    }

    public void SetFPSLock()
    {
        switch (fpcLock.value)
        {
            case 0:
                Application.targetFrameRate = -1;
                break;
            case 1:
                Application.targetFrameRate = 30;
                break;
            case 2:
                Application.targetFrameRate = 60;
                break;
            case 3:
                Application.targetFrameRate = 120;
                break;
            case 4:
                Application.targetFrameRate = 240;
                break;
        }

        fpcLockText.text = fpcLock.value.ToString();
    }

    public void SetPhysics()
    {
        Time.fixedDeltaTime = physics.value;
        physicsText.text = physics.value.ToString();
    }

    public void SetViewDistanceSettings()
    {
        if (CVC != null)
        {
            CVC.m_Lens.FarClipPlane = viewDisance.value;
        }

        viewDisanceText.text = viewDisance.value.ToString();
    }

    public void SetDrawDistanceSettings()
    {
        QualitySettings.lodBias = drawDistance.value;
        drawDistanceText.text = drawDistance.value.ToString();
    }

    public void SetShadowDistanceSettings()
    {
        universalRenderPipeline.shadowDistance = shadowDistance.value;
        shadowDistanceText.text = shadowDistance.value.ToString();

        if (shadowDistance.value != 0)
        {
            cameraData.renderShadows = true;
        }
        else
        {
            cameraData.renderShadows = false;
        }
    }

    public void SetAdditionalLights()
    {
        universalRenderPipeline.maxAdditionalLightsCount = (int)additionalLights.value;
        additionalLightsText.text = additionalLights.value.ToString();
    }

    public void SetHdrEnabled()
    {
        switch (hdr.value)
        {
            case 0:
                universalRenderPipeline.supportsHDR = false;
                break;
            case 1:
                universalRenderPipeline.supportsHDR = true;;
                break;
        }

        hdrText.text = hdr.value.ToString();
    }

    public void SetNeoTXSettings() 
    {
        switch (neotx.value)
        {
            case 0:
                material.shader = stadartShader;
                material.SetFloat("_Smoothness", 0);
                material.SetFloat("_Metallic", 0);

                neotxPower.interactable = false;
                neotxMetal.interactable = false;
                break;
            case 1:
                material.shader = neotxShader;
                material.SetFloat("_Smoothness", neotxPower.value);
                material.SetFloat("_Metallic", neotxMetal.value);

                neotxPower.interactable = true;
                neotxMetal.interactable = true;
                break;
            case 2:
                material.shader = potatoShader;
                material.SetFloat("_Smoothness", 0);
                material.SetFloat("_Metallic", 0);

                neotxPower.interactable = false;
                neotxMetal.interactable = false;
                break;
        }

        neotxText.text = neotx.value.ToString();
        neotxPowerText.text = neotxPower.value.ToString();
        neotxMetalText.text = neotxMetal.value.ToString();
    }

    public void SetJoysticSettings()
    {
        if (joystick == null) return;

        switch (joystic.value)
        {
            case 0:
                joystick.SetMode(JoystickType.Fixed);
                break;
            case 1:
                joystick.SetMode(JoystickType.Dynamic);
                break;
            case 2:
                joystick.SetMode(JoystickType.Floating);
                break;
        }

        joysticText.text = joystic.value.ToString();
    }

    public void SetViewMode()
    {
        if (fol != null)
        {
            fol.ShoulderOffset = camViewMode[viewMode.value].position;
        }

        viewModeText.text = viewMode.value.ToString();
    }

    public void SetSensitivitySettings()
    {
        if (pov != null) 
        {
            pov.m_HorizontalAxis.m_MaxSpeed = sensitivity.value;
            pov.m_VerticalAxis.m_MaxSpeed = sensitivity.value;
        }

        sensitivityText.text = sensitivity.value.ToString();
    }

    public void SetFieldOfViewSettings()
    {
        if (CVC != null)
        {
            CVC.m_Lens.FieldOfView = fovDisance.value;
        }

        fovDisanceText.text = fovDisance.value.ToString();
    }

    public void SetInput()
    {
        actionReferenceEsc.action.ApplyBindingOverride(0, "<Keyboard>/" + escInput.text);
        actionReferenceLut.action.ApplyBindingOverride(0, "<Keyboard>/" + lutInput.text);
    }

    public void SetVolume()
    {
        audioMixer.SetFloat("volume", Mathf.Log10(volume.value) * 20);
        chatMixer.SetFloat("volume", Mathf.Log10(chatVolume.value) * 20);

        volumeText.text = volume.value.ToString();
        chatVolumeText.text = chatVolume.value.ToString();

        if (volume.value <= 0.0001f)
        {
            AudioListener.pause = true;
            chatVolume.interactable = false;
        }
        else
        {
            AudioListener.pause = false;
            chatVolume.interactable = true;
        }
    }

    public void SetAdsModeSettings() 
    {
        adsModeText.text = adsMode.value.ToString();
    }

    public void SaveSettings()
    {
        PlayerPrefs.SetInt("QualitySettings", quality.value);
        PlayerPrefs.SetFloat("Scaling", scaling.value);
        PlayerPrefs.SetInt("FogMode", fogMode.value);
        PlayerPrefs.SetInt("Details", details.value);
        PlayerPrefs.SetInt("Decoration", decoration.value);
        PlayerPrefs.SetFloat("ViewDistance", viewDisance.value);
        PlayerPrefs.SetFloat("DrawDistance", drawDistance.value);
        PlayerPrefs.SetFloat("ShadowDistance", shadowDistance.value);
        PlayerPrefs.SetFloat("AdditionalLights", additionalLights.value);

        PlayerPrefs.SetInt("PostProcessing", postProcessing.value);
        PlayerPrefs.SetInt("Adjustment", adjustment.value);
        PlayerPrefs.SetFloat("Brightness", brightness.value);
        PlayerPrefs.SetFloat("Contrast", contrast.value);
        PlayerPrefs.SetFloat("Saturation", saturation.value);
        PlayerPrefs.SetInt("MotionBlurEnable", motionBlurEnable.value);
        PlayerPrefs.SetFloat("MotionBlurPower", motionBlurPower.value);
        PlayerPrefs.SetInt("DepthOfFieldEnable", depthOfFieldEnable.value);
        PlayerPrefs.SetFloat("DepthOfFieldRange", depthOfFieldRange.value);

        PlayerPrefs.SetInt("NeoTXEnabled", neotx.value);
        PlayerPrefs.SetFloat("NeotxPower", neotxPower.value);
        PlayerPrefs.SetFloat("NeotxMetal", neotxMetal.value);

        PlayerPrefs.SetInt("Resolution", resolution.value);
        PlayerPrefs.SetInt("Fullscreen", window.value);
        PlayerPrefs.SetInt("VSync", vsync.value);
        PlayerPrefs.SetInt("FPSLock", fpcLock.value);

        PlayerPrefs.SetInt("HDR", hdr.value);
        PlayerPrefs.SetInt("AliasingMode", aliasingMode.value);
        PlayerPrefs.SetInt("AliasingQuality", aliasingQuality.value);
        PlayerPrefs.SetInt("AliasingPower", aliasingPower.value);

        PlayerPrefs.SetInt("JoysticSettings", joystic.value);
        PlayerPrefs.SetInt("ViewMode", viewMode.value);
        PlayerPrefs.SetFloat("Sensitivity", sensitivity.value);
        PlayerPrefs.SetFloat("FovDistance", fovDisance.value);
        PlayerPrefs.SetString("EscInput", escInput.text);
        PlayerPrefs.SetString("LutInput", lutInput.text);

        PlayerPrefs.SetFloat("Volume", volume.value);
        PlayerPrefs.SetFloat("ChatVolume", chatVolume.value);

        PlayerPrefs.SetFloat("Physics", physics.value);
        PlayerPrefs.SetInt("AdsMode", adsMode.value);
    }

    public void LoadSettings(int currentResolutionIndex)
    {
        if (PlayerPrefs.HasKey("QualitySettings")) quality.value = PlayerPrefs.GetInt("QualitySettings"); else quality.value = 2;
        if (PlayerPrefs.HasKey("Scaling")) scaling.value = PlayerPrefs.GetFloat("Scaling"); else scaling.value = 1f;
        if (PlayerPrefs.HasKey("FogMode")) fogMode.value = PlayerPrefs.GetInt("FogMode"); else fogMode.value = 2;
        if (PlayerPrefs.HasKey("Details")) details.value = PlayerPrefs.GetInt("Details"); else details.value = 0;
        if (PlayerPrefs.HasKey("Decoration")) decoration.value = PlayerPrefs.GetInt("Decoration"); else decoration.value = 1;
        if (PlayerPrefs.HasKey("ViewDistance")) viewDisance.value = PlayerPrefs.GetFloat("ViewDistance"); else viewDisance.value = 400f;
        if (PlayerPrefs.HasKey("DrawDistance")) drawDistance.value = PlayerPrefs.GetFloat("DrawDistance"); else drawDistance.value = 1.5f;
        if (PlayerPrefs.HasKey("ShadowDistance")) shadowDistance.value = PlayerPrefs.GetFloat("ShadowDistance"); else shadowDistance.value = 100f;
        if (PlayerPrefs.HasKey("AdditionalLights")) additionalLights.value = PlayerPrefs.GetFloat("AdditionalLights"); else additionalLights.value = 8f;

        if (PlayerPrefs.HasKey("PostProcessing")) postProcessing.value = PlayerPrefs.GetInt("PostProcessing"); else postProcessing.value = 0;
        if (PlayerPrefs.HasKey("Adjustment")) adjustment.value = PlayerPrefs.GetInt("Adjustment"); else adjustment.value = 1;
        if (PlayerPrefs.HasKey("Brightness")) brightness.value = PlayerPrefs.GetFloat("Brightness"); else brightness.value = 0.35f;
        if (PlayerPrefs.HasKey("Contrast")) contrast.value = PlayerPrefs.GetFloat("Contrast"); else contrast.value = 15f;
        if (PlayerPrefs.HasKey("Saturation")) saturation.value = PlayerPrefs.GetFloat("Saturation"); else saturation.value = 15f;
        if (PlayerPrefs.HasKey("MotionBlurEnable")) motionBlurEnable.value = PlayerPrefs.GetInt("MotionBlurEnable"); else motionBlurEnable.value = 0;
        if (PlayerPrefs.HasKey("MotionBlurPower")) motionBlurPower.value = PlayerPrefs.GetFloat("MotionBlurPower"); else motionBlurPower.value = 1f;
        if (PlayerPrefs.HasKey("DepthOfFieldEnable")) depthOfFieldEnable.value = PlayerPrefs.GetInt("DepthOfFieldEnable"); else depthOfFieldEnable.value = 1;
        if (PlayerPrefs.HasKey("DepthOfFieldRange")) depthOfFieldRange.value = PlayerPrefs.GetFloat("DepthOfFieldRange"); else depthOfFieldRange.value = 2.5f;

        if (PlayerPrefs.HasKey("NeoTXEnabled")) neotx.value = PlayerPrefs.GetInt("NeoTXEnabled"); else neotx.value = 0;
        if (PlayerPrefs.HasKey("NeotxPower")) neotxPower.value = PlayerPrefs.GetFloat("NeotxPower"); else neotxPower.value = 0.35f;
        if (PlayerPrefs.HasKey("NeotxMetal")) neotxMetal.value = PlayerPrefs.GetFloat("NeotxMetal"); else neotxMetal.value = 0.1f;

        if (PlayerPrefs.HasKey("Resolution")) resolution.value = PlayerPrefs.GetInt("Resolution"); else resolution.value = currentResolutionIndex;
        if (PlayerPrefs.HasKey("Fullscreen")) window.value = PlayerPrefs.GetInt("Fullscreen"); else window.value = 0;
        if (PlayerPrefs.HasKey("VSync")) vsync.value = PlayerPrefs.GetInt("VSync"); else vsync.value = 0;
        if (PlayerPrefs.HasKey("FPSLock")) fpcLock.value = PlayerPrefs.GetInt("FPSLock"); else fpcLock.value = 0;

        if (PlayerPrefs.HasKey("HDR")) hdr.value = PlayerPrefs.GetInt("HDR"); else hdr.value = 0;
        if (PlayerPrefs.HasKey("AliasingMode")) aliasingMode.value = PlayerPrefs.GetInt("AliasingMode"); else aliasingMode.value = 0;
        if (PlayerPrefs.HasKey("AliasingQuality")) aliasingQuality.value = PlayerPrefs.GetInt("AliasingQuality"); else aliasingQuality.value = 0;
        if (PlayerPrefs.HasKey("AliasingPower")) aliasingPower.value = PlayerPrefs.GetInt("AliasingPower"); else aliasingPower.value = 0;
        
        if (PlayerPrefs.HasKey("JoysticSettings")) joystic.value = PlayerPrefs.GetInt("JoysticSettings"); else joystic.value = 2;
        if (PlayerPrefs.HasKey("Sensitivity")) sensitivity.value = PlayerPrefs.GetFloat("Sensitivity"); else sensitivity.value = 1.75f;
        if (PlayerPrefs.HasKey("ViewMode")) viewMode.value = PlayerPrefs.GetInt("ViewMode"); else viewMode.value = 1;
        if (PlayerPrefs.HasKey("FovDistance")) fovDisance.value = PlayerPrefs.GetFloat("FovDistance"); else fovDisance.value = 60f;
        if (PlayerPrefs.HasKey("EscInput")) escInput.text = PlayerPrefs.GetString("EscInput"); else escInput.text = "Escape";
        if (PlayerPrefs.HasKey("LutInput")) lutInput.text = PlayerPrefs.GetString("LutInput"); else lutInput.text = "E";

        if (PlayerPrefs.HasKey("Volume")) volume.value = PlayerPrefs.GetFloat("Volume"); else volume.value = 0.8f;
        if (PlayerPrefs.HasKey("ChatVolume")) chatVolume.value = PlayerPrefs.GetFloat("ChatVolume"); else chatVolume.value = 1f;

        if (PlayerPrefs.HasKey("Physics")) physics.value = PlayerPrefs.GetFloat("Physics"); else physics.value = 0.02f;
        if (PlayerPrefs.HasKey("AdsMode")) adsMode.value = PlayerPrefs.GetInt("AdsMode"); else adsMode.value = 0;
    }
    #endregion

    public void DeliteSettings()
    {
        PlayerPrefs.DeleteAll();
    }

    public void DeliteSave()
    {
        BinarySavingSystem.DeleteSave();

        Quit();
    }

    public void Quit() => Application.Quit();

    public void Multiplayer(bool multiplayer)
    {
        PlayerPrefs.SetInt("Multiplayer", System.Convert.ToInt32(multiplayer));
    }

    public void NewGame(bool newGame)
    {
        PlayerPrefs.SetInt("NewGame", System.Convert.ToInt32(newGame));
    }
}

[System.Serializable]
public class CameraViewMode
{
    public Vector3 position;
}