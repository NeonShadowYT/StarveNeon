﻿using UnityEngine;

public enum ItemType { Default, Food, Weapon, FireWeapon, Instrument, BuildingPlan, Transport }
public enum AnimType { Default, Spear, BigSwords, Gun, Kosa }
public enum ClothType { None, Armor, Baskpack, Shield }
public enum EquipEffect { None, Blood, Web, Poison, Infected, Fire, Frost, Mutagen, Regen, Water, Jump, Speed }
public enum SpeedAttacke { Medium, Low, Max }

[CreateAssetMenu(fileName = "Item", menuName = "Neon Imperium/Inventory/New Item")]
public class ItemScriptableObject : ScriptableObject // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Название предмета")]
    public string itemName;
    public string inHandName;

    [Space]
    [Header("Иконка")]
    public Sprite icon;

    [Space]
    [Header("Максимальное количество в слоте")]
    public int maximumAmount = 1;

    [Space]
    [Header("Прочность")]
    public int maximumDurability = 0;

    [Space]
    [Header("Описание предмета")]
    public string itemDescription;

    [Space]
    [Header("Префабы")]
    public GameObject itemPrefab;
    public GameObject buildingPrefab;

    [Space]
    [Header("Тип предмета")]
    public ItemType itemType = ItemType.Default;
    public AnimType animType = AnimType.Default;
    public ClothType clothType = ClothType.None;
    public EquipEffect equipEffect = EquipEffect.None;
    public SpeedAttacke speedAttacke = SpeedAttacke.Medium;

    [Space]
    [Header("Звук предмета")]
    public AudioClip itemAudio;

    [Space]
    [Header("Получаемые характеристики")]
    public float changeHealth;
    public float changeHunger, changeThirst, changeCold;

    [Range(0, 100)]
    public int chanceEffect = 100;
}
