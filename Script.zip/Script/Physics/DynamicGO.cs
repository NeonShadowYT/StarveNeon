using System.Collections;
using UnityEngine;

public class DynamicGO : MonoBehaviour
{
    [SerializeField] private Transform[] _targetTransform;

    [SerializeField] private Vector3 _scaleDown = new Vector3(0.8f, 0.6f, 0.8f);
    [SerializeField] private Vector3 _scaleNormal = new Vector3(0.7f, 0.7f, 0.7f);
    [SerializeField] private Vector3 _scaleUp = new Vector3(0.6f, 0.8f, 0.6f);

    [SerializeField] private float _scaleSpeed = 2.5f;
    [SerializeField] private float _rotationSpeed = 35f;

    private Transform mTransform;

    void Start()
    {
        mTransform = transform;
    }

    void Update()
    {
        for (int i = 0; i < _targetTransform.Length; i++) 
        {
            Vector3 relativePosition = _targetTransform[i].InverseTransformPoint(mTransform.position);
            float interpolant = relativePosition.y * _scaleSpeed;

            Vector3 scale = Lerp3(_scaleDown, _scaleNormal, _scaleUp, interpolant);

            _targetTransform[i].localScale = scale;
            _targetTransform[i].localEulerAngles = new Vector3(relativePosition.z, 0, -relativePosition.x) * _rotationSpeed;
        }
    }

    Vector3 Lerp3(Vector3 a, Vector3 b, Vector3 c, float t)
    {
        if(t<0)
        {
            return Vector3.Lerp(a, b, t + 1f);
        }
        else
        {
            return Vector3.Lerp(b, c, t);
        }
    }
}
