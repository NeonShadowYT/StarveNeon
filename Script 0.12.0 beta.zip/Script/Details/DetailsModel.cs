using UnityEngine;

public class DetailsModel : MonoBehaviour
{
    public MeshFilter meshFilter;
    public string detailsName;
}