using System.Collections.Generic;
using UnityEngine;

public class EffectPool : MonoBehaviour
{
    public List<EffectObject> effectObject;

    void Start()
    {
        for (int i = 0; i < effectObject.Count; i++)
        {
            effectObject[i].effectTransform = effectObject[i].effectSystem.transform;
        }
    }

    public void ViewEffect(GameObject prefabEffect, Vector3 hitPoint)
    {
        for (int i = 0; i < effectObject.Count; i++)
        {
            if (effectObject[i].effectPrefab == prefabEffect && effectObject[i].activeTime <= 0)
            {
                effectObject[i].effectTransform.position = hitPoint;
                effectObject[i].effectSystem.Play();
                effectObject[i].activeTime = 3;
                break;
            }
        }

        for (int i = 0; i < effectObject.Count; i++)
        {
            effectObject[i].activeTime --;
        }
    }
}

[System.Serializable]
public class EffectObject
{
    public ParticleSystem effectSystem;
    public GameObject effectPrefab;

    [HideInInspector]
    public Transform effectTransform;

    public int activeTime;
}