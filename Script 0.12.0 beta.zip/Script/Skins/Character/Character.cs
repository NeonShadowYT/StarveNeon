using System.Collections;
using UnityEngine;

public class Character : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;

    public int i;
    public GameObject[] AllCharacters;

    public PhotonSetManager photonSetManager;

    public void Start()
    {
        foreach (GameObject character in AllCharacters)
        {
            if (character.name != dataSaveLoad.data.currentCharacterSkin)
            {
                character.SetActive(false);
            }
            else
            {
                character.SetActive(true);
            }
        }

        if (photonSetManager != null) 
        {
            if (PlayerPrefs.HasKey("Multiplayer"))
            {
                if(System.Convert.ToBoolean(PlayerPrefs.GetInt("Multiplayer")) == true)
                {
                    photonSetManager.SetSkin(dataSaveLoad.data.currentCharacterSkin);
                }
            }
        }
    }
}
