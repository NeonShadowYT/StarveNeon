﻿using System.Collections.Generic;
using UnityEngine;

public class BuildingBlock : MonoBehaviour
{
    [Space]
    public MeshRenderer _meshRenderer;
    private Material _blockMaterials;

    [Space]
    [SerializeField] private Material _greenMaterial;
    [SerializeField] private Material _redMaterial;

    [Space]
    public List<Collider> detectedColliders;
    protected Vector3 _colliderExtents;

    [Space]
    public bool canPlace;
    public bool isPlaced;

    protected virtual void Start()
    {
        BoxCollider _collider = GetComponent<BoxCollider>();
        if (_collider != null) _colliderExtents = _collider.size;

        _blockMaterials = _meshRenderer.material;
        
        if (!isPlaced) UpdateMaterials(); else this.enabled = false;
    }

    protected virtual void Update()
    {
        canPlace = detectedColliders.Count <= 0;
        if (!isPlaced) UpdateMaterials(); else this.enabled = false;
    }

    private void UpdateMaterials()
    {
        _meshRenderer.material = detectedColliders.Count > 0 ? _redMaterial : _greenMaterial;
    }

    public void ChangeToBlockMaterial()
    {
        _meshRenderer.material = _blockMaterials;
    }
}