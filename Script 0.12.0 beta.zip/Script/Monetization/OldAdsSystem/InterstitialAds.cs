
using UnityEngine;
using UnityEngine.Advertisements;

public class InterstitialAds : MonoBehaviour, IUnityAdsLoadListener, IUnityAdsShowListener
{
    public string appKeyAndroid;
    public DataSaveLoad dataSaveLoad;

    public void Start()
    {
        ShowAd();
    }

    public void ShowAd()
    {
        if (PlayerPrefs.HasKey("AdsMode"))
        {
            if (PlayerPrefs.GetInt("AdsMode") == 1) 
            {
                Advertisement.Load(appKeyAndroid, this);
                Advertisement.Show(appKeyAndroid, this);
            }
        }
    }

    public void OnUnityAdsAdLoaded(string placementId)
    {
        Debug.Log("Реклама загружена: " + placementId);
    }

    public void OnUnityAdsFailedToLoad(string placementId, UnityAdsLoadError error, string message)
    {
        Debug.Log($"Не удалось загрузить рекламу: {error.ToString()} - {message}");
        ShowAd();
    }

    public void OnUnityAdsShowFailure(string placementId, UnityAdsShowError error, string message)
    {
        Debug.Log($"Не удалось показать рекламу: {error.ToString()} - {message}");
        ShowAd();
    }

    public void OnUnityAdsShowStart(string placementId)
    {
        Debug.Log("Начался показ рекламы: " + placementId);
    }

    public void OnUnityAdsShowClick(string placementId)
    {
        Debug.Log("Нажатие на рекламу: " + placementId);

        switch(Random.Range(0, 9))
        {
            case 0 :
                dataSaveLoad.data.woodValue += Random.Range(128, 256);
                break;
            case 1 :
                dataSaveLoad.data.rockValue += Random.Range(64, 128);
                break;
            case 2 :
                dataSaveLoad.data.cuprumValue += Random.Range(32, 64);
                break;
            case 3 :
                dataSaveLoad.data.goldValue += Random.Range(16, 32);
                break;
            case 4 :
                dataSaveLoad.data.diamondValue += Random.Range(8, 16);
                break;
            case 5 :
                dataSaveLoad.data.ametistValue += Random.Range(4, 8);
                break;
            case 6 :
                dataSaveLoad.data.reditValue += Random.Range(2, 4);
                break;
            case 7 :
                dataSaveLoad.data.izumValue += Random.Range(1, 2);
                break;
            case 8 :
                dataSaveLoad.data.coreValue += 1;
                break;
            case 9 :
                dataSaveLoad.data.neolitValue += Random.Range(0, 1);
                break;
        }
    }

    public void OnUnityAdsShowComplete(string placementId, UnityAdsShowCompletionState showCompletionState)
    {
        if (showCompletionState.Equals(UnityAdsShowCompletionState.COMPLETED))
        {
            switch(Random.Range(0, 9))
            {
                case 0 :
                    dataSaveLoad.data.woodValue += Random.Range(128, 256);
                    break;
                case 1 :
                    dataSaveLoad.data.rockValue += Random.Range(64, 128);
                    break;
                case 2 :
                    dataSaveLoad.data.cuprumValue += Random.Range(32, 64);
                    break;
                case 3 :
                    dataSaveLoad.data.goldValue += Random.Range(16, 32);
                    break;
                case 4 :
                    dataSaveLoad.data.diamondValue += Random.Range(8, 16);
                    break;
                case 5 :
                    dataSaveLoad.data.ametistValue += Random.Range(4, 8);
                    break;
                case 6 :
                    dataSaveLoad.data.reditValue += Random.Range(2, 4);
                    break;
                case 7 :
                    dataSaveLoad.data.izumValue += Random.Range(1, 2);
                    break;
                case 8 :
                    dataSaveLoad.data.coreValue += 1;
                    break;
                case 9 :
                    dataSaveLoad.data.neolitValue += Random.Range(0, 1);
                    break;
            }
        }
    }
}