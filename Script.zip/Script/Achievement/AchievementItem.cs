using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class AchievementItem : MonoBehaviour
{
    [HideInInspector] public AchievementManager achievementManager;
    [HideInInspector] public DataSaveLoad dataSaveLoad;

    [Space]
    [Header("Основная инфа")]
    public AchievementScriptableObject achievementScriptableObject;

    [Space]
    public Button buttonAchievement;
    public Image achievementIcon;
    public TMP_Text achievementText;

    [Space]
    [Header("Награда")]
    public TMP_Text rewardText;
    public Image rewardIcon;

    [Space]
    [Header("Прогресс")]
    public Slider sliderProgress;
    public bool claimProgress;

    public void Unloke()
    {
        if (claimProgress == false)
        {
            claimProgress = true;

            switch (achievementScriptableObject.rewardType)
            {
                case RewardType.Wood :
                    dataSaveLoad.data.woodValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Rock :
                    dataSaveLoad.data.rockValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Cuprum :
                    dataSaveLoad.data.cuprumValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Gold :
                    dataSaveLoad.data.goldValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Diamond :
                    dataSaveLoad.data.diamondValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Ametist :
                    dataSaveLoad.data.reditValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Redit :
                    dataSaveLoad.data.reditValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Izum :
                    dataSaveLoad.data.izumValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Core :
                    dataSaveLoad.data.coreValue += achievementScriptableObject.rewardAmount;
                    break;
                case RewardType.Neolit :
                    dataSaveLoad.data.neolitValue += achievementScriptableObject.rewardAmount;
                    break;
            }

            achievementManager.ViewComplite(achievementScriptableObject);
        }

        if (GameJolt.API.GameJoltAPI.Instance != null && GameJolt.API.GameJoltAPI.Instance.CurrentUser != null)
        {
            GameJolt.API.Trophies.TryUnlock(achievementScriptableObject.IdGJ);
        }
    }
}
