﻿using UnityEngine;
using Photon.Pun;

public class GatherResources : MonoBehaviour
{
    public QuickslotInventory quickslotInventory;
    public ItemScriptableObject itemScriptableObject;
    public GenStats genStats;

    [Space]
    [Header("Характеристики")]
    public float woodDamage;
    public float stoonDamage;
    public float enemyDamage;
    public float bildingDamage;
    public float groundDamage;
    public float crit = 77f, critModifer = 1.5f;
    public float weak = 22f, weakModifer = 0.75f;

    [Header("От бедра")]
    public float recoilX = 1f;
    public float recoilY = 2f;
    public float recoilZ = 2f;

    [Header("В прицеле")]
    public float aimRecoilX = 0.5f;
    public float aimRecoilY = 1.5f;
    public float aimRecoilZ = 1.5f;

    [Space]
    [Header("Уровень"), Range(1, 10)]
    public int Lvls;

    public AudioSource audioSource; // источник звука

    public void Start() // можно сделать гены которые меняют скорость добычи и тд
    {
        woodDamage *= genStats.damagePlus;
        stoonDamage *= genStats.damagePlus;

        enemyDamage *= genStats.damagePlus;
        bildingDamage *= genStats.damagePlus;

        groundDamage *= genStats.damagePlus;
    }

    void OnTriggerEnter(Collider hit)
    {
        if (quickslotInventory.attacke == false) return;
 
        if (quickslotInventory.quickSlot[quickslotInventory.currentQuickSlot].durability <= 0 &&
         quickslotInventory.quickSlot[quickslotInventory.currentQuickSlot].item.maximumDurability != 0) return;

        audioSource.volume = Random.Range(0.8f, 1.2f);
        audioSource.pitch = Random.Range(0.8f, 1.2f);

        ResourceHealth resourceHealth = hit.GetComponent<ResourceHealth>();

        if (resourceHealth != null)
        {
            if (resourceHealth.armor == true) return;

            float damage = 0f;

            switch (hit.tag)
            {
                case "Tree":
                    damage = woodDamage;
                    break;
                case "Rock":
                    damage = stoonDamage;
                    break;
                default:
                    damage = groundDamage;
                    break;
            }

            if (damage == 0) return;

            Recoil.instance.RecoilFire(recoilX, recoilY, recoilZ, aimRecoilX, aimRecoilY, aimRecoilZ);
            audioSource.PlayOneShot(resourceHealth.audioList[Random.Range(0, resourceHealth.audioList.Length)]);

            if (Lvls >= resourceHealth.Lvl)
            {
                GlobalPool.instance.ActiveEffect(resourceHealth.effectName, hit.ClosestPoint(transform.position));

                resourceHealth.currentHealth -= damage;

                quickslotInventory.quickSlot[quickslotInventory.currentQuickSlot].SubtractDurabilityPerHit(resourceHealth.Lvl);

                int scoreAdd = Random.Range(1, resourceHealth.Lvl);
                ScoreManager.instance.ScoreAdd(scoreAdd);

                if (resourceHealth.currentHealth <= 0)
                {
                    InventoryManager.instance.AddItem(null, resourceHealth.resourceType, 10, resourceHealth.resourceType.maximumDurability, 0f);
                    return;
                }

                if (Lvls == resourceHealth.Lvl) 
                {
                    InventoryManager.instance.AddItem(null, resourceHealth.resourceType, 1, resourceHealth.resourceType.maximumDurability, 0f);
                }
                else
                {
                    int getRes = Lvls - resourceHealth.Lvl;

                    if (getRes <= 1) getRes = 2;

                    InventoryManager.instance.AddItem(null, resourceHealth.resourceType, getRes, resourceHealth.resourceType.maximumDurability, 0f);
                }
            }
        }
        else
        {
            MobStats mobHealth = hit.GetComponent<MobStats>();

            if (mobHealth != null && !mobHealth.armor)
            {
                GlobalPool.instance.ActiveEffect(mobHealth.mobScriptableObject.effectName, hit.ClosestPoint(transform.position));
                
                float realDamage = enemyDamage;
                float realCrit = critModifer * genStats.critPlus;

                int random = Random.Range(0, 100);

                if (random >= crit) realDamage *= realCrit;
                else if (random <= weak) realDamage *= weakModifer;

                mobHealth.TakeDamage(realDamage, itemScriptableObject.equipEffect);

                int durability = Random.Range(1, 3);
                quickslotInventory.quickSlot[quickslotInventory.currentQuickSlot].SubtractDurabilityPerHit(durability);

                Recoil.instance.RecoilFire(recoilX, recoilY, recoilZ, aimRecoilX, aimRecoilY, aimRecoilZ);
                audioSource.PlayOneShot(mobHealth.mobScriptableObject.damageAudio[Random.Range(0, mobHealth.mobScriptableObject.damageAudio.Length)]);

                int scoreAdd = Random.Range(1, 10);
                ScoreManager.instance.ScoreAdd(scoreAdd);
            }
            else
            {
                BuildingHealth buildingHealth = hit.GetComponent<BuildingHealth>();

                if (buildingHealth != null)
                {
                    GlobalPool.instance.ActiveEffect(buildingHealth.effectName, hit.ClosestPoint(transform.position));

                    buildingHealth.health -= bildingDamage;
                    
                    int durability = Random.Range(1, 5);
                    quickslotInventory.quickSlot[quickslotInventory.currentQuickSlot].SubtractDurabilityPerHit(durability);

                    Recoil.instance.RecoilFire(recoilX, recoilY, recoilZ, aimRecoilX, aimRecoilY, aimRecoilZ);
                    audioSource.PlayOneShot(buildingHealth.audioList[Random.Range(0, buildingHealth.audioList.Length)]);
                }
            }
        }
    }
}