using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Photon.Pun;
using Photon.Chat;
using ExitGames.Client.Photon;
using System.Collections.Generic;

public class PhotonChatManager : MonoBehaviour, IChatClientListener // статусы 2 в сети, 3 печатает, 4 в лобби, 5 создал лобби, 6 играет в лобби, 7 не в сети
{
    [Space]
    [Header("Основное")]
    public DataSaveLoad dataSaveLoad;
    public ChatClient chatClient;

    private string userName;

    [Space]
    [Header("Чат")]
    [SerializeField] TMP_Text chatText;
    [SerializeField] TMP_InputField textMessage;
    [SerializeField] TMP_InputField textUserName;
    [SerializeField] TMP_InputField textFriendsName;

    [Space]
    [SerializeField] Button sendButton;

    void Start()
    {
        sendButton.interactable = false;
        userName = PhotonNetwork.NickName;

        chatClient = new ChatClient(this);
        chatClient.Connect(PhotonNetwork.PhotonServerSettings.AppSettings.AppIdChat, PhotonNetwork.AppVersion, new AuthenticationValues(userName));

        InvokeRepeating(nameof(UpdateChat), 1f, 1f);
    }

    void UpdateChat()
    {
        chatClient.Service();
    }

    public void SendButton()
    {
        if (textMessage.text == "") return;

        if (textUserName.text == "Глобальный чат")
        {
            chatClient.PublishMessage("Глобальный чат", textMessage.text);
        }
        else
        {
            chatClient.SendPrivateMessage(textUserName.text, textMessage.text);
        }
    }

    public void AddFriendsButton()
    {
        string[] friends = textFriendsName.text.Trim().Split(',');
        chatClient.AddFriends(friends);

        dataSaveLoad.data.friends = textFriendsName.text;
    }

    public void DebugReturn(DebugLevel level, string message)
    {
        Debug.Log($"{level} , {message}");
    }

    public void OnChatStateChange(ChatState state)
    {
        Debug.Log(state);
    }

    public void OnConnected()
    {
        chatText.text += "\n Вы подключились к чату, подождите...";
        chatClient.Subscribe(new string[] {"Глобальный чат"}); // можно указать все чаты

        textFriendsName.text = dataSaveLoad.data.friends;
        AddFriendsButton();

        chatClient.SetOnlineStatus(2, "В сети");
    }

    public void OnDisconnected()
    {
        chatClient.SetOnlineStatus(7, "Не в сети");

        chatClient.Unsubscribe(new string[] {"Глобальный чат"}); // можно указать все чаты
        chatText.text += $"\n Потеряно соединение...";

        sendButton.interactable = false;

        CancelInvoke();
        Start();
    }

    public void OnGetMessages(string channelName, string[] senders, object[] messages)
    {
        for (int i = 0; i < senders.Length; i++)
        {
            chatText.text += $"\n [{channelName}], {senders[i]}: {messages[i]}";
        }
    }

    public void OnPrivateMessage(string sender, object message, string channelName)
    {
        chatText.text += $"\n [Приватный чат] {sender}: {message}";
    }

    public void OnStatusUpdate(string user, int status, bool gotMessage, object message)
    {
        chatText.text += $"\n {user} {message} ({status})";
    }

    public void OnSubscribed(string[] channels, bool[] results)
    {
        sendButton.interactable = true;

        for (int i = 0; i < channels.Length; i++)
        {
            chatText.text += $"\n Вы подключены к {channels[i]}";
        }
    }

    public void OnUnsubscribed(string[] channels)
    {
        for (int i = 0; i < channels.Length; i++)
        {
            chatText.text += $"\n Вы отключены от {channels[i]}";
        }
    }

    public void OnUserSubscribed(string channel, string user)
    {
        chatText.text += $"\n {user} подключился к {channel}";
    }

    public void OnUserUnsubscribed(string channel, string user)
    {
        chatText.text += $"\n {user} отключился от {channel}";
    }
}
