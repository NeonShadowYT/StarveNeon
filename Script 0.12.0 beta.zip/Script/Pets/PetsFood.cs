using UnityEngine;

public class PetsFood : MonoBehaviour
{
    public PetsFoodType foodPets = PetsFoodType.Vegetables;
    public GameObject destroyObj;
}
