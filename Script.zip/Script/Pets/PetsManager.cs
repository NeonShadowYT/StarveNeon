using System.Collections.Generic;
using UnityEngine;

public class PetsManager : MonoBehaviour
{
    public static PetsManager instance;

    public AllPets currentPets;

    public Animator anim;
    public CapsuleCollider mCollider;

    private Vector3 startColliderCetner;
    private float startColliderRadius;
    private float startColliderHeight;

    [Space]
    [Header("Все петы")]
    public List<AllPets> allPets;

    private void Awake() => instance = this;

    public void Start()
    {
        currentPets = null;
        
        startColliderCetner = mCollider.center;
        startColliderRadius = mCollider.radius;
        startColliderHeight = mCollider.height;
    }

    public void EquipPets(ItemScriptableObject petsItem)
    {
        anim.SetBool("Mit", false);

        for (int i = 0; i < allPets.Count; i++)
        {
            if (allPets[i].petsItem == petsItem)
            {
                currentPets = allPets[i];

                mCollider.center = currentPets.colliderModiferCetner;
                mCollider.radius = currentPets.colliderModiferRadius;
                mCollider.height = currentPets.colliderModiferHeight;

                currentPets.obj.SetActive(true);

                if (currentPets.petsAnim == PetsAnim.Mit)
                {
                    anim.SetBool("Mit", true);
                }
            }
            else
            {
                allPets[i].obj.SetActive(false);
            }
        }
    }
    public void RemovePets()
    {
        anim.SetBool("Mit", false);

        mCollider.center = startColliderCetner;
        mCollider.radius = startColliderRadius;
        mCollider.height = startColliderHeight;

        for (int i = 0; i < allPets.Count; i++)
        {
            allPets[i].obj.SetActive(false);
        }

        currentPets = null;
    }
}
public enum PetsAnim { Mit }

[System.Serializable]
public class AllPets
{
    [Space]
    [Header("Пет")]
    public ItemScriptableObject petsItem;
    public PetsAnim petsAnim;

    [Space]
    public float walkSpeed;
    public float runSpeed;

    public Vector3 colliderModiferCetner;
    public float colliderModiferRadius;
    public float colliderModiferHeight;

    [Space]
    public GameObject obj;
}