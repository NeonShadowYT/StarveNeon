using UnityEngine;

public class DetailsModel : MonoBehaviour
{
    public MeshFilter meshFilter;
    public MeshRenderer meshRenderer;

    [Space]
    public Mesh meshStandart;
    public Mesh meshDetails;
}