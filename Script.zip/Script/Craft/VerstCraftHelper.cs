using UnityEngine;

public class VerstCraftHelper : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Скрипты")]
    public VerstAnLoker currentVerstAnLoker;

    [Space]
    [Header("Крафт")]
    public CraftScriptableObject craftAnLock;

    [Space]
    [Header("Требуется")]
    public int anlockScore;

    private int _currentVerstAnLock;
    public int currentVerstAnLock
    {
        get { return _currentVerstAnLock; }
        set
        {
            _currentVerstAnLock = value;
            
            if (_currentVerstAnLock == 1) currentVerstAnLoker.CurrentButtonAnLock.interactable = false;
        }
    }

    public void VerstEndFunc() => VerstacManager.instance.AnLock(anlockScore, craftAnLock);
}
