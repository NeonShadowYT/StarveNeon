﻿using System.Collections;
using UnityEngine;

public enum BuildingType{ Foundation, Edge, Wall, Mebel }
public class BuildingSystem : MonoBehaviour
{
    public InventoryManager inventoryManager;
    public CraftManager craftManager;
    public CraftQueueManager craftQueueManager;
    
    [Space, Header("Рейкаст настройки")] 
    [SerializeField] private Camera _mainCamera;
    [SerializeField] private float _reachDistance = 2f;

    private Transform _blockConnection;
    private string _connectionType = "";

    [HideInInspector] public Building _buildingBlockOnScene;
    [HideInInspector] public CraftScriptableObject currentBuildingBlock;

    private void OnEnable()
    {
        if (craftManager == null) return;

        StartCoroutine(BuildUpdate());
    }

    private IEnumerator BuildUpdate()
    {
        while (true)
        {
            if (Input.GetKey(KeyCode.Mouse1))
            {
                ChangeBuildingBlock();
            }

            if (_buildingBlockOnScene != null) 
            {
                if (inventoryManager.isOpened == true)
                {
                    Destroy(_buildingBlockOnScene.gameObject);
                }
                else
                {
                    Ray ray = _mainCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
                    RaycastHit hit;

                    if (Physics.Raycast(ray, out hit, _reachDistance, LayerMask.GetMask("Terrain", _connectionType)))
                    {
                        _buildingBlockOnScene.gameObject.SetActive(true);

                        Transform buildingBlockTransform = _buildingBlockOnScene.transform;
                        _buildingBlockOnScene.CheckColliders();

                        if (LayerMask.LayerToName(hit.collider.gameObject.layer) == _connectionType)
                        {
                            var blockConnection = hit.collider.transform;
                            _blockConnection = blockConnection;

                            buildingBlockTransform.position = blockConnection.position;
                            buildingBlockTransform.rotation = blockConnection.rotation;

                            if (_blockConnection.parent.GetComponentInParent<HouseManager>() != null)
                            {
                                RemoveHouseBlocksFromCollidersList();
                            }
                            else 
                            {
                                RemoveFirstBlockFromCollidersList();
                            }
                        }
                        else
                        {
                            _blockConnection = null;
                            buildingBlockTransform.position = hit.point;
                            buildingBlockTransform.rotation = Quaternion.Euler(buildingBlockTransform.rotation.eulerAngles.x, _mainCamera.transform.rotation.eulerAngles.y, buildingBlockTransform.rotation.eulerAngles.z);
                        }
                    }
                    else 
                    {
                        _buildingBlockOnScene.gameObject.SetActive(false);
                    }

                    if (Input.GetKey(KeyCode.Mouse0))
                    {
                        if (CanPlace() && _buildingBlockOnScene.gameObject.activeInHierarchy)
                        {
                            PlaceBlock();
                        }
                    }
                }
            }

            yield return null;
        }
    }

    public void RemoveResource()
    {
        foreach (CraftResource craftResource in craftQueueManager.currentCraftItem.craftResources)
        {
            int amountToRemove = craftResource.craftObjectAmount;

            foreach (InventorySlot slot in inventoryManager.slots)
            {
                if (amountToRemove <= 0) continue;

                if(slot.item == craftResource.craftObject)
                {
                    if(amountToRemove > slot.amount)
                    {
                        amountToRemove -= slot.amount;
                        slot.dragAndDropItem.NullifySlotData();
                    }
                    else
                    {
                        slot.amount -= amountToRemove;
                        amountToRemove = 0;

                        if(slot.amount <= 0) 
                        {
                            slot.dragAndDropItem.NullifySlotData();
                        }
                    }
                }
            }
        }
    }

    public void CreateCraftBlock()
    {
        if (craftQueueManager.currentCraftItem.craftType == CraftType.Buildings)
        {
            CreateNewBlock(craftQueueManager.currentCraftItem);
        }
        else
        {
            craftManager.ChangCategoryList(CraftType.Common);
            if (_buildingBlockOnScene != null) Destroy(_buildingBlockOnScene.gameObject);
        }
    }

    private void RemoveFirstBlockFromCollidersList()
    {
        if (_buildingBlockOnScene.detectedColliders.Contains(_blockConnection.parent.GetComponent<Collider>()))
        {
            _buildingBlockOnScene.detectedColliders.Remove(_blockConnection.parent.GetComponent<Collider>());
        }
    }

    private void RemoveHouseBlocksFromCollidersList()
    {
        foreach (BuildingBlock buildingBlock in _blockConnection.parent.GetComponentInParent<HouseManager>().buildingBlocks)
        {
            if (_buildingBlockOnScene != null)
            {
                if (_buildingBlockOnScene.detectedColliders.Contains(buildingBlock.GetComponent<Collider>()))
                {
                    _buildingBlockOnScene.detectedColliders.Remove(buildingBlock.GetComponent<Collider>());
                }
            }
        }
    }

    private void ChangeBuildingBlock()
    {
        if (_buildingBlockOnScene != null) Destroy(_buildingBlockOnScene.gameObject);
        
        inventoryManager.EditCurcorOn();

        craftManager.craftCategoryDropdown.interactable = false;
        craftManager.ChangCategoryList(CraftType.Buildings);

        CancelInvoke();
    }

    private void CreateNewBlock(CraftScriptableObject buildingScriptableObject)
    {
        currentBuildingBlock = buildingScriptableObject;
        inventoryManager.EditCurcorOff();

        craftManager.craftCategoryDropdown.interactable = true;
        craftManager.LoadCraftCategory();

        _buildingBlockOnScene = Instantiate(currentBuildingBlock.finalCraft.buildingPrefab).GetComponent<Building>();

        _buildingBlockOnScene.buildingCollider.enabled = false;
        _connectionType = _buildingBlockOnScene.connectionType;
    }

    private void PlaceBlock()
    {
        craftManager.FillItemDetailsHelper();

        if (craftManager.buildingBtn.interactable == true)
        {
            RemoveResource();
        }
        else
        {
            return;
        }

        _buildingBlockOnScene.isPlaced = true;
        _buildingBlockOnScene.TurnOnConnections();  

        _buildingBlockOnScene.ChangeToBlockMaterial();

        if (_blockConnection != null)
        {
            if (_blockConnection.parent.parent == null) // Первая часть
            {
                GameObject house = Instantiate(new GameObject("House"), _buildingBlockOnScene.transform.position, Quaternion.identity);
                house.AddComponent<HouseManager>();
                _blockConnection.parent.SetParent(house.transform);
            }

            _buildingBlockOnScene.transform.position = _blockConnection.position;// Вторая часть
            _buildingBlockOnScene.transform.rotation = _blockConnection.rotation;

            _buildingBlockOnScene.transform.SetParent(_blockConnection.parent.parent);
            Building blockConnection = _blockConnection.parent.GetComponent<Building>();

            if (blockConnection != null)
            {
                switch (_connectionType)// Третья часть
                {
                    case "FoundationConnection":
                        blockConnection.foundationConnections.Remove(_blockConnection.gameObject);
                        break;
                    case "EdgeConnection":
                        blockConnection.edgeConnections.Remove(_blockConnection.gameObject);
                        break;
                    case "WallConnection":
                        blockConnection.wallConnections.Remove(_blockConnection.gameObject);
                        break;
                    case "MebelConnection":
                        blockConnection.mebelConnections.Remove(_blockConnection.gameObject);
                        break;
                }

                blockConnection.deactiveConnections.Add(_blockConnection.gameObject);
                _blockConnection.gameObject.SetActive(false);

                _buildingBlockOnScene.transform.parent.GetComponent<HouseManager>().UpdateBuildingBlocks();
            }
        }

        _buildingBlockOnScene.buildingHealth.enabled = true;
        _buildingBlockOnScene.buildingCollider.enabled = true; 
        _buildingBlockOnScene = null;

        Invoke(nameof(CreateCraftBlock), 1f);
    }

    public bool CanPlace()
    {
        return _buildingBlockOnScene.canPlace;
    }

    private void OnDisable()
    {
        if (craftManager == null) return;

        StopAllCoroutines();

        craftManager.craftCategoryDropdown.interactable = true;
        craftManager.LoadCraftCategory();

        if (_buildingBlockOnScene != null) Destroy(_buildingBlockOnScene.gameObject);
    }
}