using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransition : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public PhotonSetManager photonSetManager;
    
    public string currentSceneName; //нужно для сохранения текущего биома и положения игрока

    public void Start()
    {
        currentSceneName = SceneManager.GetActiveScene().name;
    }

    public void SwitchToScene(string sceneName)
    {
        if (photonSetManager != null)
        {
            if (sceneName != "Menu")
            {
                photonSetManager.MultiSwitchScene(sceneName);
                return;
            }
            else
            {
                photonSetManager.LeaveRoom();
                SceneManager.LoadScene(sceneName);
            }
        }
        else
        {
            SceneManager.LoadScene(sceneName);
        }
    }
}
