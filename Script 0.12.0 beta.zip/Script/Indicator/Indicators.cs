using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;

public class Indicators : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public DataSaveLoad dataSaveLoad;
    
    [Space]
    [Header("Скрипты")]
    public CustomCharacterController customCharacterController;
    public WeatherPlayer weatherPlayer;
    public SceneTransition sceneTransition;
    public BioManager bioManager;
    public Daytime daytime;
    public QuastGame quastGame;

    [Space]
    public GameObject IventObject;
    public TMP_Text IventText;
    public Image IventImage;

    [Space]
    public TMP_Text IventStatsText;
    public Image IventStatsImage;

    public TMP_Text StatsText;
    public Image StatsImage;

    [Space]
    [Header("Эффекты")]
    public IndicatorsEffect healEffect;
    public IndicatorsEffect waterEffect;

    [Space]
    public IndicatorsEffect webEffect;
    public IndicatorsEffect jumpEffect;
    public IndicatorsEffect speedEffect;

    [Space]
    public IndicatorsEffect infectionEffect;
    public IndicatorsEffect poisonEffect;

    [Space]
    public IndicatorsEffect hotEffect;
    public IndicatorsEffect fireEffect;

    [Space]
    public IndicatorsEffect coldEffect;
    public IndicatorsEffect frostEffect;

    [Space]
    public IndicatorsEffect damageEffect;
    public IndicatorsEffect bloodEffect;

    [Space]
    public IndicatorsEffect changBiomEffect;

    [Space]
    [Header("Визуал")]
    public TMP_Text healthText;
    public TMP_Text foodText;
    public TMP_Text waterText;
    public TMP_Text сoldText;

    [Space]
    public Slider healthSlider;
    public Slider foodSlider;
    public Slider waterSlider;
    public Slider coldSlider;

    private float secondsToEmptyFood = 360f, secondsToEmptyWater = 360f, secondsToEmptyHealth = 60f, secondsToEmptyCold = 600f;
    private float saveSecondsToEmptyFood, saveSecondsToEmptyWater, saveSecondsToEmptyHealth, saveSecondsToEmptyCold;

    [HideInInspector]
    public int Armor, Water, Infected, StormArmor;
    private int _ColdArmor;
    public int ColdArmor
    {
        get { return _ColdArmor; }
        set
        {
            _ColdArmor = value;
            weatherPlayer.StartWeather();
            ChangColdTime();
        }
    }
    private int _JumpPower;
    public int JumpPower
    {
        get { return _JumpPower; }
        set
        {
            _JumpPower = value;
            if (_JumpPower == 1) customCharacterController.jumpForce = 7; else customCharacterController.jumpForce = 5;
        }
    }

    [Space]
    public TMP_Text ArmorPointText; 
    public TMP_Text ColdArmorPointText, StormArmorPointText, InfectedPointText, SpeedPointText;

    [Space]
    [Header("Параметры")]
    private int _sleepAIs;
    public int _sleepAI
    {
        get { return _sleepAIs; }
        set
        {
            _sleepAIs = value;

            ChangColdTime();
        }
    }

    [HideInInspector]
    public int complexity;

    [Space]
    [Header("Гены")]
    public int ksenoTypeMetabalizm;
    public int NaturalColdArmor = 0;

    public float RegenPlus = 1f, FoodPlus = 1f, WaterPlus = 1f, ColdPlus = 1f, HealthPlus = 1f, RazbrosPlus = 1f, DamagePlus = 1f, AdColdPlus = 1f, SnowColdPlus = 1f, NightSpeed = 1f, DaySpeed = 1f, NoArmorSpeed = 1f, ArmorSpeed = 1f, MyPlants = 1f, PetsPlus = 1f, CritPlus = 1f, CritDamage = 1f;

    void Start()
    {
        daytime = FindObjectOfType<Daytime>();

        StartIndicators();
        ComplexityEquip();
        GenEquip();
        Metabalizm();

        saveSecondsToEmptyFood = secondsToEmptyFood;
        saveSecondsToEmptyWater = secondsToEmptyWater;
        saveSecondsToEmptyCold = secondsToEmptyCold;
        saveSecondsToEmptyHealth = secondsToEmptyHealth;

        ColdArmor += NaturalColdArmor;

        coldEffect.genModifer *= ColdPlus;
        hotEffect.genModifer *= ColdPlus;
        
        fireEffect.genModifer *= AdColdPlus;
        frostEffect.genModifer *= SnowColdPlus;

        Invoke(nameof(PlayerUIMap), 0.15f);
        InvokeRepeating(nameof(IndicatorsUpdate), 1f, 1f);
    }

    void IndicatorsUpdate()
    {
        foodSlider.value -= 200 / secondsToEmptyFood;
        waterSlider.value -= 200 / secondsToEmptyWater;
        coldSlider.value -= 200 / secondsToEmptyCold;

        if (foodSlider.value == 0) healthSlider.value -= 200 / secondsToEmptyHealth;
        if (waterSlider.value == 0) healthSlider.value -= 200 / secondsToEmptyHealth;
        if (coldSlider.value == 0) healthSlider.value -= 200 / secondsToEmptyHealth;

        RegenereitCheck();
    }

    void Death()
    {
        dataSaveLoad.Death();
        sceneTransition.SwitchToScene("База");
    }

    public void HealthUpdate()
    {
        healthText.text = healthSlider.value.ToString();

        if (healthSlider.value == 0) Death();
    }

    public void FoodUpdate()
    {
        foodText.text = foodSlider.value.ToString();
    }

    public void WaterUpdate()
    {
        waterText.text = waterSlider.value.ToString();
    }

    public void ColdUpdate()
    {
        сoldText.text = coldSlider.value.ToString();
    }

    void ChangColdTime()
    {
        secondsToEmptyFood = saveSecondsToEmptyFood;
        secondsToEmptyWater = saveSecondsToEmptyWater;
        secondsToEmptyCold = saveSecondsToEmptyCold;
        secondsToEmptyHealth = saveSecondsToEmptyHealth;

        if (_sleepAIs == 1)
        {
            switch (_ColdArmor)
            {
                case 0:
                    secondsToEmptyCold *= 0.5f;
                    break;
                case 1:
                    secondsToEmptyCold *= 0.6f;
                    break;
                case 2:
                    secondsToEmptyCold *= 0.7f;
                    break;
                case 3:
                    secondsToEmptyCold *= 0.8f;
                    break;
                case 4:
                    secondsToEmptyCold *= 0.9f;
                    break;
            }

            customCharacterController.walkingSpeed *= NightSpeed;
            customCharacterController.runningSpeed *= NightSpeed;
        }
        else
        {
            switch (_ColdArmor)
            {
                case 1:
                    secondsToEmptyCold *= 1.1f;
                    break;
                case 2:
                    secondsToEmptyCold *= 1.2f;
                    break;
                case 3:
                    secondsToEmptyCold *= 1.3f;
                    break;
                case 4:
                    secondsToEmptyCold *= 1.4f;
                    break;
            }

            customCharacterController.walkingSpeed *= DaySpeed;
            customCharacterController.runningSpeed *= DaySpeed;
        }
    }

    void PlayerUIMap() // для того чтобы дей тайм и рассказчик знали где интерфейс игрока
    {
        if (daytime != null)
        {
            daytime.indicators = this;
            daytime.TexnoSlot = customCharacterController.inventoryManager.verstAddItem.texnoSlot;

            daytime.DayText = IventText;
            daytime.DayTextObject = IventObject;
            daytime.DayImage = IventImage;

            daytime.quastGame = quastGame;

            if (daytime.stolery != null) 
            {
                daytime.stolery.statsImage = IventStatsImage;
                daytime.stolery.statsText = IventStatsText;

                StatsText.text = daytime.stolery.currentStolyres.name;
                StatsImage.sprite = daytime.stolery.currentStolyres.image;
            }
        }
    }

    void Metabalizm()
    {
        EquipMetabalizm();
    }

    void EquipMetabalizm()
    {
        if (ksenoTypeMetabalizm == 0) return;

        if (ksenoTypeMetabalizm > 0)
        {
            ksenoTypeMetabalizm -= 1;
            secondsToEmptyHealth += 5;
            secondsToEmptyFood += 25;
            secondsToEmptyWater += 25;
            secondsToEmptyCold += 50;
        }
        else if (ksenoTypeMetabalizm < 0)
        {
            ksenoTypeMetabalizm += 1;
            secondsToEmptyHealth -= 15;
            secondsToEmptyFood -= 75;
            secondsToEmptyWater -= 75;
            secondsToEmptyCold -= 100;
        }

        if (secondsToEmptyHealth < 15)
        {
            secondsToEmptyHealth = 15;
        }

        if (secondsToEmptyWater < 15)
        {
            secondsToEmptyWater = 15;
        }

        if (secondsToEmptyFood < 15)
        {
            secondsToEmptyFood = 15;
        }
        
        if (secondsToEmptyCold < 15)
        {
            secondsToEmptyCold = 15;
        }

        Metabalizm();
    }


    public void RegenereitCheck()
    {
        if (foodSlider.value > foodSlider.maxValue * 0.75f && waterSlider.value > waterSlider.maxValue * 0.75f && coldSlider.value > coldSlider.maxValue * 0.75f)
        {
            if (healthSlider.value < 200)
            {
                healEffect.gameObject.SetActive(true);
            }
            else if (healthSlider.value >= 200)
            {
                healEffect.gameObject.SetActive(false);
            }
        }
        else
        {
            healEffect.gameObject.SetActive(false);
        }
    }

    public void ChangeHealthAmount(float changeValue)
    {
        healthSlider.value += changeValue * RegenPlus;
    }
    public void ChangeFoodAmount(float changeValue)
    {
        foodSlider.value += changeValue * FoodPlus;
    }
    public void ChangeWaterAmount(float changeValue)
    {
        waterSlider.value += changeValue * WaterPlus;
    }
    public void ChangeColdAmount(float changeValue)
    {
        coldSlider.value += changeValue * ColdPlus;
    }

    public void UpdateText()
    {
        ArmorPointText.text = Armor.ToString();
        ColdArmorPointText.text = ColdArmor.ToString();
        StormArmorPointText.text = StormArmor.ToString();
        InfectedPointText.text = Infected.ToString();
        SpeedPointText.text = customCharacterController.walkingSpeed.ToString();
    }

    public void ComplexityEquip()
    {
        complexity = dataSaveLoad.data.complexity;

        switch (complexity)
        {
            case 0:
                secondsToEmptyFood = 400f;
                secondsToEmptyWater = 380f;
                secondsToEmptyHealth = 80f;
                secondsToEmptyCold = 600f;
                break;
            case 1:
                secondsToEmptyFood = 360f;
                secondsToEmptyWater = 340f;
                secondsToEmptyHealth = 60f;
                secondsToEmptyCold = 600f;
                break;
            case 2:
                secondsToEmptyFood = 320f;
                secondsToEmptyWater = 300f;
                secondsToEmptyHealth = 40f;
                secondsToEmptyCold = 560f;
                break;
            case 3:
                secondsToEmptyFood = 280f;
                secondsToEmptyWater = 260f;
                secondsToEmptyHealth = 30f;
                secondsToEmptyCold = 520f;
                break;
        }
    }

    public void StartIndicators()
    {
        customCharacterController.jumpForce = 5f;
        customCharacterController.walkingSpeed = 7f;
        customCharacterController.currentSpeed = 0f;
        customCharacterController.runningSpeed = 11f;

        healthSlider.value = healthSlider.maxValue;
        foodSlider.value = foodSlider.maxValue;
        waterSlider.value = waterSlider.maxValue;
        coldSlider.value = coldSlider.maxValue;
    }

    public void GenEquip()
    {
        foreach (GenScriptableObject genScriptableObject in bioManager.genAcceptList)
        {
            ksenoTypeMetabalizm += genScriptableObject.Metabalizm;

            NaturalColdArmor += genScriptableObject.NaturalColdArmor;
            webEffect.genModifer *= genScriptableObject.TimeWeb;

            RegenPlus *= genScriptableObject.RegenPlus;
            HealthPlus *= genScriptableObject.HealthPlus;

            FoodPlus *= genScriptableObject.FoodPlus;
            WaterPlus *= genScriptableObject.WaterPlus;
            ColdPlus *= genScriptableObject.ColdPlus;

            AdColdPlus *= genScriptableObject.AdColdPlus;
            SnowColdPlus *= genScriptableObject.SnowColdPlus;

            NightSpeed *= genScriptableObject.NightSpeed;
            DaySpeed *= genScriptableObject.DaySpeed;

            NoArmorSpeed *= genScriptableObject.NoArmorSpeed;
            ArmorSpeed *= genScriptableObject.ArmorSpeed;

            RazbrosPlus *= genScriptableObject.RazbrosPlus;
            MyPlants *= genScriptableObject.MyPlants;
            PetsPlus *= genScriptableObject.PetsPlus;

            DamagePlus *= genScriptableObject.DamagePlus;
            bloodEffect.healthModifer *= genScriptableObject.DamageBlood;

            CritDamage *= genScriptableObject.CritDamage;
            CritPlus *= genScriptableObject.CritPlus;
        }
    }
}