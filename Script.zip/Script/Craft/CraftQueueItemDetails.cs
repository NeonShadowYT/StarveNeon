﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CraftQueueItemDetails : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Информация")]
    public Image itemImage;
    public Image progressImage;
    public TMP_Text amountText;
    public TMP_Text timeText;

    [Space]
    [Header("Информация о текущем крафте")]
    public CraftScriptableObject currentCraftItem;

    private int _craftTime;
    public int craftTime
    {
        get { return _craftTime; }
        set
        {
            _craftTime = value;

            if (craftTime <= 0)
            {
                InventoryManager.instance.AddItem(null, currentCraftItem.finalCraft, 1, currentCraftItem.finalCraft.maximumDurability, 0f);
            
                craftAmount--;
                craftTime = initialCraftTime;

                if (craftAmount <= 0)
                {
                    for (int i = 0; i < CraftQueueManager.instance.craftQueueItemDetails.Count; i++)
                    {
                        if (CraftQueueManager.instance.craftQueueItemDetails[i].craftAmount >= 1)
                        {
                            CraftQueueManager.instance.craftQueueItemDetails[i].gameObject.SetActive(true);
                            break;
                        }
                    }

                    currentCraftItem = null;
                    gameObject.SetActive(false);
                }
            }
        }
    }

    public int craftAmount;
    private int initialCraftTime;

    private void OnEnable()
    {
        initialCraftTime = craftTime;
        craftTime++;
    }

    public void RemoveFromQueue()
    {
        foreach (CraftResource resource in currentCraftItem.craftResources)
        {
            InventoryManager.instance.AddItem(null, resource.craftObject, resource.craftObjectAmount * craftAmount, resource.craftObject.maximumDurability, 0f);
        }

        InventoryManager.instance.craftView.SetActive(false);
        craftAmount = 0;

        for (int i = 0; i < CraftQueueManager.instance.craftQueueItemDetails.Count; i++)
        {
            if (CraftQueueManager.instance.craftQueueItemDetails[i].craftAmount >= 1)
            {
                CraftQueueManager.instance.craftQueueItemDetails[i].gameObject.SetActive(true);
                break;
            }
        }

        currentCraftItem = null;
        gameObject.SetActive(false);
    }

    public void UpdateTime()
    {
        amountText.text = "X" + craftAmount.ToString();
        craftTime--;

        int minutes = Mathf.FloorToInt(craftTime / 60);
        int seconds = craftTime - minutes * 60;

        progressImage.fillAmount = 1 - ((float)craftTime / initialCraftTime);
        timeText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }
}
