using UnityEngine;

public enum MobType { Ground, Water, Air }
public enum MobInteraction { Predator, Common, Herbivore }
public enum MobPerc { Run, Common, Armor, Shoter }

[HelpURL("https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg")]
[CreateAssetMenu(fileName = "Mob", menuName = "Neon Imperium/Mob/New Mob")]
public class MobScriptableObject : ScriptableObject
{
    [Space]
    [Header("Характеристики")]
    [Range(1, 10000), Tooltip("Здоровье")]
    public int Health = 100;

    [Range(0, 100), Tooltip("Урон")]
    public int Damage = 20;
    public EquipEffect damageEffect;

    [Space]
    [Header("Шансы")]
    [Range(0, 100), Tooltip("Шанс эффекта")]
    public int chanceEffect = 50;

    [Range(0f, 100f), Tooltip("Крита")]
    public float crit = 77f, critModifer = 1.5f;

    [Range(0f, 100f), Tooltip("Слабость")]
    public float weak = 22f, weakModifer = 0.75f;

    [Space]
    [Range(0, 15), Tooltip("Скорость перемещения")]
    public float movementSpeed = 7f;

    [Space]
    [Range(60, 240), Tooltip("Скорость поворота")]
    public float rotationSpeed = 120f;

    [Range(0, 30), Tooltip("Время между перемещением")]
    public float changePositionTime = 5f;

    [Range(0, 30), Tooltip("Дистанция ходьбы")]
    public float moveDistance = 15f;

    [Range(0, 10), Tooltip("Время до  обновления перка")]
    public float percTime = 3.5f;

    [Range(1, 15), Tooltip("Время между атаками")]
    public float attackeTime = 5f;

    [Range(1, 30), Tooltip("Время между выстрелами")]
    public float shootTime = 10f;

    [Tooltip("Время возраждения")]
    public float respawnTime = 300f;

    [Space]
    [Header("Тип")]
    public MobType MobType = MobType.Ground;
    public MobInteraction MobInteraction = MobInteraction.Common;
    public MobPerc MobPerc = MobPerc.Common;

    [Space]
    [Header("Лут"), Tooltip("Лут при смерти")]
    public LutList[] LutList;

    [Space]
    [Header("Звук обнаружения")] public AudioClip[] rewAudio;
    [Header("Звук смерти")] public AudioClip[] deathAudio;
    [Header("Звук атаки")] public AudioClip[] attackeAudio;
    [Header("Звук урова")] public AudioClip[] damageAudio;

    [Space]
    [Header("Эффект"), Tooltip("Название эффекта получения урона")]
    public string effectName = "Blood";

    [Space]
    [Header("Снаряд"), Tooltip("Название снаряда для выстрела")]
    public string сartridgeName = "Пуля";
}

[System.Serializable]
public class LutList
{
    [Space]
    [Header("Инфа о луте")]
    public ItemScriptableObject Item;
    public int Amount = 1;
}