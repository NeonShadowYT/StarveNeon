﻿using UnityEngine;
public class ResourceHealth : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    public float startHealth = 100;
    public bool armor;
    
    private float _currentHealth;
    
    [HideInInspector] 
    public float currentHealth
    {
        get { return _currentHealth; }
        set
        {
            _currentHealth = value;

            if(_currentHealth <= 0)
            {
                if (anim != null) 
                {
                    anim.SetBool("Death", true); 
                }
                else
                {
                    DestroyResours();
                }
            }
            else if(_currentHealth > startHealth)
            {
                currentHealth = startHealth;
            }
        }
    }

    [Space]
    public ItemScriptableObject resourceType;
    public GameObject hitFix;

    [Space, Range(1, 10)]
    public int Lvl;

    [Space]
    [Header("Время до восстановления")]
    public int timeForRegen = 60;

    [Space]
    [Header("Анимация заканчивания")]
    public Animator anim;

    [Space]
    [Header("Целый и сломанный")]
    public GameObject NormalGO;
    public GameObject DestroyGO;

    [Space]
    public bool offDestroy;

    [Space]
    [Header("Звуки")]
    public AudioClip[] audioList;

    void Start()
    {
        if (anim == null) anim = GetComponent<Animator>();

        Regen();
    }

    public void Regen()
    {
        currentHealth = startHealth;
        armor = false;

        if (offDestroy == false)
        {
            NormalGO.SetActive(true);
            DestroyGO.SetActive(false);
        }

        CancelInvoke(nameof(Regen));
    }

    public void DestroyResours()
    {
        armor = true;

        if (offDestroy == false)
        {
            NormalGO.SetActive(false);
            DestroyGO.SetActive(true);
        }

        InvokeRepeating(nameof(Regen), timeForRegen, timeForRegen);
    }
}
