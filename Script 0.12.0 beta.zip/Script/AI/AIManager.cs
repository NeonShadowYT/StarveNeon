using UnityEngine;
using UnityEngine.AI;
using System.Collections;
using System.Collections.Generic;

[HelpURL("https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg")]
public class AIManager : MonoBehaviour
{
    public MobScriptableObject mobScriptableObject;
    public List<Transform> target;

    [Space]
    [Header("Поведение")]
    public bool AgreAI;
    public bool WolfAI;
    public bool DamageForAgreAI;
    public bool PanicAI;
    public bool ShotAI;
    public bool FlyingAI;
    public bool CompanionAI;
    public bool FractionAI;
    public bool NightAI;
    public bool SleepAI;

    [Space]
    [Header("Боссы")]
    public bool Sandworm;
    public bool Dezmo;

    [Space]
    [Header("Важное")]
    [HideInInspector] public GlobalInvoker globalInvoker;
    [HideInInspector] public NavMeshAgent navMeshAgent;
    [HideInInspector] public AIManager mobInteraction;
    [HideInInspector] public FractionNPS fractionNPS;
    [HideInInspector] public Collider mobCollider;
    [HideInInspector] public Transform mTransform;
    [HideInInspector] public AudioSource audios;
    [HideInInspector] public MobStats mobStats;
    [HideInInspector] public Animator animator;
    [HideInInspector] public Daytime daytime;

    [Space]
    public AIOptimizer optimizer;
    public ViewDistance view;

    [Space]
    [Header("Дополнительное")]
    public List<Transform> patrolPoints;
    [HideInInspector] public float nextAttackTime;
    [HideInInspector] public float nextShotTime;
    [HideInInspector] public Vector3 circlePoint;

    [Space]
    [Header("Прокачка")]
    public List<MobUpdate> mobUpdate;
    public GameObject[] standartObj;

    [Space]
    [Header("Особое")]
    public GameObject BossEffect;
    public GameObject BossObject;
    public GameObject PetsPrefab;

    [Space]
    [HideInInspector] public bool death;
    [HideInInspector] public bool perc = true;
    [HideInInspector] public bool oncePets;
    [HideInInspector] public bool viewColdawn;

    public MobPerc mPerc = MobPerc.Common;

    public void Start()
    {
        globalInvoker = FindObjectOfType<GlobalInvoker>();
        navMeshAgent = GetComponent<NavMeshAgent>();
        fractionNPS = GetComponent<FractionNPS>();
        mobCollider = GetComponent<Collider>();
        daytime = FindObjectOfType<Daytime>();
        audios = GetComponent<AudioSource>();
        mobStats = GetComponent<MobStats>();
        animator = GetComponent<Animator>();

        mTransform = transform;
        patrolPoints.Add(mTransform);

        for (int i = 0; i < mobUpdate.Count; i++)
        {
            for (int ii = 0; ii < mobUpdate[i].updateObj.Length; ii++)
            {
                standartObj[ii].SetActive(true);
                mobUpdate[i].updateObj[ii].SetActive(false);
            }
        }
        
        navMeshAgent.speed = mobScriptableObject.movementSpeed;
        navMeshAgent.angularSpeed = mobScriptableObject.rotationSpeed;
        mPerc = mobScriptableObject.MobPerc;

        mobStats.Startap();
        
        if (fractionNPS != null && fractionNPS.myFraction == null) fractionNPS.Startnps();
        if (optimizer != null) optimizer.Startap();
        if (view != null) view.Startap();
    }

    //погружение
    public void MobRewEnd()
    {   
        AIWalk();

        viewColdawn = true;
        animator.SetBool("ViewTarget", false);

        InvokeRepeating(nameof(ViewColdawn), 60f, 0f);
    }
    public void ViewColdawn()
    {
        viewColdawn = false;
        
        CancelInvoke(nameof(ViewColdawn));
    }

    public void DeathAudio()
    {
        AudioRandomize();
        audios.PlayOneShot(mobScriptableObject.deathAudio[Random.Range(0, mobScriptableObject.deathAudio.Length)]);
    }
    public void RewAudio()
    {
        AudioRandomize();
        audios.PlayOneShot(mobScriptableObject.rewAudio[Random.Range(0, mobScriptableObject.rewAudio.Length)]);
    }
    public void AttackeAudio()
    {
        AudioRandomize();
        audios.PlayOneShot(mobScriptableObject.attackeAudio[Random.Range(0, mobScriptableObject.attackeAudio.Length)]);
    }
    void AudioRandomize()
    {
        audios.volume = Random.Range(0.8f, 1.2f);
        audios.pitch = Random.Range(0.8f, 1.2f);
    }

    public void RandomAnim()
    {
        animator.SetInteger("atackeID", Random.Range(0, 4));
    }

    public void AnimUpdate()
    {
        animator.SetFloat("Speed", navMeshAgent.velocity.magnitude / mobScriptableObject.movementSpeed);
    }

    public void PetsMe()
    {
        if (oncePets == false)
        {
            MyPets myPets = Instantiate(PetsPrefab, mTransform.position, Quaternion.identity).GetComponent<MyPets>(); //������� ����
            myPets.customCharacterController = globalInvoker.customCharacterController;

            oncePets = true;

            Destroy(gameObject);
        }
    }

    //взаимодействия
    public void ViewTarget()
    {
        if (death || target.Count < 1)
        {
            globalInvoker.aiViewTarget.Remove(this);
            return;
        }

        if (WolfAI && Time.time < nextAttackTime)
        {
            if (circlePoint == Vector3.zero || (circlePoint - mTransform.position).sqrMagnitude < 0.5f)
            {
                // Находим точку по окружности вокруг игрока
                circlePoint = target[0].position + Quaternion.Euler(0, Random.Range(0, 360), 0) * (Vector3.forward * 15f);
                navMeshAgent.SetDestination(circlePoint);
            }

            return;
        }

        if (Dezmo && globalInvoker.customCharacterController.currentSpeed <= 7 && mobStats.health >= mobStats.complexityHealth) 
        {
            return;
        }

        if (FractionAI)
        {
            if (AgreAI)
            {
                if (ShotAI) //стрельба
                {
                    Shoots();

                    if ((mTransform.position - target[0].position).sqrMagnitude < 15f * 15f)
                    {
                        navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
                    }
                }
                else
                {
                    if (globalInvoker.customCharacterController.indicators.waterEffect.timeEffect >= 1)
                    {
                        navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
                    }
                    else
                    {
                        navMeshAgent.SetDestination(target[0].position); // идём к цели
                        circlePoint = Vector3.zero;
                    }
                }
            }
            else if (PanicAI == true)
            {
                navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
            }
        }
        else
        {
            if (AgreAI == true)
            {
                if (mobScriptableObject.MobType == MobType.Ground || mobScriptableObject.MobType == MobType.Air)
                {
                    if (globalInvoker.customCharacterController.indicators.waterEffect.timeEffect >= 1)
                    {
                        navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
                    }
                    else
                    {
                        navMeshAgent.SetDestination(target[0].position); // идём к цели
                        circlePoint = Vector3.zero;
                    }
                }
                else
                {
                    if (globalInvoker.customCharacterController.indicators.waterEffect.timeEffect >= 1)
                    {
                        navMeshAgent.SetDestination(target[0].position); // идём к цели
                        circlePoint = Vector3.zero;
                    }
                    else
                    {
                        navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
                        //navMeshAgent.SetDestination(target[0].position + (mTransform.position - target[0].position) * 15f); // Более оптимизированный вариант но плохо убегает
                    }
                }
            }
            else if (PanicAI == true)
            {
                navMeshAgent.SetDestination(Vector3.MoveTowards(mTransform.position, target[0].position, -mobScriptableObject.movementSpeed * 2f)); // Отходит от игрока
            }

            if (ShotAI == true) //стрельба
            {
                Shoots();
            }
        }
    }

    //основное
    public void MoveAnimal()
    {
        if (target.Count >= 1 && (PanicAI == true || AgreAI == true || ShotAI == true))
        {
            animator.SetBool("Sleep", false);
            return;
        }

        if (globalInvoker.sleepAI == true)
        {
            if (SleepAI == true)
            {
                animator.SetBool("Sleep", true);
            }
        }

        animator.SetBool("Sleep", false);
        int random = Random.Range(0, 5);

        if (random == 2)
        {
            mobInteraction = globalInvoker.aiMoveAnimal[Random.Range(0, globalInvoker.aiMoveAnimal.Count)];

            if (mobInteraction != this && mobInteraction.target.Count <= 0 && ((mobInteraction.AgreAI == true && PanicAI == true) || (mobInteraction.PanicAI == true && AgreAI == true)))
            {
                target.Add(mobInteraction.mTransform);
                mobInteraction.target.Add(mTransform);

                globalInvoker.aiViewTarget.Add(this);
                globalInvoker.aiViewTarget.Add(mobInteraction);
                return;
            }
        }

        navMeshAgent.SetDestination(RandomNavSphere(Random.Range(mobScriptableObject.moveDistance * 0.75f, mobScriptableObject.moveDistance * 1.25f)));
    }
    public void AIWalk()
    {
        float speed = mobScriptableObject.movementSpeed;

        if (FractionAI == true && AgreAI == false) 
        {
            navMeshAgent.speed = speed;
            return;
        }

        int random = Random.Range(0, 4);

        if (mPerc != MobPerc.Common && perc == true && random >= 2)
        {
            if (mPerc == MobPerc.Run)
            {
                speed += speed;
                navMeshAgent.speed = speed;
            }
            else if (mPerc == MobPerc.Armor) // ��� ����������
            {
                animator.SetInteger("AtackeType", 1);
                mobStats.armor = true;

                AIStop();
            }
            else if (mPerc == MobPerc.Shoter)
            {
                Shooter();
                Shooter();

                navMeshAgent.speed = speed;
            }

            Invoke("EndPerc", mobScriptableObject.percTime);
        }
        else
        {
            navMeshAgent.speed = speed;
            return;
        }
    }

    public void AIStop()
    {
        navMeshAgent.speed = 0;
    }

    //перк
    public void EndPerc()
    {
        mobStats.armor = false;
        animator.SetInteger("AtackeType", 0);

        perc = false;
        Invoke("TimePerc", 10f);

        AIWalk();
    }

    void TimePerc()
    {
        perc = true;
    }

    Vector3 RandomNavSphere(float distance)
    {
        Vector3 randomDirection = Random.insideUnitSphere * distance;
        randomDirection += patrolPoints[Random.Range(0, patrolPoints.Count)].position;

        NavMeshHit navHit;
        NavMesh.SamplePosition(randomDirection, out navHit, distance, -1);

        return navHit.position;
    }

    //стрельба
    public void Shoots()
    {
        if (Time.time > nextShotTime)
        {
            Shooter();
        }
    }
    void Shooter()
    {
        Cartridge сartridge = Instantiate(mobScriptableObject.сartridge, mTransform.position + new Vector3(0f, 0.5f, 0f), Quaternion.identity).GetComponent<Cartridge>(); //������� ����

        Vector3 direction = new Vector3(Random.Range(-2, 2), Random.Range(-3, 3), Random.Range(-3, 3));
        direction.Normalize();

        Vector3 targetV = target[0].position + new Vector3(0f, 0.5f, 0f);

        сartridge.targetPosition = (targetV += direction);
        nextShotTime = Time.time + Random.Range(mobScriptableObject.shootTime * 0.75f, mobScriptableObject.shootTime * 1.25f); // ����� �����
    }

    //улучшения
    public void UpdateLvlMob()
    {
        for (int i = 0; i < mobUpdate.Count; i++)
        {
            for (int i2 = 0; i < mobUpdate[i].updateObj.Length; i++)
            {
                mobScriptableObject = mobUpdate[i].updateScriptableObject;
                mobStats.mobScriptableObject = mobUpdate[i].updateScriptableObject;

                mobStats.health = mobScriptableObject.Health;

                standartObj[i2].SetActive(false);
                mobUpdate[i].updateObj[i2].SetActive(true);

                standartObj[i2] = mobUpdate[i].updateObj[i2];
                mobUpdate.Remove(mobUpdate[i]);
            }
        }

        AIWalk();
    }
}

[System.Serializable]
public class MobUpdate
{
    public MobScriptableObject updateScriptableObject;
    public int dayUpdate;

    [Space]
    public GameObject[] updateObj;
}