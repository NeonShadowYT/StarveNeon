using UnityEngine;

public class RunEffect : MonoBehaviour
{
    public CustomCharacterController customCharacterController;

    [Space]
    public GameObject runGroundEffect;
    public GameObject runSandEffect, runWaterEffect, runSnowEffect, runInfectionEffect, runADEffect, runRockEffect, enterWaterEffect, runWoodEffect;

    public void RunEffectManager()
    {
        NoRunEffect();

        if (customCharacterController.currentSpeed > customCharacterController.walkingSpeed &&
         customCharacterController.stepId.Count > 0)
        {
            switch (customCharacterController.stepId[0])
            {
                case "Земля":
                    runGroundEffect.SetActive(true);
                    break;
                case "Растение":
                    runGroundEffect.SetActive(true);
                    break;   
                case "Заражение":
                    runInfectionEffect.SetActive(true);
                    break;
                case "Ад":
                    runADEffect.SetActive(true);
                    break;
                case "Камень":
                    runRockEffect.SetActive(true);
                    break;
                case "Песок":
                    runSandEffect.SetActive(true);
                    break;
                case "Cнег":
                    runSnowEffect.SetActive(true);
                    break;
                case "Дерево":
                    runWoodEffect.SetActive(true);
                    break;
                case "Вода":
                    runWaterEffect.SetActive(true);
                    break;
            }
        }
    }

    public void NoRunEffect()
    {
        runGroundEffect.SetActive(false);
        runSandEffect.SetActive(false);
        runWaterEffect.SetActive(false);
        runWoodEffect.SetActive(false);
        runSnowEffect.SetActive(false);
        runInfectionEffect.SetActive(false);
        runADEffect.SetActive(false);
        runRockEffect.SetActive(false);
    }
}
