using UnityEngine;

[HelpURL("https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg")]
public class MobStats : MonoBehaviour
{
    public FractionRace fractionRace = FractionRace.Starver;
    public MobScriptableObject mobScriptableObject;

    [HideInInspector] public GlobalInvoker globalInvoker;
    [HideInInspector] public Transform mTransform;
    [HideInInspector] public AIManager aIManager;
    [HideInInspector] public QuastGame quastGame;
    [HideInInspector] public Animator anim;

    [Space]
    [Header("Основное")]
    public float _health;
    public float health
    {
        get { return _health; }
        set
        {
            _health = value;

            if (aIManager.FractionAI == true)
            {
                if (aIManager.fractionNPS != null)
                {
                    if (_health < complexityHealth + aIManager.fractionNPS.mEquipStats.healthValue)
                    {
                        if (aIManager.fractionNPS.myFraction != null)
                        {
                            switch (fractionRace)
                            {
                                case FractionRace.Ksencse:
                                    aIManager.fractionNPS.myFraction.fractionManager.ksenoRepAmount -= 10;
                                    break;
                                case FractionRace.GC:
                                    aIManager.fractionNPS.myFraction.fractionManager.oborotRepAmount -= 5;
                                    break;
                                case FractionRace.Oboroten:
                                    aIManager.fractionNPS.myFraction.fractionManager.goldenRepAmount -= 15;
                                    break;
                                case FractionRace.Stasy:
                                    aIManager.fractionNPS.myFraction.fractionManager.stasyRepAmount -= 10;
                                    break;
                            }
                        }

                        if (_health <= 0)
                        {
                            aIManager.globalInvoker.customCharacterController.inventoryManager.itemObject.Remove(gameObject);
                        }

                        if (aIManager.DamageForAgreAI == true)
                        {
                            aIManager.AgreAI = true;
                            aIManager.PanicAI = false;
                        }
                    }
                }
            }
            else if (_health < complexityHealth)
            {
                if (aIManager.DamageForAgreAI == true)
                {
                    aIManager.AgreAI = true;
                    aIManager.PanicAI = false;
                }
            }

            if (_health <= 0)
            {
                StoneGathered();
            }
        }
    }

    public float damage;

    [HideInInspector] public float complexityHealth;
    [HideInInspector] public float complexityDamage;

    [Space]
    public SphereCollider attackeSphere;

    [HideInInspector] public float distanceAttacke;
    [HideInInspector] public float destroyTime = 2f;
    [HideInInspector] public int complexity;

    [Space]
    [Header("Другое")]
    public bool armor = false;

    [HideInInspector]
    public bool playerAttackeZone;

    public void Startap()
    {
        globalInvoker = FindObjectOfType<GlobalInvoker>();
        quastGame = FindObjectOfType<QuastGame>();
        aIManager = GetComponent<AIManager>();
        anim = GetComponent<Animator>();

        mTransform = transform;
        complexity = globalInvoker.dataSaveLoad.data.complexity;

        complexityHealth = mobScriptableObject.Health;
        complexityDamage = mobScriptableObject.Damage;

        ComplexityEquip();

        health = complexityHealth;
        damage = complexityDamage;

        if (attackeSphere != null) distanceAttacke = attackeSphere.radius;
    }

    public void ComplexityEquip()
    {
        switch (complexity)
        {
            case 0:
                complexityHealth *= 0.75f;
                complexityDamage *= 0.75f;
                break;
            case 2:
                complexityHealth *= 1.25f;
                complexityDamage *= 1.25f;
                break;
            case 3:
                complexityHealth *= 1.5f;
                complexityDamage *= 1.5f;
                break;
        }
    }

    public void StoneGathered()
    {
        aIManager.AIStop();

        if (anim != null)
        {
            anim.SetBool("Death", true);
        }
        else
        {
            Destroys();
        }
    }

    public void RespawnResource()
    {
        anim.SetBool("Damage", false);
        anim.SetBool("ViewTarget", false);
        anim.SetFloat("Speed", 0f);
        anim.SetFloat("Target", 0f);

        health = complexityHealth;
        damage = complexityDamage;

        if (attackeSphere != null) attackeSphere.radius = distanceAttacke;

        playerAttackeZone = false;
        aIManager.optimizer.MobView.SetActive(false);

        aIManager.globalInvoker.aiAnimUpdate.Remove(aIManager);
        aIManager.globalInvoker.aiMoveAnimal.Remove(aIManager);
        aIManager.globalInvoker.aiViewTarget.Remove(aIManager);

        aIManager.navMeshAgent.enabled = false;
        aIManager.mobCollider.enabled = false;
        aIManager.animator.enabled = false;
        aIManager.audios.enabled = false;

        aIManager.death = true;

        if (aIManager.fractionNPS != null) aIManager.fractionNPS.Startnps();

        Invoke("ReMob", mobScriptableObject.respawnTime);
    }

    public void ReMob()
    {
        anim.SetBool("Death", false);
        aIManager.death = false;
    }

    public void HitForMe(float hDamage)
    {
        if (mobScriptableObject.FireArmor < 1) health -= hDamage;
        else
        {
            if (mobScriptableObject.FireArmor == 1) health -= hDamage / 1.25f;
            else if (mobScriptableObject.FireArmor == 2) health -= hDamage / 1.5f;
            else if (mobScriptableObject.FireArmor == 3) health -= hDamage / 1.75f;
            else if (mobScriptableObject.FireArmor == 4) health -= hDamage / 2f;
        }
    }

    public void AtackePlayer()
    {
        if (playerAttackeZone == false) return;
        
        float rDamage = damage;

        rDamage += Random.Range(-5, 5);

        aIManager.globalInvoker.customCharacterController.MobHitAttacke(rDamage, mobScriptableObject.blood, mobScriptableObject.crit, mobScriptableObject.critModifer, mobScriptableObject.weak, mobScriptableObject.weakModifer);
    }

    public void Destroys()
    {
        aIManager.globalInvoker.aiViewTarget.Remove(aIManager);
        aIManager.globalInvoker.aiAnimUpdate.Remove(aIManager);
        aIManager.globalInvoker.aiMoveAnimal.Remove(aIManager);

        for (int i = 0; i < quastGame.quastItemList.Count; i++)
        {
            if (quastGame.quastItemList[i].quastScriptableObject.QuastMob == mobScriptableObject)
            {
                quastGame.quastItemList[i].PassItemProgress.value += 1;

                if (quastGame.quastItemList[i].PassItemProgress.value == quastGame.quastItemList[i].PassItemProgress.maxValue)
                {
                    Debug.Log("Выполнен квест " + quastGame.quastItemList[i].quastScriptableObject.QuastText);
                    quastGame.AddQuastReward(i);
                }
            }
        }

        Vector3 LutSpanw = mTransform.position + new Vector3(0f, 0.5f, 0f) + Vector3.up + mTransform.forward;

        foreach (LutList lut in mobScriptableObject.LutList)
        {
            aIManager.globalInvoker.customCharacterController.inventoryManager.AddItem(null, lut.Item, lut.Amount, lut.Item.maximumDurability, 0);
        }

        RespawnResource();
    }
}