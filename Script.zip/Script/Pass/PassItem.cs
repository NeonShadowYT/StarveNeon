using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PassItem : MonoBehaviour
{
    [Space]
    [Header("Визуал")]
    public Image PassItemImage;

    public TMP_Text PassNameItems;
    public TMP_Text PassItemLvl;
}