﻿using UnityEngine;

public interface IHaveConnections
{
    void TurnOnConnections();
}
