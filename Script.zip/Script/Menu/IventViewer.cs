using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class IventViewer : MonoBehaviour
{
    public static IventViewer instance;

    [Space]
    public GameObject iventObject;
    public Image iventImage;
    public TMP_Text iventText;

    [Space]
    public Image stoleryImage;
    public TMP_Text stoleryText;
    public Image statsImage;
    public TMP_Text statsText;

    private void Awake() => instance = this;
    
    public void IventView(Sprite _iventIcon, string _iventText)
    {
        CancelInvoke();

        iventImage.sprite = _iventIcon;
        iventText.text = _iventText;

        iventObject.SetActive(true);
        Invoke(nameof(CancelView), 5f);
    }

    public void ChangStats(Sprite _stoleryIcon, string _stoleryText, Sprite _statsIcon, string _statsText)
    {
        stoleryImage.sprite = _stoleryIcon;
        stoleryText.text = _stoleryText;
        statsImage.sprite = _statsIcon;
        statsText.text = _statsText;
    }

    private void CancelView()
    {
        iventObject.SetActive(false);
    }
}
