using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameModeManager : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;
    private Daytime daytime;

    [Space]
    [Header("Инфа")]
    public Image image;
    public TMP_Text text;

    [Space]
    [Header("Текущий пресет")]
    public GameModeScriptableObject currentGameMode;

    [Space]
    [Header("Пресеты")]
    public List<GameModeScriptableObject> GameModeList;

    [Space]
    [Header("Настройки")]
    public List<GameSettingsScriptableObject> SettingsList;
    public List<GameSettingsScriptableObject> AcceptSettingsList;

    [Space]
    [Header("Контент")]
    public Transform GameModeContent;
    public Transform GameSettingsContent;
    public Transform GameActiveSettingsContent;

    [Space]
    [Header("Префабы")]
    public GameObject GameModePrefab;
    public GameObject GameSettingsPreviewPrefab;
    public GameObject GameSettingsPrefab;

    [Space]
    [Header("В игре?")]
    public bool Game;
    public bool MP;

    [Space]
    [Header("Отображение генов")]
    public GameObject genContent;

    public void Start()
    {
        if (Game == false)
        {
            foreach (GameModeScriptableObject mode in GameModeList) // ��������� ��� ������
            {
                GameModeItem gameModeItem = Instantiate(GameModePrefab, GameModeContent).GetComponent<GameModeItem>();

                gameModeItem.GameModeManager = this;

                gameModeItem.GameModeScriptableObject = mode;

                gameModeItem.image.sprite = mode.icon;
                gameModeItem.text.text = mode.NameMode;
            }

            foreach (GameSettingsScriptableObject settings in SettingsList) // ��������� ��� ��������� ������� ����� ����� ��������
            {
                GameSettingsItem settingsItem = Instantiate(GameSettingsPreviewPrefab, GameSettingsContent).GetComponent<GameSettingsItem>();

                settingsItem.GameModeManager = this;

                settingsItem.gameSettingsScriptableObject = settings;
                settingsItem.text.text = settings.NameSettings;
                settingsItem.icon.sprite = settings.IconSettings;
            }

            ChangeGameMode(currentGameMode);
        }
        else
        {
            daytime = FindObjectOfType<Daytime>();

            if (PlayerPrefs.HasKey("Multiplayer")) MP = System.Convert.ToBoolean(PlayerPrefs.GetInt("Multiplayer")); else MP = false;
            if (PlayerPrefs.HasKey("GenView")) genContent.SetActive(System.Convert.ToBoolean(PlayerPrefs.GetInt("GenView"))); else genContent.SetActive(false);

            if (daytime == null) return;

            if (MP == true)
            { 
                foreach (GameObject _Ultimateobj in daytime.Ultimateobj) _Ultimateobj.SetActive(false);
                foreach (GameObject _Nobj in daytime.Nobj) _Nobj.SetActive(false);

                daytime.NobjForDay = false;
                daytime.BadWeather = false;
                daytime.MobUpdater = false;

                if (daytime.RouSpawner != null) daytime.RouSpawner.SetActive(false);
                if (daytime.MoreResoursSpawner != null) daytime.MoreResoursSpawner.SetActive(false);
                if (daytime.PlantsExpanded != null) daytime.PlantsExpanded.SetActive(false);

                if (daytime.OberSet != null) daytime.OberSet.SetActive(false);
                if (daytime.MediSet != null) daytime.MediSet.SetActive(false);

                return;
            }
        }

        Load();
    }

    public void Load()
    {
        if (Game == true && daytime != null)
        {
            foreach (GameObject _Ultimateobj in daytime.Ultimateobj) _Ultimateobj.SetActive(false);
            foreach (GameObject _Nobj in daytime.Nobj) _Nobj.SetActive(false);

            daytime.NobjForDay = false;
            daytime.BadWeather = false;
            daytime.MobUpdater = false;

            if (daytime.RouSpawner != null) daytime.RouSpawner.SetActive(false);
            if (daytime.MoreResoursSpawner != null) daytime.MoreResoursSpawner.SetActive(false);
            if (daytime.PlantsExpanded != null) daytime.PlantsExpanded.SetActive(false);

            if (daytime.OberSet != null) daytime.OberSet.SetActive(false);
            if (daytime.MediSet != null) daytime.MediSet.SetActive(false);

            for (int i = 0; i < dataSaveLoad.data.settingsNames.Length; i++)
                {
                    GameSettingsScriptableObject gameSettingsScriptableObject = Resources.Load<GameSettingsScriptableObject>($"GameModeScriptable/Settings/{dataSaveLoad.data.settingsNames[i]}");

                    AcceptSettingsList.Add(gameSettingsScriptableObject);

                    switch (gameSettingsScriptableObject.NameSettings)
                    {
                        case "Рой":
                            if (daytime.RouSpawner != null) daytime.RouSpawner.SetActive(true);
                            break;
                        case "Хардовые мобы":
                            foreach (GameObject _Ultimateobj in daytime.Ultimateobj) _Ultimateobj.SetActive(true);
                            break;
                        case "Ночные мобы днём":
                            daytime.NobjForDay = true;
                            foreach (GameObject _Nobj in daytime.Nobj) _Nobj.SetActive(true);
                            break;
                        case "Плохая погода чаще":
                            daytime.BadWeather = true;
                            break;
                        case "Усиленные мобы":
                            daytime.MobUpdater = true;
                            break;
                        case "Больше разбросанных ресурсов":
                            if (daytime.MoreResoursSpawner != null) daytime.MoreResoursSpawner.SetActive(true);
                            break;
                        case "Больше растений":
                            if (daytime.PlantsExpanded != null) daytime.PlantsExpanded.SetActive(true);
                            break;
                        case "Обер сет":
                            if (daytime.OberSet != null) daytime.OberSet.SetActive(true);
                            break;
                        case "Медный сет":
                            if (daytime.MediSet != null) daytime.MediSet.SetActive(true);
                            break;
                    }
                }
        }
        else
        {
            RemoveAllSettings();

            for (int i = 0; i < dataSaveLoad.data.settingsNames.Length; i++)
            {
                GameSettingsScriptableObject gameSettingsScriptableObject = Resources.Load<GameSettingsScriptableObject>($"GameModeScriptable/Settings/{dataSaveLoad.data.settingsNames[i]}");

                AddSettings(gameSettingsScriptableObject);
            }
        }
    }

    public void ChangeGameMode(GameModeScriptableObject gameSettingsScriptableObject) // ������������� ��������� ������
    {
        currentGameMode = gameSettingsScriptableObject;

        text.text = currentGameMode.NameMode;
        image.sprite = currentGameMode.icon;

        RemoveAllSettings();

        foreach (GameSettingsScriptableObject settings in gameSettingsScriptableObject.SettingsList)
        {
            AddSettings(settings);
        }
    }

    public void AddSettings(GameSettingsScriptableObject gameSettingsScriptableObjects) // ��������� ���������
    {
        SettingsList.Remove(gameSettingsScriptableObjects);
        AcceptSettingsList.Add(gameSettingsScriptableObjects);

        GameSettingsItem settingsItem = Instantiate(GameSettingsPrefab, GameActiveSettingsContent).GetComponent<GameSettingsItem>();

        settingsItem.GameModeManager = this;

        settingsItem.gameSettingsScriptableObject = gameSettingsScriptableObjects;
        settingsItem.text.text = gameSettingsScriptableObjects.NameSettings;
        settingsItem.icon.sprite = gameSettingsScriptableObjects.IconSettings;

        for (int i = 0; i < GameSettingsContent.childCount; i++)
        {
            GameSettingsItem settingsItemPreview = GameSettingsContent.GetChild(i).GetComponent<GameSettingsItem>();

            if (settingsItem.gameSettingsScriptableObject == settingsItemPreview.gameSettingsScriptableObject)
            {
                Destroy(settingsItemPreview.gameObject);
                break;
            }
        }
    }

    public void RemoveAllSettings() // ������� ��� ���������
    {
        for (int i = 0; i < GameActiveSettingsContent.childCount; i++)
        {
            GameSettingsItem gameSettingsItem = GameActiveSettingsContent.GetChild(i).GetComponent<GameSettingsItem>();

            RemoveSettings(gameSettingsItem.gameSettingsScriptableObject);

            Destroy(gameSettingsItem.gameObject);
        }
    }

    public void RemoveSettings(GameSettingsScriptableObject gameSettingsScriptableObject) // ������� ���������
    {
        SettingsList.Add(gameSettingsScriptableObject);
        AcceptSettingsList.Remove(gameSettingsScriptableObject);

        GameSettingsItem settingsItem = Instantiate(GameSettingsPreviewPrefab, GameSettingsContent).GetComponent<GameSettingsItem>();

        settingsItem.GameModeManager = this;

        settingsItem.gameSettingsScriptableObject = gameSettingsScriptableObject;
        settingsItem.text.text = gameSettingsScriptableObject.NameSettings;
        settingsItem.icon.sprite = gameSettingsScriptableObject.IconSettings;
    }

    public void CurrentGameModer()
    {
        ChangeGameMode(currentGameMode);
    }
}