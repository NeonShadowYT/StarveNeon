﻿using UnityEngine;

public interface ICheckColliders
{
    void CheckColliders();
}