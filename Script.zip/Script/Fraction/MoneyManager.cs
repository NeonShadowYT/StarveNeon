using System.Collections.Generic;
using UnityEngine;

public class MoneyManager : MonoBehaviour
{
    public static MoneyManager instance;

    [Space]
    [Header("Слоты")]
    public List<MoneySlot> AllMoneySlot;

    private void Awake() => instance = this;

    public void Start()
    {
        for (int i = 0; i < AllMoneySlot.Count; i++)
        {
            switch (AllMoneySlot[i].money.moneyType)
            {
                case MoneyType.Ksencse:
                    AllMoneySlot[i].amount = DataSaveLoad.instance.data.ksenoAmount;
                    break;
                case MoneyType.GC:
                    AllMoneySlot[i].amount = DataSaveLoad.instance.data.goldenAmount;
                    break;
                case MoneyType.Oboroten:
                    AllMoneySlot[i].amount = DataSaveLoad.instance.data.oborotAmount;
                    break;
                case MoneyType.Stasy:
                    AllMoneySlot[i].amount = DataSaveLoad.instance.data.stasyAmount;
                    break;
                case MoneyType.Texno:
                    AllMoneySlot[i].amount = DataSaveLoad.instance.data.texnoAmount;
                    break;
            }
        }
    }

    public void CheckCurrentMoney(FractionScriptableObject currentFraction)
    {
        foreach (MoneySlot mos in AllMoneySlot)
        {
            if (mos.money == currentFraction.fractionMoney)
            {
                FractionManager.instance.currentMoneySlot = mos;
                mos.gameObject.SetActive(true);
            }
            else
            {
                mos.gameObject.SetActive(false);
            }
        }
    }
    public void CurrentAddMoney(MoneyItem money)
    {
        foreach (MoneySlot mos in AllMoneySlot)
        {
            if (mos.money == money.money)
            {
                mos.amount += money.amount;
                break;
            }
        }
    }
}
