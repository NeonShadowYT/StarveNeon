using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "GameMode", menuName = "Neon Imperium/GameMode/New GameMode")]
public class GameModeScriptableObject : ScriptableObject
{
    [Space]
    [Header("���������")]
    public string NameMode;
    public Sprite icon;

    [Space]
    public List<GameSettingsScriptableObject> SettingsList;
}