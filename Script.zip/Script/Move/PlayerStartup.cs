using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;

public class PlayerStartup : MonoBehaviourPunCallbacks
{
    public Transform[] spawn;
    public GameObject playerPrefab;

    void Awake()
    {
        SpawnController();
    }

    public void SpawnController()
    {
        Transform spawnPoint = spawn[Random.Range(0, spawn.Length)];

        if (PhotonNetwork.InRoom)
        {
            PhotonNetwork.Instantiate(playerPrefab.name, spawnPoint.position, spawnPoint.rotation);
        }
        else
        {
            Instantiate(playerPrefab, spawnPoint.position, spawnPoint.rotation);
        }

        Destroy(gameObject);
    }
}