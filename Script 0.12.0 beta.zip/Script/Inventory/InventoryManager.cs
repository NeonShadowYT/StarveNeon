﻿using Cinemachine;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using TMPro;
using System;

public class InventoryManager : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Скрипты и аниматор")]
    public DataSaveLoad dataSaveLoad;
    public QuickslotInventory quickslotInventory;
    public PhotonSetManager photonSetManager;
    public FractionManager fractionManager;
    public VerstAddItem verstAddItem;
    public CraftManager craftManager;
    public MoneyManager moneyManager;
    public ClothAdder clothAdder;

    [Space]
    [Header("Камера")]
    public CinemachineVirtualCamera CVC;
    private CinemachinePOV pov;

    [HideInInspector] public float sensitivity;
    [HideInInspector] public DragAndDropItem dropScript;
    [HideInInspector] public Storage currentStorage;

    [Space]
    [Header("Компоненты")]
    public Animator anim;
    public Transform player;
    public AudioSource audioSource;

    [Space]
    [Header("Объекты")]
    public TMP_Text nameText;
    public GameObject globalCanvas;
    public GameObject viewCamera;
    public GameObject craftPanel;
    public GameObject chatPanel;
    public GameObject storagePanel;

    [Space]
    [Header("Детальная информация предмета")]
    public GameObject detailsPanel;
    public TMP_Text detailsDescriphen;
    public TMP_Text detailsName;
    public Image detailsIcon;

    [Space]
    [Header("Буллы")]
    [HideInInspector] public bool isOpened;
    [HideInInspector] public bool isInput;

    private bool destroyItem;

    [Space]
    [Header("Листы")]
    public List<InventorySlot> slots;
    public List<InventorySlot> storageSlots;

    [HideInInspector] public List<GameObject> itemObject;

    void Start()
    {
        pov = CVC.GetCinemachineComponent<CinemachinePOV>();
        nameText.text = dataSaveLoad.data.playerNick;

        EditCurcorOff();
    }

    public void ToInventory(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            isOpened = !isOpened;

            if (isOpened)
            {
                EditCurcorOn();
            }
            else
            {
                EditCurcorOff();
            }
        }
    }

    public void InputE(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            if (isInput == false) return;

            EditCurcorOff();
            Interactable();
        }
    }

    public void Interactable()
    {
        quickslotInventory.CheckItemInHand();

        for (int i = 0; i < itemObject.Count; i++)
        {
            if (itemObject[i].CompareTag("Item"))
            {
                Item itemscript = itemObject[i].GetComponent<Item>();

                anim.SetBool("addItem", true);
                destroyItem = true;

                AddItem(itemscript, itemscript.item, itemscript.amount, itemscript.durability, itemscript.destroy);

                audioSource.volume = UnityEngine.Random.Range(0.2f, 0.4f);
                audioSource.pitch = UnityEngine.Random.Range(0.8f, 1.2f);

                audioSource.PlayOneShot(itemscript.item.itemAudio);

                if (destroyItem == true)
                {
                    if (itemscript.optimize == false)
                    {
                        Destroy(itemObject[i]);
                        itemObject.Remove(itemObject[i]);
                    }
                    else
                    {
                        itemObject[i].SetActive(false); //для кустов
                        itemObject.Remove(itemObject[i]);
                    }
                }
                else
                {
                    if (itemscript.optimize == false) 
                    {
                        itemObject[i].transform.position = player.position + Vector3.up + player.forward;
                    }
                }
            }
            else
            {
                if (itemObject[i].CompareTag("FractionMoney"))
                {
                    MoneyItem money = itemObject[i].GetComponent<MoneyItem>();

                    fractionManager.AddMoney(money);
                    anim.SetBool("addItem", true);

                    Destroy(itemObject[i]);
                    itemObject.Remove(itemObject[i]);
                }
                else if (itemObject[i].CompareTag("FractionNps"))
                {
                    EditCurcorOn();
                    FractionNPS fractionNps = itemObject[i].GetComponent<FractionNPS>();

                    fractionManager.currentFraction = fractionNps.NPSFraction;
                    fractionManager.FractionNPCText.text = fractionNps.mEquipStats.name;

                    switch (fractionNps.NPSFraction.fractionRace)
                    {
                        case FractionRace.Ksencse:
                            fractionManager.FractionReputationText.text = fractionManager.ksenoRepAmount.ToString();
                            if (fractionManager.ksenoRepAmount >= 0) fractionManager.FractionFunc();
                            break;
                        case FractionRace.GC:
                            fractionManager.FractionReputationText.text = fractionManager.goldenRepAmount.ToString();
                            if (fractionManager.goldenRepAmount >= 0) fractionManager.FractionFunc();
                            break;
                        case FractionRace.Oboroten:
                            fractionManager.FractionReputationText.text = fractionManager.oborotRepAmount.ToString();
                            if (fractionManager.oborotRepAmount >= 0) fractionManager.FractionFunc();
                            break;
                        case FractionRace.Stasy:
                            fractionManager.FractionReputationText.text = fractionManager.stasyRepAmount.ToString();
                            if (fractionManager.stasyRepAmount >= 0) fractionManager.FractionFunc();
                            break;
                    }
                }
                else if (itemObject[i].CompareTag("Storage"))
                {
                    EditCurcorOn();
                    Storage storage = itemObject[i].GetComponent<Storage>();

                    for (int ii = 0; i < storageSlots.Count; i++)
                    {
                        storageSlots[ii].gameObject.SetActive(false);
                    }

                    for (int ii = 0; ii < storage.slots.Count; ii++)
                    {
                        InventorySlot slot = storageSlots[ii];
                        slot.gameObject.SetActive(true);

                        if (storage.slots[ii].item == null)
                        {
                            slot.item = null;
                            slot.amount = 0;
                            slot.iconGO.color = new Color(1, 1, 1, 0);
                            slot.iconGO.sprite = null;
                            slot.itemAmountText.text = "";
                        }
                        else
                        {
                            slot.item = storage.slots[ii].item;
                            slot.amount = storage.slots[ii].amount;
                            slot.SetIcon(slot.item.icon);
                            if (slot.item.maximumAmount != 1) slot.itemAmountText.text = slot.amount.ToString();
                        }
                    }
            
                    storagePanel.gameObject.SetActive(true);
                }
                else if (itemObject[i].CompareTag("Door"))
                {
                    Door door = itemObject[i].GetComponent<Door>();

                    door.InvertDoorState();

                    audioSource.volume = UnityEngine.Random.Range(0.2f, 0.4f);
                    audioSource.pitch = UnityEngine.Random.Range(0.8f, 1.2f);

                    audioSource.PlayOneShot(door.doorAudio);
                }
                else
                {
                    if (itemObject[i].CompareTag("Verstac")) VerstacPanels(0);
                    else
                    {
                        if (itemObject[i].CompareTag("Verstac2")) VerstacPanels(1);
                        else
                        {
                            if (itemObject[i].CompareTag("Verstac3")) VerstacPanels(2);
                            else
                            {
                                if (itemObject[i].CompareTag("Verstac4")) VerstacPanels(3);
                                else
                                {
                                    if (itemObject[i].CompareTag("BioTex")) VerstacPanels(4);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public void OffInput() => isInput = false;
    public void OnInput() => isInput = true;

    public void VerstacPanels(int verstID)
    {
        EditCurcorOn();

        verstAddItem.StartFunc(verstID);
    }

    public void DetailsItemView(ItemScriptableObject _item, int _amount, DragAndDropItem _dropScript)
    {
        detailsName.text = _item.itemName + " " + _amount.ToString() + "/" + _item.maximumAmount;
        detailsIcon.sprite = _item.icon;
        detailsDescriphen.text = _item.itemDescription;

        dropScript = _dropScript;
        detailsPanel.SetActive(true);
        chatPanel.SetActive(false);
        craftPanel.SetActive(false);
    }

    public void DropDetailsItem()
    {
        dropScript.DropItems();
    }

    public void FixDetailsItem()
    {
        dropScript.oldSlot.UpdateDurabilityBar();

        if (dropScript.oldSlot.itemDurability >= dropScript.oldSlot.item.maximumDurability || dropScript.oldSlot.destroyBar.fillAmount >= 0.95f ) return;

        CraftScriptableObject craftScriptable = null;

        for (int i = 0; i < craftManager.allCrafts.Count; i++) // ищем нужный крафт
        {
            if (dropScript.oldSlot.item == craftManager.allCrafts[i].finalCraft)
            {
                craftScriptable = craftManager.allCrafts[i];
            }
        }

        if (craftScriptable == null) return; //если у игрока нет изучения этого предмета то ничего не будет фиксится

        bool canFix = true;
        int amountToRemove = 0;
        
        for (int i = 0; i < craftScriptable.craftResources.Count; i++) //есть ли у нас эти ресурсы
        {
            amountToRemove = (int)(craftScriptable.craftResources[i].craftObjectAmount * (1f - dropScript.oldSlot.destroyBar.fillAmount / 100f));
            int resourceAmount = 0;

            foreach (InventorySlot slot in slots)
            {
                if (slot.item == null) continue;

                if (slot.item.itemName == craftScriptable.craftResources[i].craftObject.itemName) resourceAmount += slot.amount;
            }

            if (resourceAmount < amountToRemove) 
            {
                canFix = false;
                break;
            }
        }

        if (canFix == true) // если есть то отнимаем их и фиксим предмет
        {
            for (int i = 0; i < craftScriptable.craftResources.Count; i++)
            {
                amountToRemove = (int)(craftScriptable.craftResources[i].craftObjectAmount * (1f - dropScript.oldSlot.destroyBar.fillAmount / 100f));

                for (int iii = 0; iii < slots.Count; iii++)
                {
                    if (amountToRemove <= 0) 
                    {
                        break;
                    }

                    if (slots[iii].item == craftScriptable.craftResources[i].craftObject)
                    {
                        if(amountToRemove > slots[iii].amount)
                        {
                            amountToRemove -= slots[iii].amount;
                            slots[iii].GetComponentInChildren<DragAndDropItem>().NullifySlotData();
                        }
                        else
                        {
                            slots[iii].amount -= amountToRemove;
                            amountToRemove = 0;

                            if(slots[iii].amount <= 0) slots[iii].GetComponentInChildren<DragAndDropItem>().NullifySlotData(); else slots[iii].itemAmountText.text = slots[iii].amount.ToString();
                        }
                    }
                }
            }

            dropScript.oldSlot.destroyBar.fillAmount += UnityEngine.Random.Range(0.1f, 0.2f); //повреждаем предмет чтобы игрок не мог его всегда чинить
            dropScript.oldSlot.itemDurability = dropScript.oldSlot.item.maximumDurability * (1f - dropScript.oldSlot.destroyBar.fillAmount); //чиним
        }

        detailsPanel.SetActive(false);
        clothAdder.UpdateClothes();
    }

    public void RemoveItemFromSlot(int slotId)
    {
        InventorySlot slot = slots[slotId];
        if (slot.clothType != ClothType.None && slot.item != null) clothAdder.UpdateClothes();
        
        slot.item = null;
        slot.amount = 0;
        slot.itemDurability = 0f;
        slot.durabilityBar.fillAmount = 0f;
        slot.destroyBar.fillAmount = 0f;
        slot.iconGO.color = new Color(1, 1, 1, 0);
        slot.iconGO.sprite = null;
        slot.itemAmountText.text = "";
    }

    public void AddItemToSlot(ItemScriptableObject _item, int _amount, float _durability, float _destroy, int slotId)
    {
        InventorySlot slot = slots[slotId];
        slot.item = _item;
        slot.destroyBar.fillAmount = _destroy;
        slot.itemDurability = _durability;
        slot.SetIcon(_item.icon);
        if (_amount <= _item.maximumAmount)
        {
            slot.amount = _amount;
            if (slot.item.maximumAmount != 1) slot.itemAmountText.text = slot.amount.ToString();
        }
        else
        {
            slot.amount = _item.maximumAmount;
            _amount -= _item.maximumAmount;
            if (slot.item.maximumAmount != 1) slot.itemAmountText.text = slot.amount.ToString();
        }
        if (slot.clothType != ClothType.None) clothAdder.UpdateClothes();
    }

    public void AddItem(Item _itemScript, ItemScriptableObject _item, int _amount, float _durability, float _destroy)
    {      
        foreach (InventorySlot slot in slots)
        {
            if (slot.item == _item) // Стакаем предметы вместе // В слоте уже имеется этот предмет
            {
                if (slot.amount + _amount <= _item.maximumAmount)
                {
                    slot.amount += _amount;
                    slot.itemAmountText.text = slot.amount.ToString();
                    return;
                }
                else
                {
                    _amount -= _item.maximumAmount - slot.amount;
                    slot.amount = _item.maximumAmount;
                    slot.itemAmountText.text = slot.amount.ToString();
                }
                continue;
            }
        }

        bool allFull = true;
        foreach (InventorySlot inventorySlot in slots)
        {
            if (inventorySlot.item == null && inventorySlot.clothType == ClothType.None)
            {
                allFull = false;
                break;
            }
        }

        if (allFull) 
        {
            destroyItem = false;

            if (_itemScript == null)
            {
                Item itemScript = Instantiate(_item.itemPrefab, player.position + Vector3.up + player.forward, Quaternion.identity).GetComponent<Item>();

                itemScript.amount = _amount;
                itemScript.durability = _durability;
                itemScript.destroy = _destroy;
            }
            else
            {
                _itemScript.amount = _amount;
                _itemScript.durability = _durability;
                _itemScript.destroy = _destroy;
            }

            return;
        }

        foreach (InventorySlot slot in slots)
        {
            if (_amount <= 0) return;

            if (slot.item == null && slot.clothType == ClothType.None) // добавляем предметы в свободные ячейки
            {
                slot.item = _item; //slot.amount = amount;
                slot.itemDurability = _durability;
                slot.destroyBar.fillAmount = _destroy;
                slot.SetIcon(_item.icon);

                if (_amount <= _item.maximumAmount)
                {
                    slot.amount = _amount;

                    if (slot.item.maximumAmount != 1) 
                    {
                        slot.itemAmountText.text = slot.amount.ToString(); 
                    }
                    else
                    {
                        slot.itemAmountText.text = "";
                    }

                    break;
                }
                else
                {
                    slot.amount = _item.maximumAmount;
                    _amount -= _item.maximumAmount;
                     if (slot.item.maximumAmount != 1) 
                    {
                        slot.itemAmountText.text = slot.amount.ToString(); 
                    }
                    else
                    {
                        slot.itemAmountText.text = "";
                    }
                }

                allFull = true;
                foreach (InventorySlot inventorySlot in slots)
                {
                    if (inventorySlot.item == null && inventorySlot.clothType == ClothType.None)
                    {
                        allFull = false;
                        break;
                    }
                }
                
                if (allFull)
                {
                    destroyItem = false;

                    if (_itemScript == null)
                    {
                        Item itemScript = Instantiate(_item.itemPrefab, player.position + Vector3.up + player.forward, Quaternion.identity).GetComponent<Item>();

                        itemScript.amount = _amount;
                        itemScript.durability = _durability;
                        itemScript.destroy = _destroy;
                    }
                    else
                    {
                        _itemScript.amount = _amount;
                        _itemScript.durability = _durability;
                        _itemScript.destroy = _destroy;
                    }

                    break;
                } //continue;
            }
        }
    }

    public void EditCurcorOn()
    {
        isOpened = true;

        fractionManager.FractionClose();
        storagePanel.SetActive(false);
        detailsPanel.SetActive(false);
        viewCamera.SetActive(true);
        craftPanel.SetActive(false);
        chatPanel.SetActive(true);

        globalCanvas.SetActive(true);

        Cursor.lockState = CursorLockMode.None; // Прекрепляем курсор к середине экрана
        Cursor.visible = true; // и делаем его невидимым

        anim.SetBool("Hit", false);
        quickslotInventory.HitBool = false;

        pov.m_HorizontalAxis.m_InputAxisName = "";
        pov.m_VerticalAxis.m_InputAxisName = "";
        pov.m_HorizontalAxis.m_InputAxisValue = 0;
        pov.m_VerticalAxis.m_InputAxisValue = 0;
    }

    public void EditCurcorOff()
    {
        OnInput();
        isOpened = false;
        
        fractionManager.FractionClose();
        storagePanel.SetActive(false);
        detailsPanel.SetActive(false);
        viewCamera.SetActive(false);
        craftPanel.SetActive(false);
        chatPanel.SetActive(false);

        globalCanvas.SetActive(false);

        anim.SetBool("Hit", false);
        quickslotInventory.HitBool = false;
        
        Cursor.lockState = CursorLockMode.Locked; // Прекрепляем курсор к середине экрана
        Cursor.visible = false; // и делаем его невидимым

        pov.m_HorizontalAxis.m_InputAxisName = "Mouse X";
        pov.m_VerticalAxis.m_InputAxisName = "Mouse Y";
    }
}