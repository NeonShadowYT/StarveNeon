
using UnityEngine;
using UnityEngine.Advertisements;

public class InterstitialAds : MonoBehaviour, IUnityAdsLoadListener, IUnityAdsShowListener
{
    public string appKeyAndroid;

    public void Start()
    {
        ShowAd();
    }

    public void ShowAd()
    {
        if (PlayerPrefs.HasKey("AdsMode"))
        {
            if (PlayerPrefs.GetInt("AdsMode") == 1) 
            {
                Advertisement.Load(appKeyAndroid, this);
                Advertisement.Show(appKeyAndroid, this);
            }
        }
    }

    public void OnUnityAdsAdLoaded(string placementId)
    {
        Debug.Log("Реклама загружена: " + placementId);
    }

    public void OnUnityAdsFailedToLoad(string placementId, UnityAdsLoadError error, string message)
    {
        Debug.Log($"Не удалось загрузить рекламу: {error.ToString()} - {message}");
        ShowAd();
    }

    public void OnUnityAdsShowFailure(string placementId, UnityAdsShowError error, string message)
    {
        Debug.Log($"Не удалось показать рекламу: {error.ToString()} - {message}");
        ShowAd();
    }

    public void OnUnityAdsShowStart(string placementId)
    {
        Debug.Log("Начался показ рекламы: " + placementId);
    }

    public void OnUnityAdsShowClick(string placementId)
    {
        Debug.Log("Нажатие на рекламу: " + placementId);

        switch(Random.Range(0, 9))
        {
            case 0 :
                DataSaveLoad.instance.data.woodValue += Random.Range(128, 256);
                break;
            case 1 :
                DataSaveLoad.instance.data.rockValue += Random.Range(64, 128);
                break;
            case 2 :
                DataSaveLoad.instance.data.cuprumValue += Random.Range(32, 64);
                break;
            case 3 :
                DataSaveLoad.instance.data.goldValue += Random.Range(16, 32);
                break;
            case 4 :
                DataSaveLoad.instance.data.diamondValue += Random.Range(8, 16);
                break;
            case 5 :
                DataSaveLoad.instance.data.ametistValue += Random.Range(4, 8);
                break;
            case 6 :
                DataSaveLoad.instance.data.reditValue += Random.Range(2, 4);
                break;
            case 7 :
                DataSaveLoad.instance.data.izumValue += Random.Range(1, 2);
                break;
            case 8 :
                DataSaveLoad.instance.data.coreValue += 1;
                break;
            case 9 :
                DataSaveLoad.instance.data.neolitValue += Random.Range(0, 1);
                break;
        }
    }

    public void OnUnityAdsShowComplete(string placementId, UnityAdsShowCompletionState showCompletionState)
    {
        if (showCompletionState.Equals(UnityAdsShowCompletionState.COMPLETED))
        {
            switch(Random.Range(0, 9))
            {
                case 0 :
                    DataSaveLoad.instance.data.woodValue += Random.Range(128, 256);
                    break;
                case 1 :
                    DataSaveLoad.instance.data.rockValue += Random.Range(64, 128);
                    break;
                case 2 :
                    DataSaveLoad.instance.data.cuprumValue += Random.Range(32, 64);
                    break;
                case 3 :
                    DataSaveLoad.instance.data.goldValue += Random.Range(16, 32);
                    break;
                case 4 :
                    DataSaveLoad.instance.data.diamondValue += Random.Range(8, 16);
                    break;
                case 5 :
                    DataSaveLoad.instance.data.ametistValue += Random.Range(4, 8);
                    break;
                case 6 :
                    DataSaveLoad.instance.data.reditValue += Random.Range(2, 4);
                    break;
                case 7 :
                    DataSaveLoad.instance.data.izumValue += Random.Range(1, 2);
                    break;
                case 8 :
                    DataSaveLoad.instance.data.coreValue += 1;
                    break;
                case 9 :
                    DataSaveLoad.instance.data.neolitValue += Random.Range(0, 1);
                    break;
            }
        }
    }
}