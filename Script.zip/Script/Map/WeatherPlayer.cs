using UnityEngine;
using System.Collections;

public class WeatherPlayer : MonoBehaviour
{
    public static WeatherPlayer instance;

    public WeatherType currentWeatherType;

    [Space]
    [Header("Визуал")]
    public GameObject RainObj;
    public GameObject RainToxinObj;
    public GameObject RainAdObj;

    [Space]
    public GameObject FireObj;
    public GameObject ColdObj;

    [Space]
    [Header("Характеристика")]
    public int WeatherArmor;
    public float ColdChang;

    private void Awake() => instance = this;

    public void StartWeather()
    {
        StopCoroutine(WeatherIndicator());

        if (currentWeatherType == WeatherType.Default || ColdChang == 0) return;

        if (ArmorStats.instance.cold < WeatherArmor)
        {
            StartCoroutine(WeatherIndicator());
        }
    }

    IEnumerator WeatherIndicator()
    {
        while (true)
        {
            Indicators.instance.coldSlider.value += ColdChang * Time.deltaTime;
            yield return null;
        }
    }
}
