using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class DetailsManager : MonoBehaviour
{
    public List<DetailsModel> detailsModel;
    public string path;
    
    void Start()
    {
        if (PlayerPrefs.HasKey("Details"))
        {
            if (PlayerPrefs.GetInt("Details") >= 1)
            {
                if (File.Exists(Application.persistentDataPath + "/" + path))
                {
                    AssetBundle assetBundle = AssetBundle.LoadFromFile(Application.persistentDataPath + "/" + path); 

                    for (int i = 0; i < detailsModel.Count; i++)
                    {
                        detailsModel[i].meshFilter.mesh = (Mesh)assetBundle.LoadAsset(detailsModel[i].detailsName);
                    }

                    assetBundle.UnloadAsync(false);
                }
            }
        }
    }
}
