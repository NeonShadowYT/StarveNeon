using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class MagazinManager : MonoBehaviour
{
    public TMP_Text diamondMoneyText;

    [Space]
    [Header("Магазин")]
    public GameObject TovarePrefs;
    public Transform TovareContent;

    [Space]
    [Header("Инвентарь")]
    public GameObject InventoryPrefs;
    public Transform InventoryContent;

    [Space]
    [Header("Все скины")]
    public List<ItemSkinScriptableObject> AllSkins;

    [Space]
    [Header("Купленные скины")]
    public List<ItemSkinScriptableObject> AllInventorySkins;
    public List<ItemSkinScriptableObject> AllActiveSkins;

    [Space]
    [Header("Все товары")]
    public List<SkinTovare> AllTovare;

    private void Start()
    {
        if (DataSaveLoad.instance.data.inventorySkin.Length != 0)
        {
            for (int i = 0; i < DataSaveLoad.instance.data.inventorySkin.Length; i++)
            {
                ItemSkinScriptableObject itemSkinScriptableObject = Resources.Load<ItemSkinScriptableObject>($"ItemSkinScriptableObject/{DataSaveLoad.instance.data.inventorySkin[i]}");

                AllInventorySkins.Add(itemSkinScriptableObject);
            }
        }

        if (DataSaveLoad.instance.data.currentSkin.Length != 0)
        {
            for (int i = 0; i < DataSaveLoad.instance.data.currentSkin.Length; i++)
            {
                ItemSkinScriptableObject itemSkinScriptableObject = Resources.Load<ItemSkinScriptableObject>($"ItemSkinScriptableObject/{DataSaveLoad.instance.data.currentSkin[i]}");

                AllActiveSkins.Add(itemSkinScriptableObject);
            }
        }

        GenerateTovare();

        diamondMoneyText.text = DataSaveLoad.instance.data.diamondValue.ToString();
    }

    public void GenerateTovare()
    {
        foreach (ItemSkinScriptableObject skin in AllSkins) // ��������� ��� �����
        {
            int skinBuy = 0;

            foreach (ItemSkinScriptableObject inventorySkin in AllInventorySkins) // ��������� ��� �����
            {
                if(skin == inventorySkin)
                {
                    skinBuy = 1;
                    break;
                }
            }

            if (skinBuy == 0)
            {
                SkinTovare skinTovare = Instantiate(TovarePrefs, TovareContent).GetComponent<SkinTovare>();

                skinTovare.magazinManager = this;

                skinTovare.itemSkinScriptableObject = skin;

                skinTovare.Icon.sprite = skin.Icon;
                skinTovare.Name.text = skin.Name;
                skinTovare.Price.text = skin.Price.ToString();

                skinTovare.Startap();

                AllTovare.Add(skinTovare);
            }
            else
            {
                SkinsInventoryItem skinsInventoryItem = Instantiate(InventoryPrefs, InventoryContent).GetComponent<SkinsInventoryItem>();

                skinsInventoryItem.magazinManager = this;

                skinsInventoryItem.itemSkinScriptableObject = skin;

                skinsInventoryItem.Image.sprite = skin.Icon;
                skinsInventoryItem.Name.text = skin.Name;

                foreach (ItemSkinScriptableObject active in AllActiveSkins) // ��������� ��� �����
                {
                    if (active == skin)
                    {
                        skinsInventoryItem.Enable.SetActive(true);
                        skinsInventoryItem.Disable.SetActive(false);
                    }
                    else
                    {
                        skinsInventoryItem.Enable.SetActive(false);
                        skinsInventoryItem.Disable.SetActive(true);
                    }
                }
            }
        }
    }

    public void UpdateTovare()
    {
        for (int i = 0; i < AllTovare.Count; i++)
        {
            AllTovare[i].Startap();
        }
    }

    public void AddDiamond(int amount)
    {
        DataSaveLoad.instance.data.diamondValue += amount;
        if (diamondMoneyText != null) diamondMoneyText.text = DataSaveLoad.instance.data.diamondValue.ToString();
        
        UpdateTovare();
    }
}
