using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using System.IO;
using TMPro;

public class BundleInfo : MonoBehaviour
{
    public LoadAssetBundles loadAssetBundles;
    public BundlePreset bundlePreset;

    [HideInInspector]
    public AssetBundle assetBundle;

    [Space]
    [Header("Интерфейс")]
    public Image bundleImage;
    public TMP_Text bundleText;

    public Button bundleButton;
    public TMP_Text buttonText;

    public Slider bundleSlider;
    public TMP_Text progressText;

    void Start()
    {
        InfoBundle();
        LoadBundle();
    }

    public void LoadBundle()
    {
        string path = Application.persistentDataPath + "/" + bundlePreset.codeName;

        if (!File.Exists(path))
        {
            bundlePreset.install = false;
            bundleButton.gameObject.SetActive(true);
        }
        else
        {
            bundlePreset.install = true;
            bundleButton.gameObject.SetActive(true);

            buttonText.text = "Включено";
        }
    }

    void InfoBundle()
    {
        bundleImage.sprite = bundlePreset.bundleIcon;
        bundleText.text = bundlePreset.bundleName;

        switch (Application.platform)
        {
            case RuntimePlatform.WindowsEditor :
                bundlePreset.bundleUrl = bundlePreset.windowsUrl;
                break;
            case RuntimePlatform.WindowsPlayer :
                bundlePreset.bundleUrl = bundlePreset.windowsUrl;
                break;
            case RuntimePlatform.Android :
                bundlePreset.bundleUrl = bundlePreset.androidUrl;
                break;
            default:
                bundlePreset.bundleUrl = "";
                break;
        }
    }

    void UpdateBandle()
    {
        if (bundlePreset.update == false) return;

        bundleButton.gameObject.SetActive(false);
        bundleSlider.gameObject.SetActive(true);
        progressText.text = "0";

        string path = Application.persistentDataPath + "/" + bundlePreset.codeName;
        DirectoryInfo directory = new DirectoryInfo(path);

        directory.Delete(true);
        loadAssetBundles.Download(bundlePreset, this);
    }

    public void DownloadBandle()
    {
        if (bundlePreset.install == true) return;

        bundleButton.gameObject.SetActive(false);
        bundleSlider.gameObject.SetActive(true);
        progressText.text = "0";

        loadAssetBundles.Download(bundlePreset, this);
    }
}

[System.Serializable]
public class BundlePreset
{
    [Space]
    [Header("Визуал")]
    public Sprite bundleIcon;
    public string bundleName;

    [Space]
    [Header("Параметры")]
    public string codeName;

    [Space]
    public string bundleUrl;
    public string windowsUrl;
    public string androidUrl;

    [Space]
    [Header("Статус")]
    public bool install;
    public bool update;
}