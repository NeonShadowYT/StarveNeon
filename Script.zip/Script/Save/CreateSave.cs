using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class CreateSave : MonoBehaviour
{
    private AuthenticationManager authManager;

    [Space]
    [Header("Основное")]
    public TMP_InputField versionField;
    public TMP_InputField codeField;
    public TMP_InputField nameField;
    public TMP_InputField passwordField;
    public TMP_InputField friendField;
    public TMP_InputField promoField;

    [Space]
    [Header("Индикаторы")]
    public TMP_InputField healthField;
    public TMP_InputField foodField;
    public TMP_InputField waterField;
    public TMP_InputField coldField;

    [Space]
    [Header("Геймплей")]
    public TMP_InputField levelField;
    public TMP_InputField storyField;
    public TMP_InputField scoreField;
    public TMP_InputField skinField;
    public TMP_InputField skinsField;
    public TMP_InputField geneField;
    public TMP_InputField craftField;

    [Space]
    [Header("Вылазка")]
    public TMP_InputField biomField;
    public TMP_InputField stolyresField;
    public TMP_InputField complexityField;
    public TMP_InputField modeField;

    [Space]
    [Header("Предметы")]
    public TMP_InputField itemField;
    public TMP_InputField amountField;
    public TMP_InputField durabilityField;
    public TMP_InputField destroyField;
    public TMP_InputField modificationField;
    public TMP_InputField positionField;

    [Space]
    [Header("Монеты")]
    public TMP_InputField texnoField;
    public TMP_InputField bioField;
    public TMP_InputField ksenoField;
    public TMP_InputField craiperField;
    public TMP_InputField oberField;
    public TMP_InputField stasyField;
    public TMP_InputField woodField;
    public TMP_InputField rockField;
    public TMP_InputField cuprumField;
    public TMP_InputField goldenField;
    public TMP_InputField diamondField;
    public TMP_InputField ametistField;
    public TMP_InputField reditField;
    public TMP_InputField izumField;
    public TMP_InputField coreField;
    public TMP_InputField neolitField;

    [Space]
    [Header("Репутация")]
    public TMP_InputField reputationField;
    public TMP_InputField ksenoRepField;
    public TMP_InputField craiperRepField;
    public TMP_InputField oberRepField;
    public TMP_InputField stasyRepField;

    [Space]
    [Header("Пасс")]
    public TMP_InputField passField;
    public TMP_InputField levelPassField;
    public TMP_InputField powerField;
    public TMP_InputField completPassField;

    [Space]
    [Header("Достяжения")]
    public TMP_InputField completField;
    public TMP_InputField rewardField;

    [Space]
    [Header("Интерфейс")]
    public Button compliteButton;
    public TMP_Text debugText;

    private string error;

    void Start()
    {
        authManager = FindObjectOfType<AuthenticationManager>();
    }
    
    public void OnSave()
    {
        debugText.text = "Сохранение повреждено";
        versionField.text = DataSaveLoad.instance.data.saveVersion.ToString();
        codeField.text = DataSaveLoad.instance.data.playerId.ToString();
        nameField.text = DataSaveLoad.instance.data.playerNick.ToString();
        passwordField.text = DataSaveLoad.instance.data.playerPassword.ToString();
        friendField.text = DataSaveLoad.instance.data.friends.ToString();

        for (int i = 0; i < DataSaveLoad.instance.data.activePromo.Length; i++)
        {
            promoField.text += DataSaveLoad.instance.data.activePromo[i].ToString();
        }

        healthField.text = DataSaveLoad.instance.data.health.ToString();
        foodField.text = DataSaveLoad.instance.data.food.ToString();
        waterField.text = DataSaveLoad.instance.data.water.ToString();
        coldField.text = DataSaveLoad.instance.data.cold.ToString();

        levelField.text = DataSaveLoad.instance.data.playerLvl.ToString();
        storyField.text = DataSaveLoad.instance.data.playerStoryLvl.ToString();
        scoreField.text = DataSaveLoad.instance.data.playerScore.ToString();

        for (int i = 0; i < DataSaveLoad.instance.data.currentSkin.Length; i++)
        {
            skinField.text += DataSaveLoad.instance.data.currentSkin[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.inventorySkin.Length; i++)
        {
            skinsField.text += DataSaveLoad.instance.data.inventorySkin[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.genNames.Length; i++)
        {
            geneField.text += DataSaveLoad.instance.data.genNames[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.allCrafts.Length; i++)
        {
            craftField.text += DataSaveLoad.instance.data.allCrafts[i].ToString();
        }

        biomField.text = DataSaveLoad.instance.data.biom.ToString();
        stolyresField.text = DataSaveLoad.instance.data.stolyres.ToString();
        complexityField.text = DataSaveLoad.instance.data.complexity.ToString();

        for (int i = 0; i < DataSaveLoad.instance.data.modiferValue.Length; i++)
        {
            modeField.text += DataSaveLoad.instance.data.modiferValue[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.itemNames.Length; i++)
        {
            if (!string.IsNullOrEmpty(DataSaveLoad.instance.data.itemNames[i]))
            {
                itemField.text += DataSaveLoad.instance.data.itemNames[i].ToString();
            }
        }

        for (int i = 0; i < DataSaveLoad.instance.data.itemAmounts.Length; i++)
        {
            amountField.text += DataSaveLoad.instance.data.itemAmounts[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.itemDurability.Length; i++)
        {
            durabilityField.text += DataSaveLoad.instance.data.itemDurability[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.itemDestroy.Length; i++)
        {
            destroyField.text += DataSaveLoad.instance.data.itemDestroy[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.itemModifer.Length; i++)
        {
            modificationField.text += DataSaveLoad.instance.data.itemModifer[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.itemPosition.Length; i++)
        {
            positionField.text += DataSaveLoad.instance.data.itemPosition[i].ToString();
        }

        texnoField.text = DataSaveLoad.instance.data.texnoAmount.ToString();
        bioField.text = DataSaveLoad.instance.data.bioAmount.ToString();
        ksenoField.text = DataSaveLoad.instance.data.ksenoAmount.ToString();
        craiperField.text = DataSaveLoad.instance.data.goldenAmount.ToString();
        oberField.text = DataSaveLoad.instance.data.oborotAmount.ToString();
        stasyField.text = DataSaveLoad.instance.data.stasyAmount.ToString();
        woodField.text = DataSaveLoad.instance.data.woodValue.ToString();
        rockField.text = DataSaveLoad.instance.data.rockValue.ToString();
        cuprumField.text = DataSaveLoad.instance.data.cuprumValue.ToString();
        goldenField.text = DataSaveLoad.instance.data.goldValue.ToString();
        diamondField.text = DataSaveLoad.instance.data.diamondValue.ToString();
        ametistField.text = DataSaveLoad.instance.data.ametistValue.ToString();
        reditField.text = DataSaveLoad.instance.data.reditValue.ToString();
        izumField.text = DataSaveLoad.instance.data.izumValue.ToString();
        coreField.text = DataSaveLoad.instance.data.coreValue.ToString();
        neolitField.text = DataSaveLoad.instance.data.neolitValue.ToString();

        reputationField.text = DataSaveLoad.instance.data.playerRep.ToString();
        ksenoRepField.text = DataSaveLoad.instance.data.ksenoRepAmount.ToString();
        craiperRepField.text = DataSaveLoad.instance.data.goldenRepAmount.ToString();
        oberRepField.text = DataSaveLoad.instance.data.oborotRepAmount.ToString();
        stasyRepField.text = DataSaveLoad.instance.data.stasyRepAmount.ToString();

        passField.text = DataSaveLoad.instance.data.passName.ToString();
        levelPassField.text = DataSaveLoad.instance.data.passLvl.ToString();
        powerField.text = DataSaveLoad.instance.data.passPower.ToString();
        
        for (int i = 0; i < DataSaveLoad.instance.data.passComplite.Length; i++)
        {
            completPassField.text += DataSaveLoad.instance.data.passComplite[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.progressAchievement.Length; i++)
        {
            completField.text += DataSaveLoad.instance.data.progressAchievement[i].ToString();
        }

        for (int i = 0; i < DataSaveLoad.instance.data.rewardAchievement.Length; i++)
        {
            rewardField.text += DataSaveLoad.instance.data.rewardAchievement[i].ToString();
        }

        debugText.text = "Сохранение не повреждено";

        if (passwordField.text != "")
        {
            authManager.SignIn(passwordField.text, debugText);
            authManager.GetID(codeField);
        }
    }

    public void OnCompliteSave()
    {
        if (debugText.text == "Сохранение повреждено")
        {
            BinarySavingSystem.DeleteSave();
        }

        if (passwordField.text != "")
        {
            authManager.GetID(codeField);

            if (codeField.text == "")
            {
                authManager.SignIn(passwordField.text, debugText);
                debugText.text = "Попробуй снова или проверь данные";
                return;
            }
        }

        DataSaveLoad.instance.data.saveVersion = Application.version;
        DataSaveLoad.instance.data.playerId = codeField.text;
        DataSaveLoad.instance.data.playerNick = nameField.text;
        DataSaveLoad.instance.data.playerPassword = passwordField.text;

        Promo.instance.CheckPromo();
        DataSaveLoad.instance.data.biom = "База";

        DataSaveLoad.instance.Save();
        SceneManager.LoadScene(DataSaveLoad.instance.data.biom);
    }
}
