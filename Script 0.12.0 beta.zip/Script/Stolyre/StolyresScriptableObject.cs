using UnityEngine;

[CreateAssetMenu(fileName = "Stolyres", menuName = "Neon Imperium/Stolyres/New Stolyres")]
public class StolyresScriptableObject : ScriptableObject
{
    public Sprite image;
    public string Description;
}
