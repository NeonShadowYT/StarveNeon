using UnityEngine;
using UnityEngine.UI;
using Photon.Realtime;
using TMPro;

public class RoomListItem : MonoBehaviour
{
    public TMP_Text roomName;

    public RoomInfo info;

    public Launcher launcher;

    public void SetUp(RoomInfo roomInfo)
    {
        info = roomInfo;

        roomName.text = info.Name;
    }

    public void OnClick()
    {
        launcher.JoinRoom(info);
    }
}
