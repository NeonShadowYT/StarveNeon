using System.Collections.Generic;
using UnityEngine.Networking;
using System.Collections;
using UnityEngine.UI;
using UnityEngine;
using System.IO;
using TMPro;

public class LoadAssetBundles : MonoBehaviour
{
    [Space]
    [Header("Все бандлы")]
    public List<BundleInfo> bundleInfo;

    public void Download(BundlePreset preset, BundleInfo bundleInfo)
    {
        if (preset.bundleUrl == "")
        {
            bundleInfo.bundleSlider.gameObject.SetActive(false);
            bundleInfo.bundleButton.gameObject.SetActive(true);
            bundleInfo.buttonText.text = "Нет поддержки";
            return;
        }

        if(Application.internetReachability != NetworkReachability.NotReachable) 
        {
            StartCoroutine(DownloadBundle(preset, bundleInfo));
        }
        else
        {
            bundleInfo.bundleSlider.gameObject.SetActive(false);
            bundleInfo.bundleButton.gameObject.SetActive(true);
            bundleInfo.buttonText.text = "Подключитесь";
        }
    }

    IEnumerator DownloadBundle(BundlePreset preset, BundleInfo bundleInfo)
    {
        UnityWebRequest uwr = new UnityWebRequest(preset.bundleUrl);
        uwr.downloadHandler = new DownloadHandlerBuffer();

        while (!uwr.isDone)
        {
            bundleInfo.bundleSlider.value = uwr.downloadProgress * 100;
            bundleInfo.progressText.text = bundleInfo.bundleSlider.value.ToString();
            yield return new WaitForSeconds(0.1f);
        }
        
        bundleInfo.bundleSlider.value = uwr.downloadProgress * 100;
        bundleInfo.progressText.text = bundleInfo.bundleSlider.value.ToString();

        if (!string.IsNullOrEmpty(uwr.error))
        {
            Debug.Log(uwr.error);
            bundleInfo.bundleSlider.gameObject.SetActive(false);
            bundleInfo.bundleButton.gameObject.SetActive(true);
            bundleInfo.buttonText.text = "Ошибка";
            yield break;
        }
        
		byte[] bytes = uwr.downloadHandler.data;
		File.WriteAllBytes(Application.persistentDataPath + "/" + preset.codeName, bytes);

        preset.install = true;

        bundleInfo.bundleSlider.gameObject.SetActive(false);
        bundleInfo.bundleSlider.value = 0f;
        bundleInfo.progressText.text = "0";

        uwr.Dispose();
        bundleInfo.LoadBundle();
    }
}