﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// IPointerDownHandler - Следит за нажатиями мышки по объекту на котором висит этот скрипт
/// IPointerUpHandler - Следит за отпусканием мышки по объекту на котором висит этот скрипт
/// IDragHandler - Следит за тем не водим ли мы нажатую мышку по объекту
public class DragAndDropItem : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Cлот")]
    public InventorySlot oldSlot;

    private Image slotImage;
    private Transform player;
    private Transform mTransform;
    private Transform oldSlotTransform;

    private void Start()
    {
        player = CustomCharacterController.instance.mTransform;
        oldSlotTransform = oldSlot.transform;
        mTransform = transform;

        slotImage = oldSlot.iconGO;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (oldSlot.item == null) return; // Если слот пустой, то мы не выполняем то что ниже return;
        
        mTransform.position += new Vector3(eventData.delta.x, eventData.delta.y);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (oldSlot.item == null) return; // Если слот пустой, то мы не выполняем то что ниже return;

        slotImage.color = new Color(1, 1, 1, 0.75f); //Делаем картинку прозрачнее
        slotImage.raycastTarget = false; // Делаем так чтобы нажатия мышкой игнорировало картинку

        mTransform.SetParent(mTransform.parent.parent.parent); // Делаем наш DraggableObject ребенком InventoryPanel чтобы DraggableObject был над другими слотами инвенторя
        mTransform.position = oldSlotTransform.position;

        InventoryManager.instance.audioSource.volume = Random.Range(0.2f, 0.4f);
        InventoryManager.instance.audioSource.pitch = Random.Range(0.8f, 1.2f);

        InventoryManager.instance.audioSource.PlayOneShot(oldSlot.item.itemAudio);
        QuickslotInventory.instance.MobailDragSlot(oldSlot.gameObject);
        InventoryManager.instance.DetailsItemView(oldSlot.item, oldSlot.amount, this);
    }

    public void ReturnBackToSlot()
    {
        if (oldSlot.item == null) return; // Если слот пустой, то мы не выполняем то что ниже return;

        slotImage.color = new Color(1, 1, 1, 1f); // Делаем картинку опять не прозрачной
        slotImage.raycastTarget = true; // И чтобы мышка опять могла ее засечь

        mTransform.SetParent(oldSlotTransform); //Поставить DraggableObject обратно в свой старый слот
        mTransform.position = oldSlotTransform.position;

        InventoryManager.instance.audioSource.volume = Random.Range(0.2f, 0.4f);
        InventoryManager.instance.audioSource.pitch = Random.Range(0.8f, 1.2f);

        InventoryManager.instance.audioSource.PlayOneShot(oldSlot.item.itemAudio);
        InventoryManager.instance.detailsPanel.SetActive(false);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (oldSlot.item == null)
        {
            return; // Если слот пустой, то мы не выполняем то что ниже return;
        }

        slotImage.color = new Color(1, 1, 1, 1f); // Делаем картинку опять не прозрачной
        slotImage.raycastTarget = true; // И чтобы мышка опять могла ее засечь

        mTransform.SetParent(oldSlotTransform); //Поставить DraggableObject обратно в свой старый слот
        mTransform.position = oldSlotTransform.position; //Если мышка отпущена над объектом по имени UIPanel, то...

        InventoryManager.instance.audioSource.volume = Random.Range(0.2f, 0.4f);
        InventoryManager.instance.audioSource.pitch = Random.Range(0.8f, 1.2f);

        InventoryManager.instance.audioSource.PlayOneShot(oldSlot.item.itemAudio);

        if (eventData.pointerCurrentRaycast.gameObject == null)
        {
            DropItems();
            return;
        }

        InventorySlot inventorySlot = eventData.pointerCurrentRaycast.gameObject.transform.parent.parent.GetComponent<InventorySlot>();

        if (inventorySlot != null)
        {
            if (inventorySlot.clothType != ClothType.None) //Перемещаем данные из одного слота в другой
            {
                if (inventorySlot.clothType == oldSlot.item.clothType)
                {
                    ExchangeSlotData(inventorySlot);
                    ClothAdder.instance.UpdateClothes();
                }
                else return;
            }
            else
            {
                ExchangeSlotData(inventorySlot);

                if (oldSlot.clothType != ClothType.None) ClothAdder.instance.UpdateClothes();
            }

            if (oldSlot.amount <= 0) 
            {
                InventoryManager.instance.detailsPanel.SetActive(false);

                NullifySlotData();
                StorageDropUpdate();

                if (oldSlot.clothType != ClothType.None) ClothAdder.instance.UpdateClothes();
            }
        }

        QuickslotInventory.instance.CheckItemInHand();
    }

    public void DropItems()
    {
        InventoryManager.instance.detailsPanel.SetActive(false);
        InventoryManager.instance.craftView.SetActive(false);
        InventoryManager.instance.chatPanel.SetActive(true);

        Item dropItem = Instantiate(oldSlot.item.itemPrefab, player.position + Vector3.up + player.forward, Quaternion.identity).GetComponent<Item>(); // Выброс объектов из инвентаря - Спавним префаб обекта перед персонажем

        dropItem.durability = oldSlot.durability;
        dropItem.destroy = oldSlot.destroyBar.fillAmount;
        
        if (Input.GetKey(KeyCode.LeftShift) && oldSlot.amount > 1)
        {
            dropItem.amount = Mathf.CeilToInt((float)oldSlot.amount / 2f);
            oldSlot.amount /= 2;
        }
        else if (Input.GetKey(KeyCode.LeftControl) && oldSlot.amount > 1)
        {
            dropItem.amount = 1;
            oldSlot.amount--;
        }
        else
        {
            dropItem.amount = oldSlot.amount;
            NullifySlotData(); // убираем значения InventorySlot
        }

        QuickslotInventory.instance.CheckItemInHand();
        StorageDropUpdate();

        if (oldSlot.clothType != ClothType.None) 
        {
            ClothAdder.instance.UpdateClothes();
        }
    }

    public void NullifySlotData() // made public 
    {
        oldSlot.item = null; // убираем значения InventorySlot
        oldSlot.amount = 0;
        oldSlot.durability = 0f;
        oldSlot.durabilityBar.fillAmount = 0f;
        oldSlot.destroyBar.fillAmount = 0f;
    }

    void ExchangeSlotData(InventorySlot newSlot)
    {
        if (newSlot == oldSlot)
        {
            ReturnBackToSlot();
            return;
        }

        InventoryManager.instance.detailsPanel.SetActive(false);
        ItemScriptableObject item = newSlot.item; // Временно храним данные newSlot в отдельных переменных

        int amount = newSlot.amount;
        float durability = newSlot.durability;
        float itemDestroy = newSlot.destroyBar.fillAmount;
        
        if (item == null)
        {
            if (oldSlot.item.maximumAmount > 1 && oldSlot.amount > 1)
            {
                if (Input.GetKey(KeyCode.LeftShift))
                {
                    newSlot.item = oldSlot.item;
                    newSlot.amount = Mathf.CeilToInt((float)oldSlot.amount / 2f);

                    oldSlot.amount /= 2;
                    StorageUpdate(newSlot);
                    return;
                }
                else if (Input.GetKey(KeyCode.LeftControl))
                {
                    newSlot.item = oldSlot.item;
                    newSlot.amount = 1;

                    oldSlot.amount--;
                    StorageUpdate(newSlot);
                    return;
                }
            }
        }
        else
        {
            if (oldSlot.clothType != ClothType.None && item.clothType == ClothType.None)
            {
                ReturnBackToSlot();
                return;
            }

            if (oldSlot.item == newSlot.item)
            {
                if (Input.GetKey(KeyCode.LeftShift) && oldSlot.amount > 1)
                {
                    if (Mathf.CeilToInt((float)oldSlot.amount / 2f) < newSlot.item.maximumAmount - newSlot.amount)
                    {
                        newSlot.amount += Mathf.CeilToInt((float)oldSlot.amount / 2f);
                        oldSlot.amount /= 2;

                        StorageUpdate(newSlot);
                    }
                    else
                    {
                        oldSlot.amount -= newSlot.item.maximumAmount - newSlot.amount;
                        newSlot.amount = newSlot.item.maximumAmount;

                        StorageUpdate(newSlot);
                    }

                    return;
                }
                else if (Input.GetKey(KeyCode.LeftControl) && oldSlot.amount > 1)
                {
                    if (newSlot.item.maximumAmount != newSlot.amount)
                    {
                        newSlot.amount++;
                        oldSlot.amount--;

                        StorageUpdate(newSlot);
                    }

                    return;
                }
                else
                {
                    if (newSlot.amount + oldSlot.amount >= newSlot.item.maximumAmount)
                    {
                        int difference = newSlot.item.maximumAmount - newSlot.amount;
                        newSlot.amount = newSlot.item.maximumAmount;

                        oldSlot.amount -= difference;
                        StorageUpdate(newSlot);
                    }
                    else
                    {
                        newSlot.amount += oldSlot.amount;

                        NullifySlotData();
                        StorageUpdate(newSlot);
                    }

                    return;
                }
            }
        }

        newSlot.item = oldSlot.item; // Заменяем значения newSlot на значения oldSlot
        newSlot.amount = oldSlot.amount;
        newSlot.durability = oldSlot.durability;
        newSlot.destroyBar.fillAmount = oldSlot.destroyBar.fillAmount;

        oldSlot.item = item; // Заменяем значения oldSlot на значения newSlot сохраненные в переменных
        oldSlot.amount = amount;
        oldSlot.durability = durability;
        oldSlot.destroyBar.fillAmount = itemDestroy;

        StorageUpdate(newSlot);
    }

    public void StorageDropUpdate()
    {
        if (oldSlot.slotType == SlotType.Storage)
        {
            for (int i = 0; i < StorageManager.instance.currentStorage.slots.Count; i++)
            {
                if (StorageManager.instance.storageSlots[i] == oldSlot || InventoryManager.instance.slots[i] == oldSlot)
                {
                    if (oldSlot.amount <= 0)
                    {
                        StorageManager.instance.currentStorage.slots[i].item = null;
                        StorageManager.instance.currentStorage.slots[i].amount = 0;
                    }
                    else
                    {
                        StorageManager.instance.currentStorage.slots[i].item = oldSlot.item;
                        StorageManager.instance.currentStorage.slots[i].amount = oldSlot.amount;
                    }
                    break;
                }
            }
        }
    }

    public void StorageUpdate(InventorySlot newSlot)
    {
        if (newSlot.slotType == SlotType.Storage || oldSlot.slotType == SlotType.Storage)
        {
            for (int i = 0; i < StorageManager.instance.currentStorage.slots.Count; i++)
            {
                if (StorageManager.instance.storageSlots[i] == newSlot || InventoryManager.instance.slots[i] == newSlot)
                {
                    StorageManager.instance.currentStorage.slots[i].item = newSlot.item;
                    StorageManager.instance.currentStorage.slots[i].amount = newSlot.amount;
                    break;
                }
                else if (StorageManager.instance.storageSlots[i] == oldSlot || InventoryManager.instance.slots[i] == oldSlot)
                {
                    StorageManager.instance.currentStorage.slots[i].item = oldSlot.item;
                    StorageManager.instance.currentStorage.slots[i].amount = oldSlot.amount;
                    break;
                }
            }
        }
    }
}