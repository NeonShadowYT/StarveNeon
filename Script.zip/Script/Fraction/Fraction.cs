using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;

public class Fraction : MonoBehaviour
{
    [Space]
    [Header("Фракция")]
    public FractionScriptableObject MyFraction;

    [Space]
    public GameObject[] spawnerNps;

    [Space]
    [Header("Данные")]
    public int currentLvl = 1;
    public int currentDay = 1;
    public GameObject currentFractionObj;

    public List<FractionUpdate> fractionUpdate;

    [Space]
    [Header("Все нпс")]
    public List<FractionNPS> fractionNps = new List<FractionNPS>();

    public void Start()
    {
        FractionManager.instance.allBiomFraction.Add(this);

        foreach (GameObject spawner in spawnerNps)
        {
            fractionNps.AddRange(spawner.GetComponentsInChildren<FractionNPS>()); //��������� ���� ���
        }

        foreach (FractionUpdate fractup in fractionUpdate)
        {
            fractup.NewFractionObj.SetActive(false); // �������� ����������� ����

            if (fractup.Lvl <= currentLvl) 
            {
                fractionUpdate.Remove(fractup);
            }
        }

        foreach (FractionNPS fractNps in fractionNps)
        {
            fractNps.myFraction = this;

            if (fractNps.aIManager.navMeshAgent == null)
            {
                fractNps.aIManager.navMeshAgent = fractNps.gameObject.GetComponent<NavMeshAgent>();
            }

            fractNps.Startnps();
        }
    }

    public void UpdateFractChek(int day)
    {
        currentDay = day;

        for (int i = 0; i < fractionUpdate.Count; i++)
        {
            if (fractionUpdate[i].Lvl <= currentLvl) 
            {
                fractionUpdate.Remove(fractionUpdate[i]);
                return;
            }

            if (fractionUpdate[i].DayUpdate <= currentDay)
            {
                UpdateLvlFract(fractionUpdate[i]);
            }
        }
    }

    public void UpdateLvlFract(FractionUpdate fractup)
    {
        currentFractionObj.SetActive(false);
        fractup.NewFractionObj.SetActive(true);

        currentFractionObj = fractup.NewFractionObj;
        currentLvl = fractup.Lvl;

        fractionUpdate.Remove(fractup);

        UpdateFractChek(currentDay);
    }
}

[System.Serializable]
public class FractionUpdate
{
    [Space]
    [Header("Инфа улучшения")]
    public int Lvl;
    public int DayUpdate;

    public GameObject NewFractionObj;
}