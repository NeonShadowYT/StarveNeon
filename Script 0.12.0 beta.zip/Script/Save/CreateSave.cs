using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CreateSave : MonoBehaviour
{
    public DataSaveLoad dataSaveLoad;
    public SceneTransition sceneTransition;
    public Promo promo;

    private AuthenticationManager authManager;

    [Space]
    public TMP_Text idText;
    public TMP_InputField nameField;
    public TMP_InputField passwordField;

    [Space]
    public Button compliteButton;
    public TMP_Text debugText;

    void Start()
    {
        authManager = FindObjectOfType<AuthenticationManager>();
    }
    
    public void OnSave()
    {
        nameField.text = dataSaveLoad.data.playerNick;
        passwordField.text = dataSaveLoad.data.playerPassword;
        
        if (passwordField.text != "")
        {
            authManager.SignIn(passwordField.text, debugText);
            OnCompliteSave();
        }
        else 
        {
            debugText.text = "Пустой пароль";
            return;
        }
    }

    public void OnCompliteSave()
    {
        authManager.GetID(idText);

        if (idText.text == "")
        {
            authManager.SignIn(passwordField.text, debugText);
            debugText.text = "Попробуй снова или проверь данные";
            return;
        }

        dataSaveLoad.data.saveVersion = Application.version;
        dataSaveLoad.data.playerId = idText.text;
        dataSaveLoad.data.playerNick = nameField.text;
        dataSaveLoad.data.playerPassword = passwordField.text;

        promo.CheckPromo();
        dataSaveLoad.Save();

        sceneTransition.SwitchToScene("База");
    }
}
