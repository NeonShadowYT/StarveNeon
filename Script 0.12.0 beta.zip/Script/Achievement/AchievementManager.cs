using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AchievementManager : MonoBehaviour
{
    [Space]
    public List<AchievementScriptableObject> achievementScriptableObject;

    [HideInInspector]
    public List<AchievementItem> achievementItem;

    [Space]
    public RegistrProgress registrProgress;
    public DataSaveLoad dataSaveLoad;

    [Space]
    public GameObject AchievementPrefab;
    public Transform Content;

    void Start()
    {
        foreach (AchievementScriptableObject achievementScriptable in achievementScriptableObject) // ��������� ��� ������
        {
            AchievementItem achievement = Instantiate(AchievementPrefab, Content).GetComponent<AchievementItem>();
            achievementItem.Add(achievement);

            achievement.achievementScriptableObject = achievementScriptable;
            achievement.achievementIcon.sprite = achievementScriptable.achievementIcon;
            achievement.achievementText.text = achievementScriptable.name;

            achievement.rewardIcon.sprite = achievementScriptable.rewardIcon;
            achievement.rewardText.text = achievementScriptable.rewardAmount.ToString();

            achievement.sliderProgress.maxValue = achievementScriptable.progressAmount;
            achievement.sliderProgress.value = 0;

            achievement.claimProgress = false;
            achievement.achievementManager = this;
        }

        registrProgress = FindObjectOfType<RegistrProgress>();

        Load();
    }

    public void Load()
    {
        for (int i = 0; i < dataSaveLoad.data.nameAchievement.Length; i++)
        {
            AchievementScriptableObject achievementScriptableObject = Resources.Load<AchievementScriptableObject>($"AchievementScriptableObject/{dataSaveLoad.data.nameAchievement[i]}");

            achievementItem[i].sliderProgress.value = dataSaveLoad.data.progressAchievement[i];
            achievementItem[i].claimProgress = dataSaveLoad.data.rewardAchievement[i];

            if(achievementItem[i].sliderProgress.value >= achievementItem[i].sliderProgress.maxValue)
            {
                achievementItem[i].buttonAchievement.interactable = true;
            }
            else
            {
                achievementItem[i].buttonAchievement.interactable = false;
            }
        }
    }
}