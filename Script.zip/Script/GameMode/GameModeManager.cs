using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameModeManager : MonoBehaviour
{
    [Space]
    [Header("Инфа")]
    public List<GameObject> Nobj;
    public List<GameObject> Ultimateobj;

    public GameObject RouSpawner;
    public GameObject MoreResoursSpawner;
    public GameObject PlantsExpanded;

    public GameObject MediSet;
    public GameObject OberSet;

    public bool NobjForDay;
    public bool MobUpdater;

    [Space]
    [Header("Настройки")]
    public List<GameSettingsItem> SettingsList;

    public void Start()
    {
        foreach (GameObject Ultimate in Ultimateobj) Ultimate.SetActive(false);
        foreach (GameObject Nobj in Nobj) Nobj.SetActive(false);

        NobjForDay = false;
        MobUpdater = false;

        if (RouSpawner != null) RouSpawner.SetActive(false);
        if (MoreResoursSpawner != null) MoreResoursSpawner.SetActive(false);
        if (PlantsExpanded != null) PlantsExpanded.SetActive(false);

        if (OberSet != null) OberSet.SetActive(false);
        if (MediSet != null) MediSet.SetActive(false);

        Load();
    }

    public void Load()
    {
        for (int i = 0; i < DataSaveLoad.instance.data.modiferValue.Length; i++)
        {
            SettingsList[i].active = DataSaveLoad.instance.data.modiferValue[i];
        }
    }
}