using UnityEngine;

public class AudioStep : MonoBehaviour
{
    [Space]
    public CustomCharacterController customCharacterController;
    public AudioSource audioSrc;

    [Space]
    public AudioClip[] GroundStep;
    public AudioClip[] RockStep;
    public AudioClip[] SandStep;
    public AudioClip[] SnowStep;
    public AudioClip[] WaterStep;
    public AudioClip[] MetalStep;
    public AudioClip[] TrubaStep;
    public AudioClip[] GravieStep;
    public AudioClip[] TreeStep;
    public AudioClip[] KoverStep;
    public AudioClip[] SlimeStep;

    [Space]
    public AudioClip[] GroundRun;
    public AudioClip[] RockRun;
    public AudioClip[] SandRun;
    public AudioClip[] SnowRun;
    public AudioClip[] WaterRun;
    public AudioClip[] MetalRun;
    public AudioClip[] TrubaRun;
    public AudioClip[] GravieRun;
    public AudioClip[] TreeRun;
    public AudioClip[] KoverRun;
    public AudioClip[] SlimeRun;

    void Start()
    {
        if (customCharacterController == null) customCharacterController = GetComponent<CustomCharacterController>();
    }

    public void AudioStepManager()
    { 
        if (customCharacterController.CanJump == false && customCharacterController.indicators.waterEffect.infinity == false) return;

        audioSrc.pitch = Random.Range(0.95f, 1.05f);

        if (customCharacterController.run == true)
        {
            audioSrc.volume = Random.Range(0.35f, 0.45f);

            switch (customCharacterController.stepId[0])
            {
                case "Земля":
                    audioSrc.PlayOneShot(GroundRun[Random.Range(0, GroundRun.Length)]);
                    break;
                case "Заражение":
                    audioSrc.PlayOneShot(GroundRun[Random.Range(0, GroundRun.Length)]);
                    break;
                case "Ад":
                    audioSrc.PlayOneShot(RockRun[Random.Range(0, RockRun.Length)]);
                    break;
                case "Камень":
                    audioSrc.PlayOneShot(RockRun[Random.Range(0, RockRun.Length)]);
                    break;
                case "Песок":
                    audioSrc.PlayOneShot(SandRun[Random.Range(0, SandRun.Length)]);
                    break;
                case "Cнег":
                    audioSrc.PlayOneShot(SnowRun[Random.Range(0, SnowRun.Length)]);
                    break;
                case "Дерево":
                    audioSrc.PlayOneShot(TreeRun[Random.Range(0, TreeRun.Length)]);
                    break;
                case "Вода":
                    audioSrc.PlayOneShot(WaterRun[Random.Range(0, WaterRun.Length)]);
                    break;
            }
        }
        else 
        {
            audioSrc.volume = Random.Range(0.25f, 0.35f);

            switch (customCharacterController.stepId[0])
            {
                case "Земля":
                    audioSrc.PlayOneShot(GroundStep[Random.Range(0, GroundStep.Length)]);
                    break;
                case "Заражение":
                    audioSrc.PlayOneShot(GroundStep[Random.Range(0, GroundStep.Length)]);
                    break;
                case "Ад":
                    audioSrc.PlayOneShot(RockStep[Random.Range(0, RockStep.Length)]);
                    break;
                case "Камень":
                    audioSrc.PlayOneShot(RockStep[Random.Range(0, RockStep.Length)]);
                    break;
                case "Песок":
                    audioSrc.PlayOneShot(SandStep[Random.Range(0, SandStep.Length)]);
                    break;
                case "Cнег":
                    audioSrc.PlayOneShot(SnowStep[Random.Range(0, SnowStep.Length)]);
                    break;
                case "Дерево":
                    audioSrc.PlayOneShot(TreeStep[Random.Range(0, TreeStep.Length)]);
                    break;
                case "Вода":
                    audioSrc.PlayOneShot(WaterStep[Random.Range(0, WaterStep.Length)]);
                    break;
            }
        }
    }
}
