using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Tovare : MonoBehaviour
{
    [Space]
    [Header("Данные")]
    public ItemScriptableObject item;
    private MoneySlot currentMoneySlot;

    public int price;

    public Image iconItem;
    public TMP_Text priceText;
    public TMP_Text itemText;

    public Button ButtonTovare;

    public void UpdateTovare(MoneySlot moneySlot)
    {
        currentMoneySlot = moneySlot;
        iconItem.sprite = item.icon;
        priceText.text = price.ToString();
        itemText.text = item.itemName;

        if (currentMoneySlot.amount >= price) ButtonTovare.interactable = true;
        else ButtonTovare.interactable = false;
    }

    public void Buy()
    {
        if (currentMoneySlot.amount >= price)
        {
            currentMoneySlot.amount -= price;
            InventoryManager.instance.AddItem(null, item, 1, item.maximumDurability, 0f);
        }
        
        UpdateTovare(currentMoneySlot);
        FractionManager.instance.CheckCurrentMoney();
    }
}
