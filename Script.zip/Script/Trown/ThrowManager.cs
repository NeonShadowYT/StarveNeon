using UnityEngine;

public class ThrowManager : MonoBehaviour
{
    public Animator anim;

    public float _power;
    public float power
    {
        get { return _power; }
        set
        {
            _power = value;
            anim.SetFloat("ThrowPower", _power);
        }
    }

    public Rigidbody currentRb;
    public Transform currentT;

    void Start()
    {
        currentRb.useGravity = false;
    }

    public void ThrowStart() // при нажатии на кнопку запускаем аниматор
    {
        power = 0f;
        anim.SetBool("Throw", true);
    }

    public void ThrowEnd() // при нажатии на кнопку запускаем аниматор
    {
        Vector3 force = currentT.up * power; //создаем силу толчка камня 
        currentRb.AddForce(force);//даем импульс (толчек) для камня

        power = 0f;
    }

    // в аниматоре при произведении ивента
    public void ThrowPowerX05() => power = 0.5f;
    public void ThrowPowerX1() => power = 1f;
    public void ThrowPowerX15() => power = 1.5f;
    public void ThrowPowerX2() => power = 2f;
}
