using UnityEngine;

public class MyFloater : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public Rigidbody rig;

    [Header("Взаимодействие с водой")]
    [Space]
    public float floatUpSpeed = 1f, floatUpSpeedLimit = 1.15f;

    private void Awake()
    {
        if (rig == null) rig = GetComponent<Rigidbody>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 4) InvokeRepeating(nameof(InvokeWater), 0.25f, 0.25f);
    }

    void InvokeWater()
    {
        rig.AddForce(new Vector3(0f, Mathf.Clamp((Mathf.Abs(Physics.gravity.y) * floatUpSpeed), 0, Mathf.Abs(Physics.gravity.y) * floatUpSpeedLimit), 0f), ForceMode.Acceleration);

        rig.drag = 0.99f;
        rig.angularDrag = 0.8f;
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.layer == 4)
        {
            CancelInvoke(nameof(InvokeWater));

            rig.drag = 0f;
            rig.angularDrag = 0f;
        }
    }
}