using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class SkinsInventoryItem : MonoBehaviour
{
    public MagazinManager magazinManager;
    public ItemSkinScriptableObject itemSkinScriptableObject;

    public GameObject Enable;
    public GameObject Disable;

    public TMP_Text Name;
    public Image Image;

    public void EnableSkins()
    {
        magazinManager.AllActiveSkins.Add(itemSkinScriptableObject);
    }

    public void DisableSkins()
    {
        magazinManager.AllActiveSkins.Remove(itemSkinScriptableObject);
    }
}