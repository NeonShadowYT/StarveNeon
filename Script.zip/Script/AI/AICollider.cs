using System.Collections;
using UnityEngine.AI;
using UnityEngine;

public enum AIStats { OffLogic, BaseLogic, ViewLogic, AttackeLogic }
public class AICollider : MonoBehaviour
{
    public AIManager aIManager;
    public AIStats currentStats;

    [Space]
    public SphereCollider[] mobCollider;
    public GameObject[] mobView;

    public void SetupAI()
    {
        switch (DataSaveLoad.instance.data.complexity)
        {
            case 0:
                if (mobCollider[0].radius <= 150f) mobCollider[0].radius -= 15f;
                if (mobCollider[1].radius <= 100f) mobCollider[1].radius -= 15f;
                if (mobCollider[2].radius >= 0.25f) mobCollider[2].radius -= 0.25f;
                break;
            case 2:
                if (mobCollider[0].radius <= 150f) mobCollider[0].radius += 15f;
                if (mobCollider[1].radius <= 100f) mobCollider[1].radius += 15f;
                if (mobCollider[2].radius >= 0.25f) mobCollider[2].radius += 0.25f;
                break;
            case 3:
                if (mobCollider[0].radius <= 150f) mobCollider[0].radius += 30f;
                if (mobCollider[1].radius <= 100f) mobCollider[1].radius += 30f;
                if (mobCollider[2].radius >= 0.25f) mobCollider[2].radius += 0.5f;
                break;
        }

        SetupComponents(false);
    }

    public void SetupComponents(bool isActive)
    {
        for (int i = 0; i < mobView.Length; i++)
        {
            mobView[i].SetActive(isActive);
        }

        aIManager.navMeshAgent.enabled = isActive;
        aIManager.mobCollider.enabled = isActive;
        aIManager.animator.enabled = isActive;
        aIManager.audios.enabled = isActive;
    }

    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            switch (currentStats)
            {
                case AIStats.OffLogic:
                    OnBaseLogic();
                    break;
                case AIStats.BaseLogic:
                    OnViewLogic(col);
                    break;
                case AIStats.ViewLogic:
                    OnAttackeLogic();
                    break;
            }
        }
    }

    private void OnTriggerExit(Collider col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            switch (currentStats)
            {
                case AIStats.BaseLogic:
                    OffBaseLogic();
                    break;
                case AIStats.ViewLogic:
                    OffViewLogic(col);
                    break;
                case AIStats.AttackeLogic:
                    OffAttackeLogic();
                    break;
            }
        }
    }

    //Цель на дальней дистанции
    private void OnBaseLogic()
    {
        currentStats = AIStats.BaseLogic;

        mobCollider[0].enabled = true;
        mobCollider[1].enabled = true;
        mobCollider[2].enabled = false;

        if(aIManager.death == true || (!DayTime.instance.night && aIManager.NightAI))
        {
            aIManager.animator.cullingMode = AnimatorCullingMode.CullCompletely;
            SetupComponents(false);
            return;
        }

        if (aIManager.mobUpdate.Count > 0 && Random.Range(0, 2) == 1 && DayTime.instance.Day >= aIManager.mobUpdate[0].dayUpdate)
        {
            aIManager.UpdateLvlMob();
        }

        GlobalInvoker.instance.aiMoveUpdate.Add(aIManager);
        GlobalInvoker.instance.aiAnimUpdate.Add(aIManager);

        SetupComponents(true);
    }

    private void OffBaseLogic()
    {
        currentStats = AIStats.OffLogic;

        mobCollider[0].enabled = true;
        mobCollider[1].enabled = false;
        mobCollider[2].enabled = false;

        GlobalInvoker.instance.aiAnimUpdate.Remove(aIManager);
        GlobalInvoker.instance.aiMoveUpdate.Remove(aIManager);
        GlobalInvoker.instance.aiLogicUpdate.Remove(aIManager);

        aIManager.animator.cullingMode = AnimatorCullingMode.CullCompletely;
        SetupComponents(false);
    }

    //Цель на дистанции видимости
    private void OnViewLogic(Collider col)
    {
        currentStats = AIStats.ViewLogic;
        
        mobCollider[0].enabled = true;
        mobCollider[1].enabled = true;
        mobCollider[2].enabled = true;

        aIManager.animator.SetBool("Sleep", false);
        aIManager.animator.SetFloat("Target", 1f);

        aIManager.target.Clear();
        aIManager.target.Add(col.transform);

        if (aIManager.AgreAI)
        {
            aIManager.animator.cullingMode = AnimatorCullingMode.CullUpdateTransforms;
        }

        GlobalInvoker.instance.aiLogicUpdate.Add(aIManager);

        if (aIManager.viewColdawn == false) aIManager.animator.SetBool("ViewTarget", true);
        else aIManager.animator.SetBool("ViewTarget", false);
    }

    private void OffViewLogic(Collider col)
    {
        currentStats = AIStats.BaseLogic;

        mobCollider[0].enabled = true;
        mobCollider[1].enabled = true;
        mobCollider[2].enabled = false;

        GlobalInvoker.instance.aiLogicUpdate.Remove(aIManager);

        aIManager.animator.SetBool("ViewTarget", false);
        aIManager.animator.SetFloat("Target", 0f);

        aIManager.target.Remove(col.transform);
    }

    //Цель на близкой дистанции
    private void OnAttackeLogic()
    {
        currentStats = AIStats.AttackeLogic;

        mobCollider[0].enabled = true;
        mobCollider[1].enabled = true;
        mobCollider[2].enabled = true;

        if (aIManager.AgreAI)
        {
            aIManager.animator.SetBool("Damage", true);
            aIManager.AIStop();
                    
            aIManager.mobStats.playerAttackeZone = true;
        }
    }

    private void OffAttackeLogic()
    {
        currentStats = AIStats.ViewLogic;

        mobCollider[0].enabled = true;
        mobCollider[1].enabled = true;
        mobCollider[2].enabled = true;

        aIManager.animator.SetBool("Damage", false);
        aIManager.AIWalk();

        aIManager.mobStats.playerAttackeZone = false;
        aIManager.nextAttackTime = Time.time + aIManager.mobScriptableObject.attackeTime;
    }
}