using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class Daytime : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{   
    public Stolery stolery;

    [HideInInspector]
    public GlobalInvoker globalInvoker;

    [Space]
    public int GameJoltDayID;
    public string extraData;

    [Space]
    [Header("Фракция")]
    public List<Fraction> fraction;

    public List<GameObject> Nobj;
    public List<GameObject> Ultimateobj;

    [HideInInspector]public MoneySlot TexnoSlot;
    [HideInInspector]public Indicators indicators;
    [HideInInspector]public QuastGame quastGame;
    [HideInInspector]public RegistrProgress registrProgress;

    [Space]
    private int _Day;
    public int Day
    {
        get { return _Day; }
        set
        {
            _Day = value;

            if (_Day <= 0) return;

            TexnoSlot.amount += Random.Range(75, 150);

            if (_Day >= 3) TexnoSlot.amount += Random.Range(25, 50);
            if (_Day >= 6)
            {
                TexnoSlot.amount += Random.Range(20, 45);
                foreach (GameObject _Ultimateobj in Ultimateobj) _Ultimateobj.SetActive(true);
            }
            if (_Day >= 9) TexnoSlot.amount += Random.Range(15, 40);
            if (_Day >= 12) TexnoSlot.amount += Random.Range(10, 35);
            if (_Day >= 15) TexnoSlot.amount += Random.Range(5, 30);

            for (int i = 0; i < quastGame.quastItemList.Count; i++)
            {
                if (quastGame.quastItemList[i].quastScriptableObject.quastType == QuastType.Day)
                {
                    quastGame.quastItemList[i].PassItemProgress.value += 1;

                    if (quastGame.quastItemList[i].PassItemProgress.value == quastGame.quastItemList[i].PassItemProgress.maxValue)
                    {
                        quastGame.AddQuastReward(i);
                    }
                }
            }

            if(registrProgress != null)
            {
                if(registrProgress.regGJ == true)
                {
                    int dayAdd = 1;
                    GameJolt.API.Scores.Add(dayAdd, DayText.text, GameJoltDayID, extraData, (bool success) =>
                    {
                         Debug.Log(success ? "Дни защитаны" : "Не удалось защитать дни");
                    });
                }
            }
        }
    }

    [HideInInspector]public GameObject DayTextObject;
    [HideInInspector]public TMP_Text DayText;

    [HideInInspector]public Image DayImage;
    [HideInInspector]public Sprite DayIcon;

    [Space]
    [Header("Настройки")]
    public GameObject RouSpawner;
    public GameObject MoreResoursSpawner;
    public GameObject PlantsExpanded;

    [Space]
    [Header("Промокоды")]
    public GameObject MediSet;
    public GameObject OberSet;

    [HideInInspector]public bool NobjForDay;
    [HideInInspector]public bool BadWeather;
    [HideInInspector]public bool MobUpdater;

    void Start()
    {
        if(NobjForDay == false) foreach (GameObject _Nobj in Nobj) _Nobj.SetActive(false);
        foreach (GameObject _Ultimateobj in Ultimateobj) _Ultimateobj.SetActive(false);
    }

    public void DayEnd()
    {
        indicators._sleepAI = 1;// ��������
        globalInvoker.sleepAI = true;

        foreach (GameObject _Nobj in Nobj) _Nobj.SetActive(true);
    }

    public void DayStart()
    {
        Day++;

        if (DayText == null) return;

        DayText.text = "День " + Day.ToString() + " Техно очки зачислены";
        DayImage.sprite = DayIcon;
        DayTextObject.SetActive(true);

        indicators._sleepAI = 0; // меняет всякие штуки игроку
        globalInvoker.sleepAI = false;

        if (NobjForDay == false) foreach (GameObject _Nobj in Nobj) _Nobj.SetActive(false);
    }

    public void CloseDayText()
    {
        if (DayTextObject != null) DayTextObject.SetActive(false);
    }
    
    void OnFraction()
    {
        foreach (Fraction fract in fraction)
        {
            fract.UpdateFractChek(Day);
        }
    }

    public void OnStolery()
    {
        if (stolery != null) stolery.RandomIvent();
    }
}

[System.Serializable]
public class DecorList
{
    [Space]
    [Header("Декор")]
    public GameObject Decor;
}