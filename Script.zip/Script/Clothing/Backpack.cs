using UnityEngine;

public class Backpack : MonoBehaviour
{
    public ClothAdder clothAdder;

    [Space]
    [Header("Характеристики")]
    [Range(1, 10), Tooltip("Количество слотов и инвенторе")] public int slotAmmount;

    private void OnEnable()
    {
        if (clothAdder == null) return;
        clothAdder.backpack = this;

        for (int i = 0; i < slotAmmount; i++)
        {
            InventoryManager.instance.slots[InventoryManager.instance.backpackSlot + i].gameObject.SetActive(true);
        }
    }

    private void OnDisable() //делай что-то
    {
        if (clothAdder == null) return;

        for (int i = 0; i < slotAmmount; i++)
        {
            InventoryManager.instance.slots[InventoryManager.instance.backpackSlot + i].gameObject.SetActive(false);

            if (InventoryManager.instance.slots[InventoryManager.instance.backpackSlot + i].item != null)
            {
                Item dropItem = Instantiate(InventoryManager.instance.slots[InventoryManager.instance.backpackSlot + i].item.itemPrefab, CustomCharacterController.instance.mTransform.position + Vector3.up + CustomCharacterController.instance.mTransform.forward, Quaternion.identity).GetComponent<Item>(); // Выброс объектов из инвентаря - Спавним префаб обекта перед персонажем

                dropItem.amount = InventoryManager.instance.slots[InventoryManager.instance.backpackSlot + i].amount;
                dropItem.durability = InventoryManager.instance.slots[InventoryManager.instance.backpackSlot + i].durability;
                dropItem.destroy = InventoryManager.instance.slots[InventoryManager.instance.backpackSlot + i].destroyBar.fillAmount;

                InventoryManager.instance.RemoveItemFromSlot(InventoryManager.instance.backpackSlot + i);
            }
        }
    }
}