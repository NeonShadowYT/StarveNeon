using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "GameMode", menuName = "Neon Imperium/GameMode/New Settings")]
public class GameSettingsScriptableObject : ScriptableObject
{
    [Space]
    [Header("Иконка")]
    public Sprite IconSettings;

    [Space]
    [Header("Название настройки")]
    public string NameSettings;
}
