using UnityEngine;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;

public class PhotonSetManager : MonoBehaviourPunCallbacks
{
    [Space]
    public PhotonView _photonView;

    [Space]
    public Transform allWeapons;
    public Transform[] allArmor;
    public Transform allShield;
    public Transform allBackpack;
    public GameObject[] allCharacters;

    [Space]
    public GameObject chat;
    public GameObject biomLock;

    [Space]
    public string skin;

    [HideInInspector]
    public bool enableWeapon;
    public int idWeapon;

    [HideInInspector]
    public int idLvl;

    [HideInInspector]
    public bool enableArmor;
    public int idArmor;

    [HideInInspector]
    public bool enableShield;
    public int idShield;

    [HideInInspector]
    public bool enableBackpack;
    public int idBackpack;

    public bool newGame;
    public bool teamMode;
    public bool devMode;
    public bool dinamicFraction;
    
    [HideInInspector]
    public bool MP;

    void Awake()
    {
        if (PlayerPrefs.HasKey("Multiplayer")) MP = System.Convert.ToBoolean(PlayerPrefs.GetInt("Multiplayer")); else MP = false;

        if (MP == false) 
        {
            if (chat != null) 
            {
                Destroy(chat);
            }

            Destroy(this);
            return;
        }

        if (PhotonNetwork.IsMasterClient)
        {
            biomLock.SetActive(false);
        }
        else
        {
            biomLock.SetActive(true);
        }
    }

    public void MultiSwitchScene(string sceneName)
    {
        PhotonNetwork.LoadLevel(sceneName);
    }

    public void LeaveRoom()
    {
        PhotonNetwork.LeaveRoom();
    }

    public override void OnPlayerEnteredRoom(Player player) //когда игрок заходит в комнату
    {
        SetSkin(skin);
        SetWeapon(enableWeapon, idWeapon);
        SetArmor(enableArmor, idArmor);
        SetShield(enableShield, idShield);
        SetBackpack(enableShield, idShield);
    }
    public override void OnMasterClientSwitched(Player newMasterClient) //когда меняется мастер клиент
    {
        if (PhotonNetwork.IsMasterClient)
        {
            biomLock.SetActive(false);
        }
        else
        {
            biomLock.SetActive(true);
        }
    }

    public void SetSkin(string characterName) 
    {
        skin = characterName;

        _photonView.RPC(nameof(PhotonSkinData), RpcTarget.All, characterName);
    }

    public void SetWeapon(bool enabled, int id) 
    { 
        enableWeapon = enabled;
        idWeapon = id;

        _photonView.RPC(nameof(PhotonWeaponData), RpcTarget.All, enabled, id);
    }

    public void SetArmor(bool enabled, int id) 
    {
        enableArmor = enabled;
        idArmor = id;

        _photonView.RPC(nameof(PhotonArmorData), RpcTarget.All, enabled, id);
    }

    public void SetShield(bool enabled, int id) 
    {
        enableShield = enabled;
        idShield = id;

        _photonView.RPC(nameof(PhotonShieldData), RpcTarget.All, enabled, id);
    }

    public void SetBackpack(bool enabled, int id) 
    {
        enableBackpack = enabled;
        idBackpack = id;

        _photonView.RPC(nameof(PhotonBackpackData), RpcTarget.All, enabled, id);
    }

    public void SetLobby(bool _newGame, bool _teamMode, bool _devMode, bool _dinamicFraction, int id) 
    {
        _photonView.RPC(nameof(PhotonLobbyData), RpcTarget.All, _newGame, _teamMode, _devMode, _dinamicFraction, id);
    }

    [PunRPC]
    private void PhotonSkinData(string characterName)
    {
        for (int i = 0; i < allCharacters.Length; i++)
        {
            if (allCharacters[i].name != characterName) allCharacters[i].SetActive(false);
            else allCharacters[i].SetActive(true);
        }
    }

    [PunRPC]
    private void PhotonWeaponData(bool enabled, int id)
    {
        for (int i = 0; i < allWeapons.childCount; i++) allWeapons.GetChild(i).gameObject.SetActive(false);
        if (enabled == true) allWeapons.GetChild(id).gameObject.SetActive(true); // enabled создан чтобы можно было просто выключить все оружки если игрок всё убрал
    }

    [PunRPC]
    private void PhotonArmorData(bool enabled, int id)
    {
        for (int ii = 0; ii < allArmor.Length; ii++)
        {
            for (int i = 0; i < allArmor[ii].childCount; i++)
            {
                if (i == id && enabled == true) 
                {
                    allArmor[ii].GetChild(i).gameObject.SetActive(true);
                }
                else
                {
                    allArmor[ii].GetChild(i).gameObject.SetActive(false);
                }
            }
        }
    }

    [PunRPC]
    private void PhotonShieldData(bool enabled, int id)
    {
        for (int i = 0; i < allShield.childCount; i++) allShield.GetChild(i).gameObject.SetActive(false);
        if (enabled == true) allShield.GetChild(id).gameObject.SetActive(true);
    }

    [PunRPC]
    private void PhotonBackpackData(bool enabled, int id)
    {
        for (int i = 0; i < allBackpack.childCount; i++) allBackpack.GetChild(i).gameObject.SetActive(false);
        if (enabled == true) allBackpack.GetChild(id).gameObject.SetActive(true);
    }

    [PunRPC]
    private void PhotonLobbyData(bool _newGame, bool _teamMode, bool _devMode, bool _dinamicFraction, int id)
    {
        newGame = _newGame;
        teamMode = _teamMode;
        devMode = _devMode;
        dinamicFraction = _dinamicFraction;

        PlayerPrefs.SetInt("NewGame", System.Convert.ToInt32(_newGame));
        PlayerPrefs.SetInt("TeamMode", System.Convert.ToInt32(_teamMode));
        PlayerPrefs.SetInt("DevMode", System.Convert.ToInt32(_devMode));
        PlayerPrefs.SetInt("DinamicFraction", System.Convert.ToInt32(_dinamicFraction));
    }
}