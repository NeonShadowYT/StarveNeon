﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CraftResourceDetails : MonoBehaviour
{
    public TMP_Text itemTypeText, totalText; //public void FillResourceDetails() =>
    public Image itemImage, compliteImage;

    [Space]
    public Color disableColor;
    public Color enebleColor;
}