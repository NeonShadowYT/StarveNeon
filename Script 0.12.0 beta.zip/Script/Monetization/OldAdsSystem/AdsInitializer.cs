using UnityEngine;
using UnityEngine.Advertisements;

public class AdsInitializer : MonoBehaviour, IUnityAdsInitializationListener
{
    [SerializeField] string androidGameID;

    private void Awake()
    {
        Advertisement.Initialize(androidGameID, false, this);
    }

    public void OnInitializationComplete()
    {
        Debug.Log("Инициализация рекламы успешно");
    }

    public void OnInitializationFailed(UnityAdsInitializationError error, string message)
    {
        Advertisement.Initialize(androidGameID, false, this);
    }
}