using System.Collections.Generic;
using UnityEngine;

public class PetsManager : MonoBehaviour
{
    public AllPets currentPets;

    public Animator anim;
    public BoxCollider mCollider;

    private Vector3 startColliderCetner;
    private Vector3 startColliderSize;

    [Space]
    [Header("Все петы")]
    public List<AllPets> allPets;

    public void Start()
    {
        currentPets = null;
        startColliderCetner = mCollider.center;
        startColliderSize = mCollider.size;
    }

    public void EquipPets(ItemScriptableObject petsItem)
    {
        anim.SetBool("Mit", false);

        for (int i = 0; i < allPets.Count; i++)
        {
            if (allPets[i].petsItem == petsItem)
            {
                currentPets = allPets[i];

                mCollider.center = currentPets.colliderModiferCenter;
                mCollider.size = currentPets.colliderModiferSize;

                currentPets.obj.SetActive(true);

                if (currentPets.petsAnim == PetsAnim.Mit)
                {
                    anim.SetBool("Mit", true);
                }
            }
            else
            {
                allPets[i].obj.SetActive(false);
            }
        }
    }
    public void RemovePets()
    {
        anim.SetBool("Mit", false);

        mCollider.center = startColliderCetner;
        mCollider.size = startColliderSize;

        for (int i = 0; i < allPets.Count; i++)
        {
            allPets[i].obj.SetActive(false);
        }

        currentPets = null;
    }
}
public enum PetsAnim { Mit }

[System.Serializable]
public class AllPets
{
    [Space]
    [Header("Пет")]
    public ItemScriptableObject petsItem;
    public PetsAnim petsAnim;

    [Space]
    public float walkSpeed;
    public float runSpeed;

    public Vector3 colliderModiferCenter;
    public Vector3 colliderModiferSize;

    [Space]
    public GameObject obj;
}
