using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine;
using Photon.Pun;

public class CustomCharacterController : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Скрипты")]
    public InventoryManager inventoryManager;
    public CraftManager craftManager;
    public QuickslotInventory quickslotInventory;
    public SceneTransition sceneTransition;
    public Indicators indicators;
    public TurnController turnController;
    public VariableJoystick Joystick;

    [Space]
    public PhotonView photonView;
    public PhotonSetManager photonSetManager;
    public PetsManager petsManager;
    public DataSaveLoad dataSaveLoad;
    public RunEffect runEffect;
    public AudioStep audioStep;

    [Space]
    public Animator anim;
    public Rigidbody rig;

    [Space]
    [Header("Переменные")]
    public float walkingSpeed = 7f;
    public float runningSpeed = 11f, lerpMultiplier = 7f, animationInterpolation = 1f;
    public float floatUpSpeed = 5f, floatUpSpeedLimit = 10f;
    
    [HideInInspector]
    public float currentSpeed, horizontal, vertical;

    [Space]
    [Header("Прыжок")]
    public float jumpForce = 5f;

    private byte platformCollisions;
    public bool CanJump
    {
        get { return platformCollisions > 0; }
    }

    [Space]
    [Header("Объекты")]
    public GameObject MobaillMenu;

    [Space]
    [Header("Разное")]
    public Transform mainCamera;
    public Transform mTransform;

    [Space]
    public GameObject[] LocalObj;
    public Transform[] ParrentObj;

    [Space]
    [Header("Звуки")]
    public AudioSource audioSource;
    public AudioClip[] audioHit;

    [HideInInspector]
    public List<string> stepId;

    [HideInInspector]
    public bool run, MP;

    void Start()
    {
        if (PlayerPrefs.HasKey("Multiplayer")) MP = System.Convert.ToBoolean(PlayerPrefs.GetInt("Multiplayer")); else MP = false;

        if (MP == true)
        {
            if (!photonView.IsMine)
            {
                gameObject.tag = "Untagged";
                MultiplayerDel();
                return;
            }

            PhotonNetwork.Instantiate("PlayerController", mTransform.position, Quaternion.identity);
            PhotonNetwork.NickName = dataSaveLoad.data.playerNick;

            PhotonNetwork.OfflineMode = false;
        }
        else
        {
            PhotonNetwork.OfflineMode = true;
        }

        foreach (Transform obj in ParrentObj) 
        {
            obj.parent = null;
        }

        if (SystemInfo.deviceType != DeviceType.Handheld)
        {
            MobaillMenu.SetActive(false);
        }

        platformCollisions = 0;
        FindObjectOfType<GlobalInvoker>().customCharacterController = this;
    }

    void Run()
    {
        run = true;

        animationInterpolation = Mathf.Lerp(animationInterpolation, 1.5f, Time.deltaTime * 3);

        anim.SetFloat("x", horizontal * animationInterpolation);
        anim.SetFloat("y", vertical * animationInterpolation);

        if (petsManager.currentPets == null) currentSpeed = Mathf.Lerp(currentSpeed, runningSpeed, Time.deltaTime * 3);
        else currentSpeed = Mathf.Lerp(currentSpeed, petsManager.currentPets.runSpeed, Time.deltaTime * 3);

        anim.SetFloat("run", currentSpeed / runningSpeed);
    }

    public void Walk()
    {
        run = false;
        runEffect.NoRunEffect();

        animationInterpolation = Mathf.Lerp(animationInterpolation, 1f, Time.deltaTime * 3); // Mathf.Lerp - отвчает за то, чтобы каждый кадр число animationInterpolation(в данном случае) приближалось к числу 1 со скоростью Time.deltaTime * 3.
        
        anim.SetFloat("x", horizontal * animationInterpolation);
        anim.SetFloat("y", vertical * animationInterpolation);

        if (petsManager.currentPets == null) currentSpeed = Mathf.Lerp(currentSpeed, walkingSpeed, Time.deltaTime * 3);
        else currentSpeed = Mathf.Lerp(currentSpeed, petsManager.currentPets.walkSpeed, Time.deltaTime * 3);

        anim.SetFloat("run", 0);
    }

    public void Step()
    {
        runEffect.RunEffectManager();
        audioStep.AudioStepManager();
    }

    public void OnJump(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            if (CanJump == true) rig.AddForce(Vector3.up * jumpForce, ForceMode.Impulse); //Прыгаем
        }
    }
    
    public void MobailJump()
    {
        if (CanJump == true) rig.AddForce(Vector3.up * jumpForce, ForceMode.Impulse); //Прыгаем
    }

    private void Update()
    {
        horizontal = Mathf.Lerp(horizontal, (Joystick.Horizontal + Input.GetAxis("Horizontal")), Time.deltaTime * lerpMultiplier);
        vertical = Mathf.Lerp(vertical, (Joystick.Vertical + Input.GetAxis("Vertical")), Time.deltaTime * lerpMultiplier);

        if (horizontal < 0.25f && horizontal > -0.25f && vertical > 0.5f) Run();
        else Walk();
        
        mTransform.rotation = Quaternion.Euler(mTransform.rotation.eulerAngles.x, mainCamera.rotation.eulerAngles.y, mTransform.rotation.eulerAngles.z); // Устанавливаем поворот персонажа когда камера поворачивается 
        turnController.TurnUpdate();
    }

    void FixedUpdate()
    {
        Vector3 camF = mainCamera.forward; // Здесь мы задаем движение персонажа в зависимости от направления в которое смотрит камера
        Vector3 camR = mainCamera.right; // Сохраняем направление вперед и вправо от камеры

        camF.y = 0; // Чтобы направления вперед и вправо не зависили от того смотрит ли камера вверх или вниз, иначе когда мы смотрим вперед, персонаж будет идти быстрее чем когда смотрит вверх или вниз
        camR.y = 0; // Можете сами проверить что будет убрав camF.y = 0 и camR.y = 0 :)

        Vector3 movingVector;
        movingVector = Vector3.ClampMagnitude(camF.normalized * vertical * currentSpeed + camR.normalized * horizontal * currentSpeed, currentSpeed); // Тут мы умножаем наше нажатие на кнопки W & S на направление камеры вперед и прибавляем к нажатиям на кнопки A & D и умножаем на направление камеры вправо

        rig.velocity = new Vector3(movingVector.x, rig.velocity.y, movingVector.z); // Здесь мы двигаем персонажа! Устанавливаем движение только по x & z потому что мы не хотим чтобы наш персонаж взлетал в воздух
        rig.angularVelocity = Vector3.zero; // У меня был баг, что персонаж крутился на месте и это исправил с помощью этой строки
    }

    public void OnScrin(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            ScreenCapture.CaptureScreenshot("Starve Neon " + Random.Range(0, 100000) + ".png");
        }
    }

    public void MultiplayerDel()
    {
        foreach (GameObject obj in LocalObj)
        {
            Destroy(obj);
        }

        Destroy(rig);
        Destroy(runEffect);
        Destroy(this);
    }

    public void StartHit()
    {
        int random = Random.Range(0, audioHit.Length);

        audioSource.volume = Random.Range(0.8f, 1.2f);
        audioSource.pitch = Random.Range(0.8f, 1.2f);

        audioSource.PlayOneShot(audioHit[random]);
    }

    public void ChangBiom()
    {
        indicators.changBiomEffect.infinity = true;
        indicators.changBiomEffect.gameObject.SetActive(true);

        Invoke(nameof(OnChangBiom), 5f);
    }

    public void OnChangBiom()
    {
        dataSaveLoad.Live();
        sceneTransition.SwitchToScene("База");
    }

    private void OnTriggerStay(Collider col)
    {
        if (col.CompareTag("Water"))
        {
            rig.AddForce(new Vector3(0f, Mathf.Clamp((Mathf.Abs(Physics.gravity.y) * floatUpSpeed), 0, Mathf.Abs(Physics.gravity.y) * floatUpSpeedLimit), 0f), ForceMode.Acceleration);

            rig.drag = 0.99f;
            rig.angularDrag = 0.8f;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Water")) //Входим ли мы в воду ?
        {
            indicators.waterEffect.infinity = true;
            indicators.waterEffect.gameObject.SetActive(true);

            stepId.Add("Вода");
            runEffect.enterWaterEffect.SetActive(true);
        }
        if (other.CompareTag("Damage")) 
        {
            indicators.damageEffect.infinity = true;
            indicators.damageEffect.gameObject.SetActive(true);
        }
        if (other.CompareTag("Infected"))
        {
            indicators.infectionEffect.gameObject.SetActive(true);
        }
        if (other.CompareTag("Web"))
        {
            indicators.webEffect.gameObject.SetActive(true);
        }

        if (other.CompareTag("Fire"))
        {
            indicators.hotEffect.infinity = true;
            indicators.hotEffect.gameObject.SetActive(true);
        }
        else if (other.CompareTag("Cold")) 
        {
            if (indicators.ColdArmor < 3)
            {
                indicators.coldEffect.infinity = true;
                indicators.coldEffect.gameObject.SetActive(true);
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Water"))
        {
            indicators.waterEffect.infinity = false; //Выходим из этих зон?
            stepId.Remove("Вода");

            rig.drag = 0f;
            rig.angularDrag = 0f;
        }

        if (other.CompareTag("Damage"))
        {
            indicators.damageEffect.infinity = false;
        }

        if (other.CompareTag("Fire"))
        {
            indicators.hotEffect.infinity = false;
        }
        else if (other.CompareTag("Cold")) 
        {
            indicators.coldEffect.infinity = false;
        }

        if (other.CompareTag("MapEnd"))
        {
            ChangBiom();
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground")) //Прыгнули
        {
            stepId.Add("Земля");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("AD"))
        {
            stepId.Add("Ад");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Rock"))
        {
            stepId.Add("Камень");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Snow"))
        {
            stepId.Add("Снег");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Sand"))
        {
            stepId.Add("Песок");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Infection"))
        {
            stepId.Add("Заражение");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Wood"))
        {
            stepId.Add("Дерево");
            platformCollisions++;
        }

        if (collision.gameObject.CompareTag("Lava"))
        {
            indicators.fireEffect.infinity = true;
            indicators.fireEffect.gameObject.SetActive(true);
        }
        if (collision.gameObject.CompareTag("Infected")) //Если стоим на зоне заражения
        {
            indicators.infectionEffect.infinity = true;
            indicators.infectionEffect.gameObject.SetActive(true);
        }
        if (collision.gameObject.CompareTag("Web")) //Если стоим на паутине
        {
            indicators.webEffect.infinity = true;
            indicators.webEffect.gameObject.SetActive(true);
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground")) //Прыгнули
        {
            stepId.Remove("Земля");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("AD"))
        {
            stepId.Remove("Ад");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Rock"))
        {
            stepId.Remove("Камень");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Snow"))
        {
            stepId.Remove("Снег");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Sand"))
        {
            stepId.Remove("Песок");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Infection"))
        {
            stepId.Remove("Заражение");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Wood"))
        {
            stepId.Remove("Дерево");
            platformCollisions--;
        }

        if (collision.gameObject.CompareTag("Lava")) indicators.damageEffect.infinity = false;
        if (collision.gameObject.CompareTag("Infected")) indicators.infectionEffect.infinity = false;
        if (collision.gameObject.CompareTag("Web")) indicators.webEffect.infinity = false;
    }

    public void MobHitAttacke(float damage, bool blood, float crit, float critModifer, float weak, float weakModifer)
    {
        damage *= indicators.HealthPlus;
        critModifer *= indicators.CritDamage;

        float random = Random.Range(0, 100);

        if (random >= crit) damage *= critModifer;
        else if (random <= weak) damage *= weakModifer;

        switch (indicators.Armor)
        {
            case 0:
                indicators.healthSlider.value -= damage;
                break;
            case 1:
                indicators.healthSlider.value -= (damage * 0.975f);
                break;
            case 2:
                indicators.healthSlider.value -= (damage * 0.95f);
                break;
            case 3:
                indicators.healthSlider.value -= (damage * 0.925f);
                break;
            case 4:
                indicators.healthSlider.value -= (damage * 0.9f);
                break;
            case 5:
                indicators.healthSlider.value -= (damage * 0.875f);
                break;
            case 6:
                indicators.healthSlider.value -= (damage * 0.85f);
                break;
            case 7:
                indicators.healthSlider.value -= (damage * 0.825f);
                break;
            case 8:
                indicators.healthSlider.value -= (damage * 0.8f);
                break;
            case 9:
                indicators.healthSlider.value -= (damage * 0.775f);
                break;
            case 10:
                indicators.healthSlider.value -= (damage * 0.75f);
                break;
            case 11:
                indicators.healthSlider.value -= (damage * 0.725f);
                break;
            case 12:
                indicators.healthSlider.value -= (damage * 0.7f);
                break;
            case 13:
                indicators.healthSlider.value -= (damage * 0.675f);
                break;
            case 14:
                indicators.healthSlider.value -= (damage * 0.65f);
                break;
            case 15:
                indicators.healthSlider.value -= (damage * 0.625f);
                break;
            case 16:
                indicators.healthSlider.value -= (damage * 0.6f);
                break;
            case 17:
                indicators.healthSlider.value -= (damage * 0.575f);
                break;
            case 18:
                indicators.healthSlider.value -= (damage * 0.55f);
                break;
            case 19:
                indicators.healthSlider.value -= (damage * 0.525f);
                break;
            default :
                indicators.healthSlider.value -= (damage * 0.5f);
                break;
        }

        random = damage * Random.Range(0.25f, 0.5f);

        inventoryManager.clothAdder.armorSlot.SubtractDurabilityPerHit(random);
        inventoryManager.clothAdder.backpackSlot.SubtractDurabilityPerHit(random);
        inventoryManager.clothAdder.shieldSlot.SubtractDurabilityPerHit(random);

        if (blood == true)
        {
            random = Random.Range(0, indicators.Armor);

            if (random <= Random.Range(5, 15))
            {
                indicators.bloodEffect.gameObject.SetActive(true);
            }
        }

        Handheld.Vibrate();

        indicators.damageEffect.gameObject.SetActive(true);
        inventoryManager.clothAdder.UpdateClothes();
    }

    // Мобилки
    public void MobailHit()
    {
        anim.SetBool("Hit", false); //Этот метод произходит при нажатии на кнопку удара на телефоне. Отключение чтобы перс не бил бесконечно
        quickslotInventory.HitBool = false;

        if (quickslotInventory.activeSlot != null && quickslotInventory.activeSlot.item != null && (quickslotInventory.activeSlot.item.itemType == ItemType.Instrument || quickslotInventory.activeSlot.item.itemType == ItemType.Weapon))
        {
            anim.SetBool("SpeedMedium", false);
            anim.SetBool("SpeedLow", false);
            anim.SetBool("SpeedMax", false);

            switch (quickslotInventory.activeSlot.item.speedAttacke)
            {
                case SpeedAttacke.Low:
                    anim.SetBool("SpeedLow", true);
                    break;
                case SpeedAttacke.Medium:
                    anim.SetBool("SpeedMedium", true);
                    break;
                case SpeedAttacke.Max:
                    anim.SetBool("SpeedMax", true);
                    break;
            }

            anim.SetBool("Hit", true);
        }
    }
}