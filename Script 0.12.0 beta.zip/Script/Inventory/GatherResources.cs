﻿using UnityEngine;
using Photon.Pun;

public class GatherResources : MonoBehaviour
{
    [Space]
    [Header("Важное")]
    public EffectPool effectPool;
    public InventoryManager inventoryManager;
    public QuickslotInventory quickslotInventory;
    public Score scoreM;

    [Space]
    [Header("Характеристики")]
    public float woodDamage;
    public float stoonDamage;
    public float enemyDamage;
    public float bildingDamage;
    public float groundDamage;
    public float crit = 77f, critModifer = 1.5f;
    public float weak = 22f, weakModifer = 0.75f;

    [Space]
    [Header("Отдача")]
    public Recoil recoil;

    [Header("От бедра")]
    public float recoilX = 1f;
    public float recoilY = 2f;
    public float recoilZ = 2f;

    [Header("В прицеле")]
    public float aimRecoilX = 0.5f;
    public float aimRecoilY = 1.5f;
    public float aimRecoilZ = 1.5f;

    [Space]
    [Header("Уровень"), Range(1, 10)]
    public int Lvls;

    public AudioSource audioSource; // источник звука

    public void Start() // можно сделать гены которые меняют скорость добычи и тд
    {
        woodDamage *= quickslotInventory.indicators.DamagePlus;
        stoonDamage *= quickslotInventory.indicators.DamagePlus;

        enemyDamage *= quickslotInventory.indicators.DamagePlus;
        bildingDamage *= quickslotInventory.indicators.DamagePlus;

        groundDamage *= quickslotInventory.indicators.DamagePlus;
    }

    void OnTriggerEnter(Collider hit)
    {
        if (quickslotInventory.HitBool == false) return;
 
        if (quickslotInventory.activeSlot.item.isDurability == true && quickslotInventory.activeSlot.itemDurability <= 0) return;

        audioSource.volume = Random.Range(0.8f, 1.2f);
        audioSource.pitch = Random.Range(0.8f, 1.2f);

        ResourceHealth resourceHealth = hit.GetComponent<ResourceHealth>();

        if (resourceHealth != null)
        {
            if (resourceHealth.armor == true) return;

            float damage = 0f;

            if (hit.CompareTag("Tree"))
            {
                damage = woodDamage;
            }
            else if (hit.CompareTag("Rock"))
            {
                damage = stoonDamage;
            }
            else
            {
                damage = groundDamage;
            }

            if (damage == 0) return;

            recoil.RecoilFire(recoilX, recoilY, recoilZ, aimRecoilX, aimRecoilY, aimRecoilZ);
            audioSource.PlayOneShot(resourceHealth.audioList[Random.Range(0, resourceHealth.audioList.Length)]);

            if (Lvls >= resourceHealth.Lvl)
            {
                effectPool.ViewEffect(resourceHealth.hitFix, hit.ClosestPoint(transform.position));

                resourceHealth.currentHealth -= damage;

                quickslotInventory.activeSlot.SubtractDurabilityPerHit(resourceHealth.Lvl);

                int scoreAdd = Random.Range(1, resourceHealth.Lvl);
                scoreM.ScoreAdd(scoreAdd);

                if (resourceHealth.currentHealth <= 0)
                {
                    inventoryManager.AddItem(null, resourceHealth.resourceType, 10, resourceHealth.resourceType.maximumDurability, 0f);
                    return;
                }

                if (Lvls == resourceHealth.Lvl) 
                {
                    inventoryManager.AddItem(null, resourceHealth.resourceType, 1, resourceHealth.resourceType.maximumDurability, 0f);
                }
                else
                {
                    int getRes = Lvls - resourceHealth.Lvl;

                    if (getRes <= 1) getRes = 2;

                    inventoryManager.AddItem(null, resourceHealth.resourceType, getRes, resourceHealth.resourceType.maximumDurability, 0f);
                }
            }
        }
        else
        {
            MobStats mobHealth = hit.GetComponent<MobStats>();

            if (mobHealth != null && enemyDamage >= 1)
            {
                if (mobHealth.armor == true) return;

                effectPool.ViewEffect(mobHealth.mobScriptableObject.hitFIX, hit.ClosestPoint(transform.position));
                
                float realDamage = enemyDamage;
                float realCrit = critModifer * quickslotInventory.indicators.CritPlus;

                int random = Random.Range(0, 100);

                if (random >= crit) realDamage *= realCrit;
                else if (random <= weak) realDamage *= weakModifer;

                mobHealth.health -= realDamage;

                int durability = Random.Range(1, 3);
                quickslotInventory.activeSlot.SubtractDurabilityPerHit(durability);

                recoil.RecoilFire(recoilX, recoilY, recoilZ, aimRecoilX, aimRecoilY, aimRecoilZ);
                audioSource.PlayOneShot(mobHealth.mobScriptableObject.damageAudio[Random.Range(0, mobHealth.mobScriptableObject.damageAudio.Length)]);

                int scoreAdd = Random.Range(1, 10);
                scoreM.ScoreAdd(scoreAdd);
            }
            else
            {
                BuildingHealth buildingHealth = hit.GetComponent<BuildingHealth>();

                if (buildingHealth != null && bildingDamage >= 1)
                {
                    effectPool.ViewEffect(buildingHealth.hitFix, hit.ClosestPoint(transform.position));

                    buildingHealth.health -= bildingDamage;
                    
                    int durability = Random.Range(1, 5);
                    quickslotInventory.activeSlot.SubtractDurabilityPerHit(durability);

                    recoil.RecoilFire(recoilX, recoilY, recoilZ, aimRecoilX, aimRecoilY, aimRecoilZ);
                    audioSource.PlayOneShot(buildingHealth.audioList[Random.Range(0, buildingHealth.audioList.Length)]);
                }
            }
        }
    }
}