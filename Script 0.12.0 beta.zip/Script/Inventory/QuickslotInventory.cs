using UnityEngine;
using UnityEngine.UI;

public class QuickslotInventory : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("Скрипты")]
    public PetsManager petsManager;
    public InventoryManager inventoryManager;
    public Indicators indicators;
    public AchievementManager Achievement;
    public ThrowManager throwManager;
    public PhotonSetManager photonSetManager; // синхранизация в мультиплеере

    [Space]
    public Animator anim;
    public AudioSource audioSource;

    [Space]
    [Header("Иконка слота")]
    public Color selectedColor;
    public Color notSelectedColor;

    [Space]
    [Header("Парент")]
    public Transform quickslotParent;
    public Transform allWeapons;

    [Space]
    [Header("Текущий слот")]
    public InventorySlot activeSlot;

    private int currentQuickslotID = 0;
    private int currentSmenaSlotID = -1;

    [Space]
    [Header("Кеширование")]
    private Image currentQSlotImage;
    private float _scrollWheel;
    private float scrollWheel
    {
        get{ return _scrollWheel; }
        set
        {
            _scrollWheel = value;

            if (_scrollWheel > 0.1) // Берем предыдущий слот и меняем его картинку на обычную
            {
                currentQSlotImage.color = notSelectedColor; // Здесь добавляем что случится когда мы УБЕРАЕМ ВЫДЕЛЕНИЕ со слота (Выключить нужный нам предмет, поменять аниматор ...)

                if (currentQuickslotID >= quickslotParent.childCount - 1) currentQuickslotID = 0; else currentQuickslotID++;// Если крутим колесиком мышки вперед и наше число currentQuickslotID равно последнему слоту, то выбираем наш первый слот (первый слот считается нулевым) // Прибавляем к числу currentQuickslotID единичку
                SelectSlot(); // Берем предыдущий слот и меняем его картинку на "выбранную" // Здесь добавляем что случится когда мы ВЫДЕЛЯЕМ слот (Включить нужный нам предмет, поменять аниматор ...)
            }
            else if (_scrollWheel < -0.1) // Берем предыдущий слот и меняем его картинку на обычную
            {
                currentQSlotImage.color = notSelectedColor; // Здесь добавляем что случится когда мы УБЕРАЕМ ВЫДЕЛЕНИЕ со слота (Выключить нужный нам предмет, поменять аниматор ...)

                if (currentQuickslotID <= 0) currentQuickslotID = quickslotParent.childCount - 1; else currentQuickslotID--; // Если крутим колесиком мышки назад и наше число currentQuickslotID равно 0, то выбираем наш последний слот // Уменьшаем число currentQuickslotID на 1
                SelectSlot(); // Берем предыдущий слот и меняем его картинку на "выбранную" // Здесь добавляем что случится когда мы ВЫДЕЛЯЕМ слот (Включить нужный нам предмет, поменять аниматор ...)
            }
        }
    }

    private Gun currentGun;
    private GatherResources currentWeapon;

    [Space]
    [Header("Прицеливание")]
    public bool HitBool;
    public bool Aim;

    void Start()
    {
        SelectSlot();
    }

    void Update()
    {
        if (HitBool == true)
        {
            if (currentGun != null) 
            {
                currentGun.Shoot();
            }
        }

        if (Application.platform == RuntimePlatform.Android) return;

        scrollWheel = Input.GetAxis("Mouse ScrollWheel"); // Используем колесико мышки

        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            ActiveSlot();
        }
        else if (Input.GetKeyUp(KeyCode.Mouse0))
        {
            anim.SetBool("Hit", false);
            HitBool = false;
        }

        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            Aim = true;
            anim.SetBool("Aim", true);
        }
        else if (Input.GetKeyUp(KeyCode.Mouse1))
        {
            Aim = false;
            anim.SetBool("Aim", false);
        }
    }

    public void AchivementChek(float progressAdd)
    {
        foreach (AchievementItem achievement in Achievement.achievementItem)
        {
            if (achievement.achievementScriptableObject.itemScriptableObject == activeSlot.item)
            {
                achievement.sliderProgress.value += progressAdd;

                if (achievement.sliderProgress.value >= achievement.sliderProgress.maxValue) 
                {
                    achievement.Unloke();
                    achievement.buttonAchievement.interactable = true;
                }
                else
                {
                    achievement.buttonAchievement.interactable = false;
                }

                break;
            }
        }
    }

    private void SelectSlot()
    {
        anim.SetBool("Hit", false);
        HitBool = false;

        currentQSlotImage = quickslotParent.GetChild(currentQuickslotID).GetComponent<Image>();
        activeSlot = quickslotParent.GetChild(currentQuickslotID).GetComponent<InventorySlot>();

        currentQSlotImage.color = selectedColor;
        currentGun = null;

        CheckItemInHand();
    }

    private void RemoveConsumableItem()
    {
        if (activeSlot.amount <= 1) 
        {
            quickslotParent.GetChild(currentQuickslotID).GetComponentInChildren<DragAndDropItem>().NullifySlotData();
        }
        else
        {
            activeSlot.amount--;
            activeSlot.itemAmountText.text = activeSlot.amount.ToString();
        }
    }

    public void CheckItemInHand()
    {
        HideItemsInHand();

        if (activeSlot.item != null) 
        {
            ShowItemInHand();
        }
        else
        {
            currentGun = null;
            HitBool = false;

            anim.SetBool("Hit", false);
        }
    }

    private void ChangeCharacteristics()
    {
        indicators.ChangeFoodAmount(activeSlot.item.changeHunger);
        indicators.ChangeWaterAmount(activeSlot.item.changeThirst);
        indicators.ChangeHealthAmount(activeSlot.item.changeHealth);
        indicators.ChangeColdAmount(activeSlot.item.changeCold);

        inventoryManager.audioSource.volume = Random.Range(0.2f, 0.4f);
        inventoryManager.audioSource.pitch = Random.Range(0.8f, 1.2f);

        inventoryManager.audioSource.PlayOneShot(activeSlot.item.itemAudio);

        RemoveConsumableItem();
    }

    private void ShowItemInHand()
    {
        AchivementChek(1);

        inventoryManager.audioSource.volume = Random.Range(0.2f, 0.4f);
        inventoryManager.audioSource.pitch = Random.Range(0.8f, 1.2f);

        inventoryManager.audioSource.PlayOneShot(activeSlot.item.itemAudio);

        if(currentQuickslotID != currentSmenaSlotID)
        {
            anim.SetBool("Smena", true);
            currentSmenaSlotID = currentQuickslotID;
        }

        if (activeSlot.item.animType != AnimType.Default)
        {
            switch (activeSlot.item.animType)
            {
                case AnimType.Spear:
                    anim.SetBool("Spear", true);
                    break;
                case AnimType.Gun:
                    anim.SetBool("Weapon", true);
                    break;
                case AnimType.BigSwords:
                    anim.SetBool("BigSwords", true);
                    break;
                case AnimType.Kosa:
                    anim.SetBool("Kosa", true);
                    break;
            }
        }

        for (int i = 0; i < allWeapons.childCount; i++)
        {
            GameObject equipItem = allWeapons.GetChild(i).gameObject; 

            if (activeSlot.item.inHandName == equipItem.name)
            {
                equipItem.SetActive(true);

                if (photonSetManager != null) 
                {
                    if (PlayerPrefs.HasKey("Multiplayer"))
                    {
                        if(System.Convert.ToBoolean(PlayerPrefs.GetInt("Multiplayer")) == true)
                        {
                            photonSetManager.SetWeapon(true, i);
                        }
                    }
                }

                if (currentWeapon != null) //тут так написано чтобы по максимуму без GetComponent обойтись если что
                {
                    if (equipItem != currentWeapon.gameObject)
                    {
                        currentWeapon = null;
                        currentWeapon = equipItem.GetComponent<GatherResources>();
                    }
                }
                else 
                {
                    currentWeapon = equipItem.GetComponent<GatherResources>();
                }

                anim.SetBool("SpeedMedium", false);
                anim.SetBool("SpeedLow", false);
                anim.SetBool("SpeedMax", false);

                switch (activeSlot.item.speedAttacke)
                {
                    case SpeedAttacke.Low:
                        anim.SetBool("SpeedLow", true);
                        break;
                    case SpeedAttacke.Medium:
                        anim.SetBool("SpeedMedium", true);
                        break;
                    case SpeedAttacke.Max:
                        anim.SetBool("SpeedMax", true);
                        break;
                }

                if (currentGun != null)
                {
                    if (equipItem != currentGun.gameObject)
                    {
                        currentGun = null;
                        currentGun = equipItem.GetComponent<Gun>();
                    }
                }
                else 
                {
                    currentGun = equipItem.GetComponent<Gun>();
                }

                break;
            }
        }
    }

    public void AnimHelper()
    {
        anim.SetBool("BigSwords", false);
        anim.SetBool("Spear", false);
        anim.SetBool("Weapon", false);
        anim.SetBool("Kosa", false);
    }

    private void HideItemsInHand()
    {
        for (int i = 0; i < allWeapons.childCount; i++)
        {
            allWeapons.GetChild(i).gameObject.SetActive(false);
        }

        if (photonSetManager != null) 
        {
            if (PlayerPrefs.HasKey("Multiplayer"))
            {
                if(System.Convert.ToBoolean(PlayerPrefs.GetInt("Multiplayer")) == true)
                {
                    photonSetManager.SetWeapon(false, 1);
                }
            }
        }

        AnimHelper();
    }

    public void MobailDragSlot(GameObject slotGO)
    {
        for (int i = 0; i < quickslotParent.childCount; i++)
        {
            if (slotGO == quickslotParent.GetChild(i).gameObject)
            {
                currentQSlotImage.color = notSelectedColor;
                currentQuickslotID = i;

                SelectSlot();
                break;
            }
        }
    }

    public void ActiveSlot()
    {
        if (activeSlot.item != null)
        {
            if (!inventoryManager.isOpened && currentQSlotImage.color == selectedColor)
            {
                if (activeSlot.item.isConsumeable && activeSlot.item.itemType == ItemType.Food)
                {
                    ChangeCharacteristics(); // Применяем изменения к здоровью (будущем к голоду и жажде) 
                    CheckItemInHand();
                }
                else if (activeSlot.item.itemType == ItemType.Instrument || activeSlot.item.itemType == ItemType.Weapon)
                {
                    anim.SetBool("Hit", true);
                    HitBool = true;
                }
                else if (activeSlot.item.itemType == ItemType.FireWeapon)
                {
                    anim.SetBool("Hit", false);
                    HitBool = true;
                }
            }
        }
        else
        {
            currentGun = null;
            anim.SetBool("Hit", false);
            HitBool = false;
        }
    }

    public void OnReload()
    {
        if (currentGun != null) currentGun.Reload();
    }

    public void AudioReload()
    {
        if (currentGun != null)
        {
            audioSource.pitch = Random.Range(0.9f, 1.1f);
            audioSource.PlayOneShot(currentGun.reloadAudio);
        }
    }

    public void EndReload()
    {
        anim.SetBool("Reload", false);

        if (currentGun != null)
        {
            currentGun.reload = false;
            currentGun.Amount = currentGun.realBilletAmmount;
        }
    }
}