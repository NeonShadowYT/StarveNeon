﻿using System.Collections.Generic;
using UnityEngine;

public class Building : BuildingBlock, ICheckColliders, IHaveConnections
{
    [Space]
    public BuildingHealth buildingHealth;

    [Space]
    public List<GameObject> foundationConnections;
    public List<GameObject> edgeConnections;
    public List<GameObject> wallConnections;
    public List<GameObject> mebelConnections;

    [Space]
    public Collider collider;
    public LayerMask layerMask;
    public BuildingType buildingType;
    public string connectionType = "FoundationConnection";

    [Space]
    public List<GameObject> deactiveConnections;

    protected override void Start()
    {
        foreach (GameObject foundationConnection in foundationConnections) foundationConnection.SetActive(false);
        foreach (GameObject edgeConnection in edgeConnections) edgeConnection.SetActive(false);
        foreach (GameObject wallConnection in wallConnections) wallConnection.SetActive(false);
        foreach (GameObject mebelConnection in mebelConnections) mebelConnection.SetActive(false);

        base.Start();
    }

    public void CheckColliders()
    {
        detectedColliders = new List<Collider>();
        Collider[] currentColliders = null;

        switch (buildingType)
        {
            case BuildingType.Foundation:
                currentColliders = Physics.OverlapBox(transform.position, _colliderExtents * 7.5f, transform.rotation, ~layerMask);
                break;
            case BuildingType.Mebel:
                currentColliders = Physics.OverlapBox(transform.position, _colliderExtents, transform.rotation, ~layerMask);
                break;
            default:
                currentColliders = Physics.OverlapBox(transform.position, _colliderExtents * 5f, transform.rotation, ~layerMask);
                break;
        }

        detectedColliders.AddRange(currentColliders);
    } 

    public void CheckNearby(int i)
    {
        Collider[] overlapColliders = null;

        switch (buildingType)
        {
            case BuildingType.Foundation:
                overlapColliders = Physics.OverlapSphere(foundationConnections[i].transform.position, foundationConnections[i].GetComponent<SphereCollider>().radius);

                foreach (Collider overlapCollider in overlapColliders)
                {
                    if (overlapCollider.gameObject.GetComponent<Building>() != null)
                    {
                        GameObject foundationConnection = foundationConnections[i];
                        foundationConnection.SetActive(false);

                        deactiveConnections.Add(foundationConnection);
                        break;
                    }
                }

                break;
            case BuildingType.Edge:
                overlapColliders = Physics.OverlapSphere(edgeConnections[i].transform.position, edgeConnections[i].GetComponent<SphereCollider>().radius);

                foreach (Collider overlapCollider in overlapColliders)
                {
                    if (overlapCollider.gameObject.GetComponent<Building>() != null)
                    {
                        GameObject edgeConnection = edgeConnections[i];
                        edgeConnection.SetActive(false);

                        deactiveConnections.Add(edgeConnection);
                        break;
                    }
                }

                break;
            case BuildingType.Wall:
                overlapColliders = Physics.OverlapSphere(wallConnections[i].transform.position, wallConnections[i].GetComponent<SphereCollider>().radius);

                foreach (Collider overlapCollider in overlapColliders)
                {
                    if (overlapCollider.gameObject.GetComponent<Building>() != null)
                    {
                        GameObject wallConnection = wallConnections[i];
                        wallConnection.SetActive(false);

                        deactiveConnections.Add(wallConnection);
                        break;
                    }
                }

                break;
            case BuildingType.Mebel:
                overlapColliders = Physics.OverlapSphere(mebelConnections[i].transform.position, mebelConnections[i].GetComponent<SphereCollider>().radius);

                foreach (Collider overlapCollider in overlapColliders)
                {
                    if (overlapCollider.gameObject.GetComponent<Building>() != null)
                    {
                        GameObject mebelConnection = mebelConnections[i];
                        mebelConnection.SetActive(false);

                        deactiveConnections.Add(mebelConnection);
                        break;
                    }
                }

                break;
        }
    }

    public void TurnOnConnections()
    {
        foreach (GameObject foundationConnection in foundationConnections) foundationConnection.SetActive(true);
        foreach (GameObject edgeConnection in edgeConnections) edgeConnection.SetActive(true);
        foreach (GameObject wallConnection in wallConnections) wallConnection.SetActive(true);
        foreach (GameObject mebelConnection in mebelConnections) mebelConnection.SetActive(true);
    }
}
