using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine;
using Photon.Pun;
using System.Collections;

public class CustomCharacterController : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public static CustomCharacterController instance;
    public RunEffect runEffect;
    public GenStats genStats;

    [Space]
    [Header("Компоненты")]
    public PhotonView photonView;
    public Rigidbody rig;
    public Animator anim;
    
    [Space]
    [Header("Переменные")]
    public float walkingSpeed = 7f;
    public float runningSpeed = 11f, lerpMultiplier = 7f, animationInterpolation = 1f;
    public float floatUpSpeed = 5f, floatUpSpeedLimit = 10f;
    
    [HideInInspector]
    public float currentSpeed, horizontal, vertical;

    [Space]
    [Header("Прыжок")]
    public float jumpForce = 5f;

    private byte platformCollisions;
    public bool CanJump
    {
        get { return platformCollisions > 0; }
    }

    [Space]
    [Header("Объекты")]
    public GameObject MobaillMenu;

    [Space]
    [Header("Звуки")]
    public AudioSource audioSource;
    public AudioClip[] audioHit;

    [Space]
    [Header("Разное")]
    public Transform mainCamera;
    public Transform mTransform;

    [Space]
    public Transform[] ParrentObj;
    public List<string> stepId;

    private bool cooldownJump;

    private void Awake() => instance = this;

    private void Start()
    {
        foreach (Transform obj in ParrentObj) 
        {
            obj.parent = null;
        }

        if (SystemInfo.deviceType != DeviceType.Handheld)
        {
            MobaillMenu.SetActive(false);
        }

        platformCollisions = 0;
    }

    private void Run()
    {
        animationInterpolation = Mathf.Lerp(animationInterpolation, 1.5f, Time.deltaTime * 3);

        anim.SetFloat("x", horizontal * animationInterpolation);
        anim.SetFloat("y", vertical * animationInterpolation);

        if (PetsManager.instance.currentPets == null) currentSpeed = Mathf.Lerp(currentSpeed, runningSpeed, Time.deltaTime * 3);
        else currentSpeed = Mathf.Lerp(currentSpeed, PetsManager.instance.currentPets.runSpeed, Time.deltaTime * 3);

        anim.SetFloat("run", currentSpeed / runningSpeed);
    }

    private void Walk()
    {
        runEffect.NoRunEffect();
        animationInterpolation = Mathf.Lerp(animationInterpolation, 1f, Time.deltaTime * 3); // Mathf.Lerp - отвчает за то, чтобы каждый кадр число animationInterpolation(в данном случае) приближалось к числу 1 со скоростью Time.deltaTime * 3.
        
        anim.SetFloat("x", horizontal * animationInterpolation);
        anim.SetFloat("y", vertical * animationInterpolation);

        if (PetsManager.instance.currentPets == null) currentSpeed = Mathf.Lerp(currentSpeed, walkingSpeed, Time.deltaTime * 3);
        else currentSpeed = Mathf.Lerp(currentSpeed, PetsManager.instance.currentPets.walkSpeed, Time.deltaTime * 3);

        anim.SetFloat("run", 0f);
    }

    private void LateUpdate()
    {
        horizontal = Mathf.Lerp(horizontal, VariableJoystick.instance.Horizontal + Input.GetAxis("Horizontal"), Time.deltaTime * lerpMultiplier);
        vertical = Mathf.Lerp(vertical, VariableJoystick.instance.Vertical + Input.GetAxis("Vertical"), Time.deltaTime * lerpMultiplier);

        if (horizontal < 0.25f && horizontal > -0.25f && vertical > 0.5f)
        {
            Run();
        }
        else
        {
            Walk();
        }
        
        mTransform.rotation = Quaternion.Euler(mTransform.rotation.eulerAngles.x, mainCamera.rotation.eulerAngles.y, mTransform.rotation.eulerAngles.z); // Устанавливаем поворот персонажа когда камера поворачивается 
        TurnController.instance.TurnUpdate();
    }

    private void FixedUpdate()
    {
        Vector3 camF = mainCamera.forward; // Здесь мы задаем движение персонажа в зависимости от направления в которое смотрит камера
        Vector3 camR = mainCamera.right; // Сохраняем направление вперед и вправо от камеры

        camF.y = 0; // Чтобы направления вперед и вправо не зависили от того смотрит ли камера вверх или вниз, иначе когда мы смотрим вперед, персонаж будет идти быстрее чем когда смотрит вверх или вниз
        camR.y = 0; // Можете сами проверить что будет убрав camF.y = 0 и camR.y = 0 :)

        Vector3 movingVector;
        movingVector = Vector3.ClampMagnitude(camF.normalized * vertical * currentSpeed + camR.normalized * horizontal * currentSpeed, currentSpeed); // Тут мы умножаем наше нажатие на кнопки W & S на направление камеры вперед и прибавляем к нажатиям на кнопки A & D и умножаем на направление камеры вправо

        rig.velocity = new Vector3(movingVector.x, rig.velocity.y, movingVector.z); // Здесь мы двигаем персонажа! Устанавливаем движение только по x & z потому что мы не хотим чтобы наш персонаж взлетал в воздух
        rig.angularVelocity = Vector3.zero; // У меня был баг, что персонаж крутился на месте и это исправил с помощью этой строки
    }

    public void OnJump(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            Jump();
        }
    }

    public void Jump()
    {
        if (CanJump == true && cooldownJump == false)
        {
            rig.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);

            cooldownJump = true;
            Invoke(nameof(CooldownJump), 0.25f);
        }
    }

    public void CooldownJump()
    {
        cooldownJump = false;
    }

    public void StartHit()
    {
        int random = Random.Range(0, audioHit.Length);

        audioSource.volume = Random.Range(0.8f, 1.2f);
        audioSource.pitch = Random.Range(0.8f, 1.2f);

        audioSource.PlayOneShot(audioHit[random]);
    }

    public void ChangBiom()
    {
        Indicators.instance.changBiomEffect.infinity = true;
        Indicators.instance.changBiomEffect.gameObject.SetActive(true);

        Invoke(nameof(OnChangBiom), 5f);
    }

    private void OnChangBiom()
    {
        DataSaveLoad.instance.Live();
    }

    private IEnumerator WaterPhysics()
    {
        while (true)
        {
            rig.AddForce(Vector3.up * Mathf.Clamp(Mathf.Abs(Physics.gravity.y) * floatUpSpeed, 0, Mathf.Abs(Physics.gravity.y) * floatUpSpeedLimit), ForceMode.Acceleration);

            rig.drag = 0.99f;
            rig.angularDrag = 0.8f;
            yield return null;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Water")) //Входим ли мы в воду ?
        {
            Indicators.instance.waterEffect.infinity = true;
            stepId.Add("Вода");
            
            Indicators.instance.waterEffect.gameObject.SetActive(true);
            StartCoroutine(WaterPhysics());
        }
        if (other.CompareTag("Damage")) 
        {
            Indicators.instance.damageEffect.infinity = true;
            Indicators.instance.damageEffect.gameObject.SetActive(true);
        }
        if (other.CompareTag("Infected"))
        {
            Indicators.instance.infectionEffect.gameObject.SetActive(true);
        }
        if (other.CompareTag("Web"))
        {
            Indicators.instance.webEffect.gameObject.SetActive(true);
        }

        if (other.CompareTag("Fire"))
        {
            Indicators.instance.hotEffect.infinity = true;
            Indicators.instance.hotEffect.gameObject.SetActive(true);
        }
        else if (other.CompareTag("Cold")) 
        {
            if (ArmorStats.instance.cold < 3)
            {
                Indicators.instance.coldEffect.infinity = true;
                Indicators.instance.coldEffect.gameObject.SetActive(true);
            }
        }

        if (other.CompareTag("Lava"))
        {
            Indicators.instance.fireEffect.infinity = true;
            Indicators.instance.fireEffect.gameObject.SetActive(true);
        }
        if (other.CompareTag("Infected")) //Если стоим на зоне заражения
        {
            Indicators.instance.infectionEffect.infinity = true;
            Indicators.instance.infectionEffect.gameObject.SetActive(true);
        }
        if (other.CompareTag("Web")) //Если стоим на паутине
        {
            Indicators.instance.webEffect.infinity = true;
            Indicators.instance.webEffect.gameObject.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Water"))
        {
            Indicators.instance.waterEffect.infinity = false; //Выходим из этих зон?
            stepId.Remove("Вода");
            StopAllCoroutines();

            rig.drag = 0f;
            rig.angularDrag = 0f;
        }

        if (other.CompareTag("Damage"))
        {
            Indicators.instance.damageEffect.infinity = false;
        }

        if (other.CompareTag("Fire"))
        {
            Indicators.instance.hotEffect.infinity = false;
        }
        else if (other.CompareTag("Cold")) 
        {
            Indicators.instance.coldEffect.infinity = false;
        }

        if (other.CompareTag("MapEnd"))
        {
            ChangBiom();
        }

        if (other.CompareTag("Lava")) Indicators.instance.fireEffect.infinity = false;
        if (other.CompareTag("Infected")) Indicators.instance.infectionEffect.infinity = false;
        if (other.CompareTag("Web")) Indicators.instance.webEffect.infinity = false;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground")) //Прыгнули
        {
            stepId.Add("Земля");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Plants")) //Прыгнули
        {
            stepId.Add("Растение");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("AD"))
        {
            stepId.Add("Ад");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Rock"))
        {
            stepId.Add("Камень");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Snow"))
        {
            stepId.Add("Снег");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Sand"))
        {
            stepId.Add("Песок");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Infection"))
        {
            stepId.Add("Заражение");
            platformCollisions++;
        }
        else if (collision.gameObject.CompareTag("Wood"))
        {
            stepId.Add("Дерево");
            platformCollisions++;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground")) //Прыгнули
        {
            stepId.Remove("Земля");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Plants")) //Прыгнули
        {
            stepId.Remove("Растение");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("AD"))
        {
            stepId.Remove("Ад");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Rock"))
        {
            stepId.Remove("Камень");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Snow"))
        {
            stepId.Remove("Снег");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Sand"))
        {
            stepId.Remove("Песок");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Infection"))
        {
            stepId.Remove("Заражение");
            platformCollisions--;
        }
        else if (collision.gameObject.CompareTag("Wood"))
        {
            stepId.Remove("Дерево");
            platformCollisions--;
        }
    }

    public void TakeDamage(float damage, EquipEffect effect, int chanceEffect, float crit, float critModifer, float weak, float weakModifer)
    {
        damage *= genStats.healthPlus;
        critModifer *= genStats.critDamage;

        float random = Random.Range(0, 100);

        if (random >= crit) damage *= critModifer;
        else if (random <= weak) damage *= weakModifer;

        if (QuickslotInventory.instance.special && ClothAdder.instance.shieldSlot.item != null && ClothAdder.instance.shield.recharg == false)
        {
            damage *= ClothAdder.instance.shield.resistance;
            ClothAdder.instance.shield.StartRecharges();

            random = damage * Random.Range(0.25f, 0.5f);
            ClothAdder.instance.shieldSlot.SubtractDurabilityPerHit(random);
        }
        else
        {
            random = damage * Random.Range(0.125f, 0.25f);

            ClothAdder.instance.armorSlot.SubtractDurabilityPerHit(random);
            ClothAdder.instance.backpackSlot.SubtractDurabilityPerHit(random);
            ClothAdder.instance.shieldSlot.SubtractDurabilityPerHit(random);
        }

        anim.SetBool("Shield", false); //щит
        Indicators.instance.ChangeHealthAmount(-damage * (1f - ArmorStats.instance.armor * 0.025f));

        if (Random.Range(0, 100) <= chanceEffect)
        {
            switch (effect)
            {
                case EquipEffect.Blood:
                    Indicators.instance.bloodEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Web:
                    Indicators.instance.webEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Poison:
                    Indicators.instance.poisonEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Infected:
                    Indicators.instance.infectionEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Fire:
                    Indicators.instance.fireEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Frost:
                    Indicators.instance.frostEffect.gameObject.SetActive(true);
                    break;
                case EquipEffect.Mutagen:
                    
                    break;
            }
        }

        ClothAdder.instance.UpdateClothes();
    }
}