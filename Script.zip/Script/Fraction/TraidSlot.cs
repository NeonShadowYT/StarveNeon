using UnityEngine;
public class TraidSlot : MonoBehaviour
{
    public ItemScriptableObject buyItem;
    public int price;
}
