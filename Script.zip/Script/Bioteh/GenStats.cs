using UnityEngine;

public class GenStats : MonoBehaviour
{
    public BioManager bioManager;

    [Space]
    [Header("Гены")]
    public int ksenoTypeMetabalizm;

    public float regenPlus = 1f; 
    public float foodPlus = 1f; 
    public float waterPlus = 1f; 
    public float coldPlus = 1f; 
    public float healthPlus = 1f;
    public float razbrosPlus = 1f; 
    public float damagePlus = 1f; 
    public float adColdPlus = 1f; 
    public float snowColdPlus = 1f; 
    public float nightSpeed = 1f; 
    public float daySpeed = 1f;
    public float noArmorSpeed = 1f; 
    public float armorSpeed = 1f; 
    public float plants = 1f; 
    public float petsPlus = 1f; 
    public float critPlus = 1f; 
    public float critDamage = 1f;

    private void Start()
    {
        GenEquip();
    }

    private void GenEquip()
    {
        foreach (GenScriptableObject genScriptableObject in bioManager.genAcceptList)
        {
            ksenoTypeMetabalizm += genScriptableObject.Metabalizm;

            ArmorStats.instance.cold += genScriptableObject.NaturalColdArmor;
            Indicators.instance.webEffect.genModifer *= genScriptableObject.TimeWeb;

            regenPlus *= genScriptableObject.RegenPlus;
            healthPlus *= genScriptableObject.HealthPlus;

            foodPlus *= genScriptableObject.FoodPlus;
            waterPlus *= genScriptableObject.WaterPlus;
            coldPlus *= genScriptableObject.ColdPlus;

            adColdPlus *= genScriptableObject.AdColdPlus;
            snowColdPlus *= genScriptableObject.SnowColdPlus;

            nightSpeed *= genScriptableObject.NightSpeed;
            daySpeed *= genScriptableObject.DaySpeed;

            noArmorSpeed *= genScriptableObject.NoArmorSpeed;
            armorSpeed *= genScriptableObject.ArmorSpeed;

            razbrosPlus *= genScriptableObject.RazbrosPlus;
            CustomCharacterController.instance.jumpForce *= genScriptableObject.JumpPlus;
            plants *= genScriptableObject.MyPlants;
            petsPlus *= genScriptableObject.PetsPlus;

            damagePlus *= genScriptableObject.DamagePlus;
            Indicators.instance.bloodEffect.healthModifer *= genScriptableObject.DamageBlood;

            critDamage *= genScriptableObject.CritDamage;
            critPlus *= genScriptableObject.CritPlus;
        }
    }
}
