﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CraftManager : MonoBehaviour // https://www.youtube.com/c/maximple, https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    public static CraftManager instance;

    [Space]
    [Header("Текущая информация о крафте")]
    public FillCraftItemDetails currentCraftItem;

    [Space]
    [Header("Крафт предмета детали")]
    public Image craftItemImage;
    public TMP_Text craftItemName;
    public TMP_Text craftItemTime;
    public TMP_Text craftItemDescription;

    [Space]
    [Header("Все крафты")]
    public List<CraftResourceDetails> allResDetails;
    public List<FillCraftItemDetails> allCraftItemDetails;

    [Space]
    [Header("Объекты")]
    public TMP_Dropdown craftCategoryDropdown;
    public GameObject craftItemButtonPrefab;
    public Transform craftItemsPanel;
    public Button craftBtn;
    public Button buildingBtn;

    private void Awake() => instance = this;

    private void Start()
    {
        LoadCraftList();
        LoadCraftCategory();

        currentCraftItem = allCraftItemDetails[0]; // подсказка новичкам что нужно крафтить сначала
        FillItemDetailsHelper();
    }

    public void FillItemDetailsHelper() => currentCraftItem.FillItemDetails();

    private void LoadCraftList() // загружаем все крафты
    {
        CraftScriptableObject[] craftScriptableObject = Resources.LoadAll<CraftScriptableObject>($"CraftItems/");
        bool craftComplite;

        for (int i = 0; i < craftScriptableObject.Length; i++)
        {
            if (craftScriptableObject[i].verstLevel == 0)
            {
                ChangCraftList(craftScriptableObject[i]);
            }
            else
            {
                craftComplite = false;

                for (int ii = 0; ii < DataSaveLoad.instance.data.allCrafts.Length; ii++)
                {
                    if (craftScriptableObject[i].name == DataSaveLoad.instance.data.allCrafts[ii])
                    {
                        ChangCraftList(craftScriptableObject[i]);
                        craftComplite = true;
                        break;
                    }
                }

                if (craftComplite == false)
                {
                    VerstacManager.instance.AddCraft(craftScriptableObject[i]);
                }
            }
        }
    }

    public void ChangCraftList(CraftScriptableObject сraftScriptableObject) // добавляем крафты
    {
        FillCraftItemDetails fillCraftItemDetails = Instantiate(craftItemButtonPrefab, craftItemsPanel).GetComponent<FillCraftItemDetails>();
        allCraftItemDetails.Add(fillCraftItemDetails);

        fillCraftItemDetails.currentCraftItem = сraftScriptableObject;
        fillCraftItemDetails.image.sprite = сraftScriptableObject.finalCraft.icon;

        fillCraftItemDetails.gameObject.SetActive(false);
    }

    public void LoadCraftCategory() // загружаем категорию из craftCategoryDropdown
    {
        switch (craftCategoryDropdown.value)
        {
            case 0:
                ChangCategoryList(CraftType.Common);
                break;
            case 1:
                ChangCategoryList(CraftType.Tools);
                break;
            case 2:
                ChangCategoryList(CraftType.Weapons);
                break;
            case 3:
                ChangCategoryList(CraftType.Armor);
                break;
            case 4:
                ChangCategoryList(CraftType.Gun);
                break;
            case 5:
                ChangCategoryList(CraftType.Special);
                break;
        }
    }

    public void ChangCategoryList(CraftType craftType) // изменяем категорию
    {
        for (int i = 0; i < allCraftItemDetails.Count; i++)
        {
            if (allCraftItemDetails[i].currentCraftItem.craftType == craftType)
            {
                allCraftItemDetails[i].gameObject.SetActive(true);
            }
            else
            {
                allCraftItemDetails[i].gameObject.SetActive(false);
            }
        }
    }
}