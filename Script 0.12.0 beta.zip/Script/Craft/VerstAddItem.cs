using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using TMPro;

public class VerstAddItem : MonoBehaviour //https://www.youtube.com/channel/UC2pH2qNfh2sEAeYEGs1k_Lg
{
    [Space]
    [Header("�������")]
    public VerstCraftHelper verstCraftHelper;
    public CraftManager craftManager;
    public MoneySlot texnoSlot;

    [Space]
    [Header("����������")]
    public GameObject VerstacPanel;
    public GameObject[] VerstacID;

    [Space]
    public Image CraftIcon;
    public GameObject CraftAnLockButton;
    public TMP_Text CraftName, CraftDiscriphen, CraftScoreTreb;

    public void UpdateCraftAnLock(ItemScriptableObject craftAnLock, int anlockScore)
    {
        CraftIcon.sprite = craftAnLock.icon;
        CraftName.text = craftAnLock.itemName;
        CraftDiscriphen.text = craftAnLock.itemDescription;
        CraftScoreTreb.text = anlockScore.ToString();

        CraftScoreTreb.gameObject.SetActive(true);
        CraftDiscriphen.gameObject.SetActive(true);
        CraftName.gameObject.SetActive(true);
        CraftIcon.gameObject.SetActive(true);
        CraftAnLockButton.SetActive(true);

        verstCraftHelper.currentVerstAnLock = 0;
    }

    public void AnLock(int anlockScore, CraftScriptableObject craftAnLock)
    {
        CraftScoreTreb.gameObject.SetActive(false);
        CraftDiscriphen.gameObject.SetActive(false);
        CraftName.gameObject.SetActive(false);
        CraftIcon.gameObject.SetActive(false);
        CraftAnLockButton.SetActive(false);

        int chekAnlok = 0;

        foreach (CraftScriptableObject cso in craftManager.allCrafts)
        {
            if (cso == craftAnLock)
            {
                verstCraftHelper.currentVerstAnLock = 1;
                chekAnlok = 1;
                break;
            }
        }

        if (texnoSlot.amount >= anlockScore && chekAnlok == 0)
        {
            texnoSlot.amount -= anlockScore;
            craftManager.allCrafts.Add(craftAnLock);
            verstCraftHelper.currentVerstAnLock = 1;
        }
    }

    public void StartFunc(int verstID)
    {
        VerstacPanel.SetActive(true);

        for (int i = 0; i < VerstacID.Length; i++) VerstacID[i].SetActive(false);

        VerstacID[verstID].SetActive(true);

        CraftScoreTreb.gameObject.SetActive(false);
        CraftDiscriphen.gameObject.SetActive(false);
        CraftName.gameObject.SetActive(false);
        CraftIcon.gameObject.SetActive(false);
        CraftAnLockButton.SetActive(false);
    }
}
