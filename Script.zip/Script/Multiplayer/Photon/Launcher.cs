using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;
using TMPro;

public class Launcher : MonoBehaviourPunCallbacks
{
    public static Launcher instance;
    public string region = "ru";

    [Space]
    [Header("Вылазки")]
    public Transform scrollContent;

    public GameObject roomPrefab;
    public GameObject playerPrefab;

    [Space]
    [Header("Загрузка")]
    public GameObject loadObject;
    public TMP_Text loadText;

    [Space]
    [Header("Поиск")]
    public GameObject findObject;

    [Space]
    [Header("Отряд")]
    public GameObject lobbyObject;
    public TMP_Text nameText;
    public TMP_Text leaderText;

    private void Awake() => instance = this;

    private void Start() 
    {
        Reconnected();
    }
    
    public void Reconnected()
    {
        loadText.text = "Идём к отрядам";

        loadObject.SetActive(true);
        findObject.SetActive(false);
        lobbyObject.SetActive(false);

        if (!PhotonNetwork.IsConnected)
        {
            PhotonNetwork.NickName = DataSaveLoad.instance.data.playerNick;
            PhotonNetwork.GameVersion = DataSaveLoad.instance.data.saveVersion;
            PhotonNetwork.AutomaticallySyncScene = true;

            PhotonNetwork.ConnectUsingSettings();
            PhotonNetwork.ConnectToRegion(region);
        }
        else
        {
            OnConnectedToMaster();
        }
    }

    public void ChangScene()
    {
        loadText.text = "Вылазка начинается";

        loadObject.SetActive(true);
        findObject.SetActive(false);
        lobbyObject.SetActive(false);

        if (PhotonNetwork.InRoom && PhotonNetwork.IsMasterClient)
        {
            if (DataSaveLoad.instance.data.biom != "База") 
            {
                PhotonNetwork.CurrentRoom.IsVisible = false;
                PhotonNetwork.LoadLevel(DataSaveLoad.instance.data.biom);
                return;
            }
        }

        SceneManager.LoadScene(DataSaveLoad.instance.data.biom);
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        loadText.text = "Вы потеряли отряд " + cause;

        loadObject.SetActive(true);
        findObject.SetActive(false);
        lobbyObject.SetActive(false);

        PhotonNetwork.ConnectUsingSettings();
        PhotonNetwork.ConnectToRegion(region);
    }

    public override void OnConnectedToMaster()
    {
        loadText.text = "Поиск отрядов";

        if (SceneManager.GetActiveScene().name == "База")
        {
            if (!PhotonNetwork.InLobby)
            {
                PhotonNetwork.JoinLobby();
            }
            else
            {
                OnJoinedLobby();
            }
        }
    }

    public override void OnJoinedLobby() //если мы смогли подключиться к инету
    {
        loadText.text = "Отряды найдены";

        if (PhotonNetwork.InRoom)
        {
            LeaveRoom();
        }

        loadObject.SetActive(false);
        findObject.SetActive(true);
        lobbyObject.SetActive(false);
    }

    public override void OnCreateRoomFailed(short returnCode, string message)
    {
        loadText.text = "Не удалось создать отряд " + message;

        loadObject.SetActive(true);
        findObject.SetActive(false);
        lobbyObject.SetActive(false);
    }

    public void CreateRoom()
    {
        if (!PhotonNetwork.InRoom)
        {
            loadText.text = "Создаём отряд " + PhotonNetwork.NickName;
            PhotonNetwork.CreateRoom(PhotonNetwork.NickName);

            loadObject.SetActive(true);
            findObject.SetActive(false);
            lobbyObject.SetActive(false);
        }
        else
        {
            LeaveRoom();
        }
    }

    public override void OnCreatedRoom()
    {
        loadText.text = "Отряд создан";
        DataSaveLoad.instance.Save();
    }

    public void JoinRoom(RoomInfo info)
    {
        if (!PhotonNetwork.InRoom)
        {
            loadText.text = "Вступаем в отряд " + info.Name;
            PhotonNetwork.JoinRoom(info.Name);

            loadObject.SetActive(true);
            findObject.SetActive(false);
            lobbyObject.SetActive(false);
        }
        else
        {
            LeaveRoom();
        }
    }

    public override void OnJoinedRoom() //зашли в лобби
    {
        DataSaveLoad.instance.Save();
        
        nameText.text = PhotonNetwork.CurrentRoom.Name;
        leaderText.text = PhotonNetwork.MasterClient.NickName;
        
        Player[] players = PhotonNetwork.PlayerList;

        foreach (Transform child in scrollContent)
        {
            Destroy(child.gameObject);
        }
        
        for (int i = 0; i < players.Length; i++)
        {
            OnPlayerEnteredRoom(players[i]);
        }

        loadObject.SetActive(false);
        findObject.SetActive(false);
        lobbyObject.SetActive(true);
    }

    public void LeaveRoom()
    {
        loadText.text = "Покидаем отряд";
        PhotonNetwork.LeaveRoom();

        loadObject.SetActive(true);
        findObject.SetActive(false);
        lobbyObject.SetActive(false);
    }

    public override void OnLeftRoom()
    {
        loadText.text = "Покинули отряд";

        loadObject.SetActive(false);
        findObject.SetActive(true);
        lobbyObject.SetActive(false);
    }

    public override void OnMasterClientSwitched(Player newMasterClient)
    {
        loadText.text = "Новый лидер отряда " + newMasterClient.NickName;
        leaderText.text = newMasterClient.NickName;
    }

    public override void OnRoomListUpdate(List<RoomInfo> _roomList) //когда создатся комната
    {
        if (PhotonNetwork.InRoom) return;

        foreach (Transform child in scrollContent)
        {
            Destroy(child.gameObject);
        }

        foreach (RoomInfo roomInfo in _roomList)
        {
            RoomListItem roomListItem = Instantiate(roomPrefab, scrollContent).GetComponent<RoomListItem>();

            roomListItem.launcher = this;
            roomListItem.SetUp(roomInfo);
        }
    }

    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        loadText.text = "Новый старвер в отряде " + newPlayer.NickName;
        Instantiate(playerPrefab, scrollContent).GetComponent<PlayerListItem>().SetUp(newPlayer);
    }
}