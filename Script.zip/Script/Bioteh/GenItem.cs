using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GenItem : MonoBehaviour
{
    [HideInInspector] public BioManager bioManager;

    public GenScriptableObject genScriptableObject;

    public Image icon;
    public TMP_Text text;

    public GameObject addButton;
    public GameObject removeButton;

    public void InfoGen()
    {
        bioManager.InfoGen(genScriptableObject);
    }

    public void AddGen()
    {
        bioManager.AddGen(genScriptableObject);
    }

    public void RemoveGen()
    {
        bioManager.RemoveGen(genScriptableObject);
    }
}
