using UnityEngine;

public class ItemSkins : MonoBehaviour
{
    public GameObject[] allSkinObj;
    public GameObject OriginalObj;

    private void Start()
    {
        Load();
    }

    public void Load() //кринге сделай чтобы просто меш менялся
    {
        for (int i = 0; i < allSkinObj.Length; i++)
        {
            ItemSkinScriptableObject itemSkinScriptableObject = Resources.Load<ItemSkinScriptableObject>($"ItemSkinScriptableObject/{DataSaveLoad.instance.data.inventorySkin[i]}");

            if (itemSkinScriptableObject.Name == allSkinObj[i].name)
            {
                allSkinObj[i].SetActive(true);
                OriginalObj.SetActive(false);
                break;
            }
        }
    }
}